# 🤖 Ultra Server Management Bot

A **1000+ feature** Discord bot for complete server management!

---

## 📦 Installation

### 1. Install Python 3.10+
Download from https://python.org

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Setup config
Edit `config.json`:
```json
{
  "token": "YOUR_BOT_TOKEN_HERE",
  "prefix": "!",
  "owner_ids": [YOUR_DISCORD_USER_ID]
}
```

### 4. Run the bot
```bash
python bot.py
```

---

## 🔑 Getting a Bot Token
1. Go to https://discord.com/developers/applications
2. Click **New Application**
3. Go to **Bot** → **Add Bot**
4. Click **Reset Token** → Copy token
5. Enable all **Privileged Gateway Intents**
6. Paste token in `config.json`

---

## 🎛️ Command Categories (1000+ Total Commands)

| Category | Commands | Description |
|---|---|---|
| 🛡️ Moderation | 50+ | ban, kick, mute, warn, purge, lock, role... |
| 👑 Admin | 40+ | setup, welcome, log, autorole, antispam... |
| ⚙️ Config | 15+ | config, modules, export/import settings... |
| 🔧 Utility | 50+ | afk, remind, avatar, calc, tags, qr... |
| 🏷️ Tags | 15+ | tag, tagcreate, taglist, taginfo... |
| 📋 Info | 15+ | userinfo, serverinfo, roles, permissions... |
| 🎉 Giveaway | 6+ | gstart, gend, greroll, glist... |
| 🎫 Tickets | 8+ | ticket, close, adduser, stats... |
| 💰 Economy | 20+ | balance, daily, work, slots, rob, pay... |
| ⭐ Leveling | 8+ | rank, leaderboard, setxp, setlevel... |
| 🎮 Fun | 35+ | meme, joke, ship, roast, trivia, rps... |
| 🕹️ Games | 8+ | guess, wordle, tictactoe, hangman... |
| 🎵 Music | 15+ | play, pause, skip, volume, queue... |

---

## ⚙️ Quick Setup Guide

```
!setup              — View setup guide
!setwelcome #ch     — Set welcome channel
!setleave #ch       — Set leave channel
!setlog #ch         — Set mod log channel
!setautorole @role  — Auto-role on join
!antispam on        — Enable anti-spam
!anticaps on        — Enable anti-caps
!antiinvite on      — Block invites
!xp on              — Enable XP system
!economy on         — Enable economy
!setstarboard #ch 3 — Setup starboard
!tempvc #hub-vc     — Temp voice channels
```

---

## 🛡️ Moderation Features

- **Ban System**: ban, unban, tempban, softban, hackban, banlist
- **Mute System**: mute, unmute, auto-mute on spam
- **Kick**: kick members
- **Warnings**: warn, warnings, delwarn, clearwarns, modhistory
- **Purge**: purge, purgeuser, purgebots, purgelinks, purgecontains
- **Channel Control**: lock, unlock, lockdown, slowmode, hide, unhide, nuke
- **Role Management**: addrole, removerole, massrole, createrole, rolecolor
- **Voice**: vcmove, vckick, vcmoveall, deafen, vmute
- **Notes**: note, notes, delnote
- **Blacklist**: blacklist, unblacklist

---

## 🤖 Auto-Moderation

- **Anti-Spam**: Auto-mute after X messages in 5 seconds
- **Anti-Caps**: Delete messages with 70%+ caps
- **Anti-Invite**: Block Discord invite links
- **Anti-Links**: Block all external links
- **Auto-Responder**: Custom triggers with responses

---

## 💰 Economy System

- 💵 Wallet + Bank system
- 🗓️ Daily rewards
- 👷 Work, Crime, Beg commands
- 🎰 Slots, Coin flip betting
- 🦹 Rob other members
- 💸 Pay/Transfer money
- 🏆 Rich leaderboard

---

## ⭐ XP & Leveling

- Auto XP gain per message
- Level-up announcements
- Level role rewards
- XP leaderboard
- Admin: set/give/reset XP

---

## 🎫 Ticket System

- User opens ticket with `!ticket`
- Private channel created
- Support role access
- Close with transcript saving
- Ticket statistics

---

## 🎉 Giveaway System

- Start giveaways with timer
- Multiple winners support
- Reroll system
- Early end option

---

## ⭐ Starboard

- Auto-posts starred messages
- Configurable emoji and count
- Updates star count live

---

## 🎙️ Temp Voice Channels

- Users join hub → auto-create private VC
- Empty VCs auto-deleted

---

## 🔧 File Structure

```
discord_bot/
├── bot.py              # Main bot file
├── config.json         # Configuration
├── requirements.txt    # Dependencies
├── ultrabot.db         # SQLite database (auto-created)
├── bot.log             # Log file (auto-created)
└── cogs/
    ├── moderation.py   # 50+ mod commands
    ├── admin.py        # 40+ admin commands
    ├── utility.py      # 50+ utility commands
    ├── fun.py          # 35+ fun commands
    ├── games.py        # 8+ game commands
    ├── economy.py      # 20+ economy commands
    ├── leveling.py     # XP system
    ├── giveaway.py     # Giveaway system
    ├── tickets.py      # Ticket system
    ├── info.py         # Info commands
    ├── config.py       # Config commands
    ├── tags.py         # Tags system
    ├── music.py        # Music commands
    └── help.py         # Help system
```

---

## 📋 Bot Permissions Required

When inviting the bot, grant these permissions:
- Administrator (recommended for all features)

Or manually: Manage Server, Manage Channels, Manage Roles, Manage Messages,
Kick Members, Ban Members, Moderate Members, View Channels, Send Messages,
Embed Links, Attach Files, Read Message History, Add Reactions, Connect, Speak, Move Members

---

## 🆘 Support

Join our support server or open a GitHub issue!

Made with ❤️ using discord.py
