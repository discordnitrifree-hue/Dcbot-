"""
╔══════════════════════════════════════════════════════════════╗
║          ULTRA SERVER MANAGEMENT BOT v1.0                   ║
║          1000+ Features | Admin Powerhouse                  ║
╚══════════════════════════════════════════════════════════════╝
"""

import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import json
import os
import random
import time
import datetime
import re
import math
import hashlib
import base64
import sqlite3
import logging
import aiohttp
import io
import sys
import traceback
from collections import defaultdict, Counter
from typing import Optional, Union

# ── Logging Setup ──────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("UltraBot")

# ── Bot Config ─────────────────────────────────────────────────
with open("config.json", "r") as f:
    config = json.load(f)

TOKEN        = config["token"]
PREFIX       = config.get("prefix", "!")
OWNER_IDS    = config.get("owner_ids", [])
LOG_CHANNEL  = config.get("log_channel_id", None)

# ── Intents ────────────────────────────────────────────────────
intents = discord.Intents.all()

# ── Bot Instance ───────────────────────────────────────────────
bot = commands.Bot(
    command_prefix=commands.when_mentioned_or(PREFIX),
    intents=intents,
    help_command=None,
    case_insensitive=True,
    description="Ultra Server Management Bot with 1000+ Features",
    owner_ids=set(OWNER_IDS),
)

# ── Database Setup ─────────────────────────────────────────────
def init_db():
    conn = sqlite3.connect("ultrabot.db")
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS warns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT, user_id TEXT, mod_id TEXT,
        reason TEXT, timestamp TEXT
    );
    CREATE TABLE IF NOT EXISTS mutes (
        guild_id TEXT, user_id TEXT, expires TEXT,
        PRIMARY KEY(guild_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT, user_id TEXT, mod_id TEXT,
        note TEXT, timestamp TEXT
    );
    CREATE TABLE IF NOT EXISTS xp (
        guild_id TEXT, user_id TEXT, xp INTEGER DEFAULT 0,
        level INTEGER DEFAULT 0, messages INTEGER DEFAULT 0,
        PRIMARY KEY(guild_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS economy (
        guild_id TEXT, user_id TEXT,
        wallet INTEGER DEFAULT 0, bank INTEGER DEFAULT 0,
        PRIMARY KEY(guild_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS giveaways (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT, channel_id TEXT, message_id TEXT,
        host_id TEXT, prize TEXT, winners INTEGER,
        ends_at TEXT, ended INTEGER DEFAULT 0,
        entries TEXT DEFAULT '[]'
    );
    CREATE TABLE IF NOT EXISTS afk (
        guild_id TEXT, user_id TEXT,
        reason TEXT, timestamp TEXT,
        PRIMARY KEY(guild_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS tags (
        guild_id TEXT, name TEXT, content TEXT,
        author_id TEXT, uses INTEGER DEFAULT 0,
        PRIMARY KEY(guild_id, name)
    );
    CREATE TABLE IF NOT EXISTS autorespond (
        guild_id TEXT, trigger TEXT, response TEXT,
        PRIMARY KEY(guild_id, trigger)
    );
    CREATE TABLE IF NOT EXISTS guild_settings (
        guild_id TEXT PRIMARY KEY,
        settings TEXT DEFAULT '{}'
    );
    CREATE TABLE IF NOT EXISTS starboard (
        guild_id TEXT, message_id TEXT, star_msg_id TEXT,
        stars INTEGER DEFAULT 0,
        PRIMARY KEY(guild_id, message_id)
    );
    CREATE TABLE IF NOT EXISTS reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT, guild_id TEXT, channel_id TEXT,
        remind_at TEXT, message TEXT, done INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT, channel_id TEXT, user_id TEXT,
        status TEXT DEFAULT 'open', opened_at TEXT, closed_at TEXT,
        transcript TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS polls (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT, channel_id TEXT, message_id TEXT,
        question TEXT, options TEXT, votes TEXT,
        ends_at TEXT, ended INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS reaction_roles (
        guild_id TEXT, message_id TEXT, emoji TEXT, role_id TEXT,
        PRIMARY KEY(guild_id, message_id, emoji)
    );
    CREATE TABLE IF NOT EXISTS temp_channels (
        guild_id TEXT, channel_id TEXT, owner_id TEXT,
        PRIMARY KEY(guild_id, channel_id)
    );
    CREATE TABLE IF NOT EXISTS command_stats (
        guild_id TEXT, command TEXT, uses INTEGER DEFAULT 0,
        PRIMARY KEY(guild_id, command)
    );
    CREATE TABLE IF NOT EXISTS join_leave_log (
        guild_id TEXT, user_id TEXT,
        event TEXT, timestamp TEXT
    );
    CREATE TABLE IF NOT EXISTS custom_commands (
        guild_id TEXT, name TEXT, response TEXT,
        PRIMARY KEY(guild_id, name)
    );
    CREATE TABLE IF NOT EXISTS blacklist (
        guild_id TEXT, user_id TEXT,
        reason TEXT,
        PRIMARY KEY(guild_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS slowmode_log (
        guild_id TEXT, channel_id TEXT,
        seconds INTEGER, set_by TEXT, timestamp TEXT
    );
    CREATE TABLE IF NOT EXISTS message_log (
        guild_id TEXT, message_id TEXT, author_id TEXT,
        channel_id TEXT, content TEXT, timestamp TEXT
    );
    """)
    conn.commit()
    conn.close()

init_db()

# ── DB Helper ──────────────────────────────────────────────────
def db():
    return sqlite3.connect("ultrabot.db")

# ── Guild Settings Helper ──────────────────────────────────────
def get_settings(guild_id: str) -> dict:
    with db() as conn:
        c = conn.cursor()
        c.execute("SELECT settings FROM guild_settings WHERE guild_id=?", (guild_id,))
        row = c.fetchone()
        if row:
            return json.loads(row[0])
        return {}

def set_settings(guild_id: str, settings: dict):
    with db() as conn:
        c = conn.cursor()
        c.execute(
            "INSERT OR REPLACE INTO guild_settings (guild_id, settings) VALUES (?,?)",
            (guild_id, json.dumps(settings))
        )
        conn.commit()

def update_setting(guild_id: str, key: str, value):
    s = get_settings(guild_id)
    s[key] = value
    set_settings(guild_id, s)

# ── Utility Functions ──────────────────────────────────────────
def plural(n, singular, plural_form):
    return f"{n} {singular}" if n == 1 else f"{n} {plural_form}"

def human_timedelta(dt: datetime.datetime) -> str:
    now = datetime.datetime.utcnow()
    delta = abs((now - dt).total_seconds())
    if delta < 60:    return f"{int(delta)}s"
    if delta < 3600:  return f"{int(delta//60)}m {int(delta%60)}s"
    if delta < 86400: return f"{int(delta//3600)}h {int((delta%3600)//60)}m"
    return f"{int(delta//86400)}d {int((delta%86400)//3600)}h"

def parse_time(s: str) -> int:
    """Parse '1d2h3m4s' -> seconds"""
    total = 0
    for val, unit in re.findall(r'(\d+)([dhms])', s.lower()):
        val = int(val)
        if unit == 'd': total += val * 86400
        elif unit == 'h': total += val * 3600
        elif unit == 'm': total += val * 60
        elif unit == 's': total += val
    return total

def format_seconds(sec: int) -> str:
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    parts = []
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    if s: parts.append(f"{s}s")
    return " ".join(parts) or "0s"

def success_embed(title, desc=None):
    e = discord.Embed(title=f"✅ {title}", description=desc, color=0x2ecc71)
    return e

def error_embed(title, desc=None):
    e = discord.Embed(title=f"❌ {title}", description=desc, color=0xe74c3c)
    return e

def info_embed(title, desc=None):
    e = discord.Embed(title=f"ℹ️ {title}", description=desc, color=0x3498db)
    return e

def warn_embed(title, desc=None):
    e = discord.Embed(title=f"⚠️ {title}", description=desc, color=0xf39c12)
    return e

# ── Anti-Spam Cache ────────────────────────────────────────────
spam_cache   = defaultdict(list)
mention_cache = defaultdict(list)
caps_cache   = defaultdict(list)

# ── Bot Events ─────────────────────────────────────────────────
@bot.event
async def on_ready():
    log.info(f"Logged in as {bot.user} ({bot.user.id})")
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"{len(bot.guilds)} servers | {PREFIX}help"
        )
    )
    reminder_check.start()
    giveaway_check.start()
    mute_check.start()
    log.info("Background tasks started.")
    try:
        synced = await bot.tree.sync()
        log.info(f"Synced {len(synced)} slash commands.")
    except Exception as e:
        log.error(f"Slash sync error: {e}")

@bot.event
async def on_guild_join(guild):
    log.info(f"Joined guild: {guild.name} ({guild.id})")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        # Check custom commands
        cmd = ctx.invoked_with.lower()
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT response FROM custom_commands WHERE guild_id=? AND name=?",
                      (str(ctx.guild.id), cmd))
            row = c.fetchone()
        if row:
            await ctx.send(row[0])
        return
    if isinstance(error, commands.MissingPermissions):
        await ctx.send(embed=error_embed("No Permission", f"You need: `{'`, `'.join(error.missing_permissions)}`"))
    elif isinstance(error, commands.BotMissingPermissions):
        await ctx.send(embed=error_embed("Bot Missing Permission", f"I need: `{'`, `'.join(error.missing_permissions)}`"))
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(embed=error_embed("Missing Argument", f"`{error.param.name}` is required.\nUsage: `{ctx.prefix}{ctx.command.qualified_name} {ctx.command.signature}`"))
    elif isinstance(error, commands.BadArgument):
        await ctx.send(embed=error_embed("Bad Argument", str(error)))
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(embed=warn_embed("Cooldown", f"Try again in **{error.retry_after:.1f}s**"))
    elif isinstance(error, commands.CheckFailure):
        await ctx.send(embed=error_embed("Check Failed", "You can't use this command."))
    else:
        log.error(f"Unhandled error in {ctx.command}: {error}")
        await ctx.send(embed=error_embed("Error", f"```{error}```"))

@bot.event
async def on_member_join(member):
    guild = member.guild
    s = get_settings(str(guild.id))

    # Welcome message
    wch_id = s.get("welcome_channel")
    if wch_id:
        wch = guild.get_channel(int(wch_id))
        if wch:
            msg = s.get("welcome_message", "Welcome {user} to **{server}**! You are member #{count}.")
            msg = msg.replace("{user}", member.mention) \
                     .replace("{server}", guild.name) \
                     .replace("{count}", str(guild.member_count)) \
                     .replace("{username}", member.name)
            e = discord.Embed(description=msg, color=0x2ecc71)
            e.set_thumbnail(url=member.display_avatar.url)
            await wch.send(embed=e)

    # Auto role
    ar_id = s.get("auto_role")
    if ar_id:
        role = guild.get_role(int(ar_id))
        if role:
            try:
                await member.add_roles(role, reason="Auto-role on join")
            except:
                pass

    # Log join
    with db() as conn:
        conn.execute(
            "INSERT INTO join_leave_log VALUES (?,?,?,?)",
            (str(guild.id), str(member.id), "join", datetime.datetime.utcnow().isoformat())
        )
        conn.commit()

@bot.event
async def on_member_remove(member):
    guild = member.guild
    s = get_settings(str(guild.id))

    # Goodbye message
    lch_id = s.get("leave_channel")
    if lch_id:
        lch = guild.get_channel(int(lch_id))
        if lch:
            msg = s.get("leave_message", "**{username}** has left **{server}**. Goodbye!")
            msg = msg.replace("{username}", member.name) \
                     .replace("{server}", guild.name)
            e = discord.Embed(description=msg, color=0xe74c3c)
            e.set_thumbnail(url=member.display_avatar.url)
            await lch.send(embed=e)

    with db() as conn:
        conn.execute(
            "INSERT INTO join_leave_log VALUES (?,?,?,?)",
            (str(guild.id), str(member.id), "leave", datetime.datetime.utcnow().isoformat())
        )
        conn.commit()

@bot.event
async def on_message(message):
    if message.author.bot or not message.guild:
        return

    guild_id = str(message.guild.id)
    user_id  = str(message.author.id)
    s = get_settings(guild_id)

    # ── AFK check ─────────────────────────────────────────────
    with db() as conn:
        c = conn.cursor()
        c.execute("SELECT reason, timestamp FROM afk WHERE guild_id=? AND user_id=?",
                  (guild_id, user_id))
        afk_row = c.fetchone()
    if afk_row:
        with db() as conn:
            conn.execute("DELETE FROM afk WHERE guild_id=? AND user_id=?", (guild_id, user_id))
            conn.commit()
        await message.channel.send(
            embed=success_embed("Welcome Back!", f"Your AFK has been removed.\nReason was: {afk_row[0]}"),
            delete_after=5
        )

    # ── Ping AFK users ────────────────────────────────────────
    if message.mentions:
        for mentioned in message.mentions:
            with db() as conn:
                c = conn.cursor()
                c.execute("SELECT reason, timestamp FROM afk WHERE guild_id=? AND user_id=?",
                          (guild_id, str(mentioned.id)))
                row = c.fetchone()
            if row:
                await message.channel.send(
                    embed=info_embed("User is AFK",
                        f"{mentioned.mention} is AFK: **{row[0]}**\nSince: {row[1][:16]}"),
                    delete_after=8
                )

    # ── Auto-respond ──────────────────────────────────────────
    with db() as conn:
        c = conn.cursor()
        c.execute("SELECT trigger, response FROM autorespond WHERE guild_id=?", (guild_id,))
        ar_rows = c.fetchall()
    for trigger, response in ar_rows:
        if trigger.lower() in message.content.lower():
            resp = response.replace("{user}", message.author.mention) \
                           .replace("{server}", message.guild.name)
            await message.channel.send(resp)
            break

    # ── Anti-Spam ─────────────────────────────────────────────
    if s.get("antispam"):
        now = time.time()
        key = f"{guild_id}:{user_id}"
        spam_cache[key].append(now)
        spam_cache[key] = [t for t in spam_cache[key] if now - t < 5]
        if len(spam_cache[key]) >= int(s.get("antispam_limit", 5)):
            try:
                await message.author.timeout(datetime.timedelta(minutes=5), reason="Auto: Spam detected")
                await message.channel.send(
                    embed=warn_embed("Anti-Spam", f"{message.author.mention} muted for spamming."),
                    delete_after=10
                )
                spam_cache[key] = []
            except:
                pass

    # ── Anti Caps ─────────────────────────────────────────────
    if s.get("anticaps") and len(message.content) > 10:
        caps_ratio = sum(1 for c in message.content if c.isupper()) / len(message.content)
        if caps_ratio > 0.7:
            try:
                await message.delete()
                await message.channel.send(
                    embed=warn_embed("Anti-Caps", f"{message.author.mention}, no excessive CAPS!"),
                    delete_after=5
                )
            except:
                pass
            await bot.process_commands(message)
            return

    # ── Anti Invite ───────────────────────────────────────────
    if s.get("antiinvite"):
        if re.search(r'discord\.gg/\w+|discordapp\.com/invite/\w+', message.content, re.I):
            if not message.author.guild_permissions.manage_messages:
                try:
                    await message.delete()
                    await message.channel.send(
                        embed=warn_embed("Anti-Invite", f"{message.author.mention}, no invite links!"),
                        delete_after=5
                    )
                except:
                    pass
                await bot.process_commands(message)
                return

    # ── Anti Links ────────────────────────────────────────────
    if s.get("antilinks"):
        if re.search(r'https?://\S+', message.content):
            if not message.author.guild_permissions.manage_messages:
                try:
                    await message.delete()
                    await message.channel.send(
                        embed=warn_embed("Anti-Links", f"{message.author.mention}, no links allowed!"),
                        delete_after=5
                    )
                except:
                    pass
                await bot.process_commands(message)
                return

    # ── XP System ─────────────────────────────────────────────
    if s.get("xp_enabled") and not message.content.startswith(PREFIX):
        xp_gain = random.randint(10, 25)
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT xp, level FROM xp WHERE guild_id=? AND user_id=?", (guild_id, user_id))
            row = c.fetchone()
            if row:
                new_xp = row[0] + xp_gain
                new_level = row[1]
                needed = 100 * (new_level + 1) * (new_level + 1)
                leveled_up = False
                if new_xp >= needed:
                    new_level += 1
                    leveled_up = True
                conn.execute(
                    "UPDATE xp SET xp=?, level=?, messages=messages+1 WHERE guild_id=? AND user_id=?",
                    (new_xp, new_level, guild_id, user_id)
                )
                if leveled_up:
                    lup_ch_id = s.get("level_channel", str(message.channel.id))
                    lup_ch = message.guild.get_channel(int(lup_ch_id))
                    if lup_ch:
                        lup_role_id = s.get(f"level_role_{new_level}")
                        lup_msg = f"🎉 {message.author.mention} reached **Level {new_level}**!"
                        if lup_role_id:
                            role = message.guild.get_role(int(lup_role_id))
                            if role:
                                await message.author.add_roles(role)
                                lup_msg += f" Earned role: {role.mention}"
                        await lup_ch.send(embed=success_embed("Level Up!", lup_msg))
            else:
                conn.execute(
                    "INSERT INTO xp (guild_id, user_id, xp, level, messages) VALUES (?,?,?,0,1)",
                    (guild_id, user_id, xp_gain)
                )
            conn.commit()

    # ── Economy daily message coins ───────────────────────────
    if s.get("economy_enabled") and random.random() < 0.1:
        coins = random.randint(1, 10)
        with db() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO economy (guild_id, user_id) VALUES (?,?)",
                (guild_id, user_id)
            )
            conn.execute(
                "UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",
                (coins, guild_id, user_id)
            )
            conn.commit()

    # ── Log messages ──────────────────────────────────────────
    if s.get("log_messages"):
        with db() as conn:
            conn.execute(
                "INSERT INTO message_log VALUES (?,?,?,?,?,?)",
                (guild_id, str(message.id), user_id,
                 str(message.channel.id), message.content[:2000],
                 datetime.datetime.utcnow().isoformat())
            )
            conn.commit()

    await bot.process_commands(message)

@bot.event
async def on_message_delete(message):
    if message.author.bot or not message.guild:
        return
    guild_id = str(message.guild.id)
    s = get_settings(guild_id)
    lch_id = s.get("log_channel")
    if lch_id:
        lch = message.guild.get_channel(int(lch_id))
        if lch:
            e = discord.Embed(
                title="🗑️ Message Deleted",
                color=0xe74c3c,
                timestamp=datetime.datetime.utcnow()
            )
            e.add_field(name="Author", value=message.author.mention)
            e.add_field(name="Channel", value=message.channel.mention)
            e.add_field(name="Content", value=message.content[:1024] or "*empty*", inline=False)
            await lch.send(embed=e)

@bot.event
async def on_message_edit(before, after):
    if before.author.bot or not before.guild or before.content == after.content:
        return
    guild_id = str(before.guild.id)
    s = get_settings(guild_id)
    lch_id = s.get("log_channel")
    if lch_id:
        lch = before.guild.get_channel(int(lch_id))
        if lch:
            e = discord.Embed(
                title="✏️ Message Edited",
                color=0xf39c12,
                timestamp=datetime.datetime.utcnow()
            )
            e.add_field(name="Author", value=before.author.mention)
            e.add_field(name="Channel", value=before.channel.mention)
            e.add_field(name="Before", value=before.content[:512] or "*empty*", inline=False)
            e.add_field(name="After",  value=after.content[:512]  or "*empty*", inline=False)
            e.add_field(name="Jump", value=f"[Click]({after.jump_url})")
            await lch.send(embed=e)

@bot.event
async def on_member_update(before, after):
    guild_id = str(before.guild.id)
    s = get_settings(guild_id)
    lch_id = s.get("log_channel")
    if not lch_id:
        return
    lch = before.guild.get_channel(int(lch_id))
    if not lch:
        return

    if before.nick != after.nick:
        e = discord.Embed(title="📝 Nickname Changed", color=0x9b59b6, timestamp=datetime.datetime.utcnow())
        e.add_field(name="Member", value=after.mention)
        e.add_field(name="Before", value=before.nick or before.name)
        e.add_field(name="After",  value=after.nick  or after.name)
        await lch.send(embed=e)

    if before.roles != after.roles:
        added   = [r for r in after.roles  if r not in before.roles]
        removed = [r for r in before.roles if r not in after.roles]
        if added or removed:
            e = discord.Embed(title="🎭 Roles Updated", color=0x1abc9c, timestamp=datetime.datetime.utcnow())
            e.add_field(name="Member", value=after.mention)
            if added:   e.add_field(name="Added",   value=" ".join(r.mention for r in added))
            if removed: e.add_field(name="Removed", value=" ".join(r.mention for r in removed))
            await lch.send(embed=e)

@bot.event
async def on_voice_state_update(member, before, after):
    guild_id = str(member.guild.id)
    s = get_settings(guild_id)

    # Temp Voice Channels
    vc_hub = s.get("temp_vc_hub")
    if vc_hub and after.channel and str(after.channel.id) == str(vc_hub):
        category = after.channel.category
        try:
            new_vc = await member.guild.create_voice_channel(
                name=f"🎙️ {member.display_name}'s Room",
                category=category
            )
            await member.move_to(new_vc)
            with db() as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO temp_channels VALUES (?,?,?)",
                    (guild_id, str(new_vc.id), str(member.id))
                )
                conn.commit()
        except:
            pass

    # Delete empty temp channels
    if before.channel:
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT owner_id FROM temp_channels WHERE guild_id=? AND channel_id=?",
                      (guild_id, str(before.channel.id)))
            row = c.fetchone()
        if row and len(before.channel.members) == 0:
            try:
                await before.channel.delete(reason="Empty temp VC")
                with db() as conn:
                    conn.execute("DELETE FROM temp_channels WHERE guild_id=? AND channel_id=?",
                                 (guild_id, str(before.channel.id)))
                    conn.commit()
            except:
                pass

@bot.event
async def on_raw_reaction_add(payload):
    if not payload.guild_id:
        return
    guild_id = str(payload.guild_id)

    # ── Reaction Roles ────────────────────────────────────────
    emoji = str(payload.emoji)
    with db() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT role_id FROM reaction_roles WHERE guild_id=? AND message_id=? AND emoji=?",
            (guild_id, str(payload.message_id), emoji)
        )
        row = c.fetchone()
    if row:
        guild = bot.get_guild(payload.guild_id)
        member = guild.get_member(payload.user_id)
        if member and not member.bot:
            role = guild.get_role(int(row[0]))
            if role:
                await member.add_roles(role, reason="Reaction role")

    # ── Starboard ─────────────────────────────────────────────
    s = get_settings(guild_id)
    star_ch_id = s.get("starboard_channel")
    star_emoji = s.get("starboard_emoji", "⭐")
    star_count = int(s.get("starboard_count", 3))
    if star_ch_id and str(payload.emoji) == star_emoji:
        guild = bot.get_guild(payload.guild_id)
        channel = guild.get_channel(payload.channel_id)
        try:
            msg = await channel.fetch_message(payload.message_id)
            stars = sum(r.count for r in msg.reactions if str(r.emoji) == star_emoji)
            star_ch = guild.get_channel(int(star_ch_id))
            with db() as conn:
                c = conn.cursor()
                c.execute("SELECT star_msg_id FROM starboard WHERE guild_id=? AND message_id=?",
                          (guild_id, str(msg.id)))
                row = c.fetchone()
            if stars >= star_count:
                e = discord.Embed(
                    description=msg.content or "*[No text]*",
                    color=0xf1c40f,
                    timestamp=msg.created_at
                )
                e.set_author(name=msg.author.display_name, icon_url=msg.author.display_avatar.url)
                e.add_field(name="Source", value=f"[Jump]({msg.jump_url})")
                e.set_footer(text=f"⭐ {stars}")
                if msg.attachments:
                    e.set_image(url=msg.attachments[0].url)
                if row:
                    try:
                        sm = await star_ch.fetch_message(int(row[0]))
                        await sm.edit(embed=e)
                        with db() as conn:
                            conn.execute("UPDATE starboard SET stars=? WHERE guild_id=? AND message_id=?",
                                         (stars, guild_id, str(msg.id)))
                            conn.commit()
                    except:
                        pass
                else:
                    sm = await star_ch.send(embed=e)
                    with db() as conn:
                        conn.execute(
                            "INSERT INTO starboard VALUES (?,?,?,?)",
                            (guild_id, str(msg.id), str(sm.id), stars)
                        )
                        conn.commit()
        except:
            pass

@bot.event
async def on_raw_reaction_remove(payload):
    if not payload.guild_id:
        return
    guild_id = str(payload.guild_id)
    emoji = str(payload.emoji)
    with db() as conn:
        c = conn.cursor()
        c.execute(
            "SELECT role_id FROM reaction_roles WHERE guild_id=? AND message_id=? AND emoji=?",
            (guild_id, str(payload.message_id), emoji)
        )
        row = c.fetchone()
    if row:
        guild = bot.get_guild(payload.guild_id)
        member = guild.get_member(payload.user_id)
        if member and not member.bot:
            role = guild.get_role(int(row[0]))
            if role:
                await member.remove_roles(role, reason="Reaction role removed")

# ── Background Tasks ───────────────────────────────────────────
@tasks.loop(seconds=30)
async def reminder_check():
    now = datetime.datetime.utcnow().isoformat()
    with db() as conn:
        c = conn.cursor()
        c.execute("SELECT id, user_id, channel_id, message FROM reminders WHERE done=0 AND remind_at<=?", (now,))
        rows = c.fetchall()
    for rid, uid, ch_id, msg in rows:
        ch = bot.get_channel(int(ch_id))
        if ch:
            try:
                await ch.send(f"⏰ <@{uid}> Reminder: **{msg}**")
            except:
                pass
        with db() as conn:
            conn.execute("UPDATE reminders SET done=1 WHERE id=?", (rid,))
            conn.commit()

@tasks.loop(seconds=60)
async def giveaway_check():
    now = datetime.datetime.utcnow().isoformat()
    with db() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM giveaways WHERE ended=0 AND ends_at<=?", (now,))
        rows = c.fetchall()
    for row in rows:
        (gid, guild_id, ch_id, msg_id, host_id, prize, winners, ends_at, ended, entries_json) = row
        entries = json.loads(entries_json)
        guild = bot.get_guild(int(guild_id))
        ch    = bot.get_channel(int(ch_id)) if guild else None
        if not ch:
            continue
        if len(entries) == 0:
            await ch.send(embed=error_embed("Giveaway Ended", f"No valid entries for **{prize}**!"))
        else:
            actual_winners = min(winners, len(entries))
            won = random.sample(entries, actual_winners)
            mentions = " ".join(f"<@{w}>" for w in won)
            e = discord.Embed(title="🎉 Giveaway Ended!", color=0xf1c40f)
            e.add_field(name="Prize",   value=prize)
            e.add_field(name="Winners", value=mentions)
            e.add_field(name="Host",    value=f"<@{host_id}>")
            await ch.send(embed=e)
        with db() as conn:
            conn.execute("UPDATE giveaways SET ended=1 WHERE id=?", (gid,))
            conn.commit()

@tasks.loop(seconds=60)
async def mute_check():
    now = datetime.datetime.utcnow().isoformat()
    with db() as conn:
        c = conn.cursor()
        c.execute("SELECT guild_id, user_id FROM mutes WHERE expires<=?", (now,))
        rows = c.fetchall()
    for guild_id, user_id in rows:
        guild = bot.get_guild(int(guild_id))
        if guild:
            member = guild.get_member(int(user_id))
            if member:
                try:
                    await member.timeout(None, reason="Mute expired")
                except:
                    pass
        with db() as conn:
            conn.execute("DELETE FROM mutes WHERE guild_id=? AND user_id=?", (guild_id, user_id))
            conn.commit()

# ── Load Cogs ──────────────────────────────────────────────────
async def load_cogs():
    cogs = [
        "cogs.moderation",
        "cogs.admin",
        "cogs.utility",
        "cogs.fun",
        "cogs.economy",
        "cogs.leveling",
        "cogs.tickets",
        "cogs.giveaway",
        "cogs.info",
        "cogs.config",
        "cogs.music",
        "cogs.games",
        "cogs.tags",
        "cogs.help",
    ]
    for cog in cogs:
        try:
            await bot.load_extension(cog)
            log.info(f"Loaded: {cog}")
        except Exception as e:
            log.error(f"Failed to load {cog}: {e}")

async def main():
    async with bot:
        await load_cogs()
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
