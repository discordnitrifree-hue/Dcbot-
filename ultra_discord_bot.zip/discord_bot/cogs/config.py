"""CONFIG COG"""
import discord, json, sqlite3
from discord.ext import commands

def db(): return sqlite3.connect("ultrabot.db")
def s(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)
def e(t,d=None): return discord.Embed(title=f"❌ {t}",description=d,color=0xe74c3c)
def i(t,d=None): return discord.Embed(title=f"ℹ️ {t}",description=d,color=0x3498db)

def get_settings(gid):
    with db() as conn:
        c=conn.cursor()
        c.execute("SELECT settings FROM guild_settings WHERE guild_id=?",(gid,))
        row=c.fetchone()
        return json.loads(row[0]) if row else {}

def update_setting(gid,key,value):
    settings=get_settings(gid)
    settings[key]=value
    with db() as conn:
        conn.execute("INSERT OR REPLACE INTO guild_settings VALUES (?,?)",(gid,json.dumps(settings)))
        conn.commit()

class Config(commands.Cog):
    """⚙️ Config & Setup"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="config",aliases=["cfg"],help="View bot configuration")
    async def config_cmd(self,ctx):
        settings=get_settings(str(ctx.guild.id))
        em=discord.Embed(title=f"⚙️ Bot Config — {ctx.guild.name}",color=0x3498db)
        def ch(cid): return f"<#{cid}>" if cid else "❌ Not set"
        def ro(rid): return f"<@&{rid}>" if rid else "❌ Not set"
        def yn(v): return "✅ ON" if v else "❌ OFF"
        em.add_field(name="📥 Welcome Channel",value=ch(settings.get("welcome_channel")))
        em.add_field(name="📤 Leave Channel",value=ch(settings.get("leave_channel")))
        em.add_field(name="📋 Log Channel",value=ch(settings.get("log_channel")))
        em.add_field(name="🎭 Auto Role",value=ro(settings.get("auto_role")))
        em.add_field(name="🔧 Prefix",value=f"`{settings.get('prefix','!')}`")
        em.add_field(name="⭐ XP System",value=yn(settings.get("xp_enabled")))
        em.add_field(name="💰 Economy",value=yn(settings.get("economy_enabled")))
        em.add_field(name="🛡️ Anti-Spam",value=yn(settings.get("antispam")))
        em.add_field(name="🔠 Anti-Caps",value=yn(settings.get("anticaps")))
        em.add_field(name="🔗 Anti-Invite",value=yn(settings.get("antiinvite")))
        em.add_field(name="🌐 Anti-Links",value=yn(settings.get("antilinks")))
        em.add_field(name="⭐ Starboard",value=ch(settings.get("starboard_channel")))
        em.add_field(name="🎙️ Temp VC Hub",value=ch(settings.get("temp_vc_hub")))
        em.add_field(name="📩 Log Messages",value=yn(settings.get("log_messages")))
        em.set_footer(text="Use !setup for configuration guide")
        await ctx.send(embed=em)

    @commands.command(name="enablemodule",help="Enable a module")
    @commands.has_permissions(administrator=True)
    async def enablemodule(self,ctx,module:str):
        modules={"xp":"xp_enabled","economy":"economy_enabled","antispam":"antispam","anticaps":"anticaps","antiinvite":"antiinvite","antilinks":"antilinks","logmessages":"log_messages"}
        if module.lower() not in modules:
            return await ctx.send(embed=e("Unknown Module",f"Available: {', '.join(modules.keys())}"))
        update_setting(str(ctx.guild.id),modules[module.lower()],True)
        await ctx.send(embed=s(f"Module Enabled",f"`{module}` is now enabled."))

    @commands.command(name="disablemodule",help="Disable a module")
    @commands.has_permissions(administrator=True)
    async def disablemodule(self,ctx,module:str):
        modules={"xp":"xp_enabled","economy":"economy_enabled","antispam":"antispam","anticaps":"anticaps","antiinvite":"antiinvite","antilinks":"antilinks","logmessages":"log_messages"}
        if module.lower() not in modules:
            return await ctx.send(embed=e("Unknown Module",f"Available: {', '.join(modules.keys())}"))
        update_setting(str(ctx.guild.id),modules[module.lower()],False)
        await ctx.send(embed=s(f"Module Disabled",f"`{module}` is now disabled."))

    @commands.command(name="exportconfig",help="Export server config as JSON")
    @commands.has_permissions(administrator=True)
    async def exportconfig(self,ctx):
        settings=get_settings(str(ctx.guild.id))
        import io
        data=json.dumps(settings,indent=2)
        file=discord.File(io.StringIO(data),filename="config.json")
        await ctx.send("📦 Here's your config export:",file=file)

    @commands.command(name="importconfig",help="Import config from JSON attachment")
    @commands.has_permissions(administrator=True)
    async def importconfig(self,ctx):
        if not ctx.message.attachments:
            return await ctx.send(embed=e("No Attachment","Attach a config JSON file."))
        import aiohttp, io
        async with aiohttp.ClientSession() as session:
            async with session.get(ctx.message.attachments[0].url) as r:
                data=await r.text()
        try:
            settings=json.loads(data)
            with db() as conn:
                conn.execute("INSERT OR REPLACE INTO guild_settings VALUES (?,?)",(str(ctx.guild.id),json.dumps(settings)))
                conn.commit()
            await ctx.send(embed=s("Config Imported","Settings applied successfully."))
        except:
            await ctx.send(embed=e("Invalid JSON","Could not parse config file."))

async def setup(bot):
    await bot.add_cog(Config(bot))
