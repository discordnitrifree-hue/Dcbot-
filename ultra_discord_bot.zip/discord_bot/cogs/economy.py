"""
ECONOMY COG
"""
import discord
from discord.ext import commands
import datetime, random, sqlite3
from typing import Optional

def db(): return sqlite3.connect("ultrabot.db")
def s(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)
def e(t,d=None): return discord.Embed(title=f"❌ {t}",description=d,color=0xe74c3c)
def i(t,d=None): return discord.Embed(title=f"ℹ️ {t}",description=d,color=0x3498db)

def ensure_account(guild_id,user_id):
    with db() as conn:
        conn.execute("INSERT OR IGNORE INTO economy VALUES (?,?,0,0)",(guild_id,user_id))
        conn.commit()

def get_bal(guild_id,user_id):
    ensure_account(guild_id,user_id)
    with db() as conn:
        c=conn.cursor()
        c.execute("SELECT wallet,bank FROM economy WHERE guild_id=? AND user_id=?",(guild_id,user_id))
        return c.fetchone()

class Economy(commands.Cog):
    """💰 Economy System"""
    def __init__(self,bot):
        self.bot=bot
        self.daily_cooldown={}
        self.work_cooldown={}
        self.crime_cooldown={}
        self.beg_cooldown={}

    @commands.command(name="balance",aliases=["bal","wallet"],help="Check your balance")
    async def balance(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        gid,uid=str(ctx.guild.id),str(m.id)
        wallet,bank=get_bal(gid,uid)
        em=discord.Embed(title=f"💰 {m.display_name}'s Balance",color=0xf1c40f)
        em.add_field(name="👛 Wallet",value=f"${wallet:,}")
        em.add_field(name="🏦 Bank",value=f"${bank:,}")
        em.add_field(name="💎 Net Worth",value=f"${wallet+bank:,}")
        em.set_thumbnail(url=m.display_avatar.url)
        await ctx.send(embed=em)

    @commands.command(name="daily",help="Claim your daily reward")
    async def daily(self,ctx):
        uid=str(ctx.author.id)
        now=datetime.datetime.utcnow()
        last=self.daily_cooldown.get(uid)
        if last and (now-last).total_seconds()<86400:
            remaining=86400-(now-last).total_seconds()
            h,r=divmod(int(remaining),3600); m,s=divmod(r,60)
            return await ctx.send(embed=e("Cooldown",f"Next daily in `{h}h {m}m {s}s`"))
        amount=random.randint(100,500)
        gid,uid=str(ctx.guild.id),str(ctx.author.id)
        ensure_account(gid,uid)
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
            conn.commit()
        self.daily_cooldown[uid]=now
        await ctx.send(embed=s("Daily Claimed!",f"You received **${amount:,}**! Come back tomorrow."))

    @commands.command(name="work",help="Work to earn coins")
    async def work(self,ctx):
        uid=str(ctx.author.id)
        now=datetime.datetime.utcnow()
        last=self.work_cooldown.get(uid)
        if last and (now-last).total_seconds()<3600:
            rem=3600-(now-last).total_seconds()
            return await ctx.send(embed=e("Cooldown",f"Work again in `{int(rem//60)}m`"))
        jobs=["programmer","chef","teacher","doctor","driver","plumber","artist","designer","streamer","trader"]
        job=random.choice(jobs)
        amount=random.randint(50,200)
        gid=str(ctx.guild.id)
        ensure_account(gid,uid)
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
            conn.commit()
        self.work_cooldown[uid]=now
        await ctx.send(embed=s("Work Done!",f"You worked as a **{job}** and earned **${amount:,}**!"))

    @commands.command(name="crime",help="Commit crime for big reward (or get fined)")
    async def crime(self,ctx):
        uid=str(ctx.author.id)
        now=datetime.datetime.utcnow()
        last=self.crime_cooldown.get(uid)
        if last and (now-last).total_seconds()<7200:
            rem=7200-(now-last).total_seconds()
            return await ctx.send(embed=e("Cooldown",f"Crime again in `{int(rem//60)}m`"))
        gid=str(ctx.guild.id)
        ensure_account(gid,uid)
        self.crime_cooldown[uid]=now
        if random.random()<0.6:
            amount=random.randint(200,600)
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
                conn.commit()
            await ctx.send(embed=s("Crime Successful! 🦹",f"You got away with **${amount:,}**!"))
        else:
            fine=random.randint(100,300)
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=MAX(0,wallet-?) WHERE guild_id=? AND user_id=?",(fine,gid,uid))
                conn.commit()
            await ctx.send(embed=e("Caught! 👮",f"You were caught and fined **${fine:,}**!"))

    @commands.command(name="beg",help="Beg for coins")
    async def beg(self,ctx):
        uid=str(ctx.author.id)
        now=datetime.datetime.utcnow()
        last=self.beg_cooldown.get(uid)
        if last and (now-last).total_seconds()<300:
            return await ctx.send(embed=e("Cooldown","Beg again in 5 minutes."))
        self.beg_cooldown[uid]=now
        if random.random()<0.7:
            amount=random.randint(1,50)
            gid=str(ctx.guild.id)
            ensure_account(gid,uid)
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
                conn.commit()
            phrases=["Someone felt pity on you.","A generous soul helped.","Luck was on your side!"]
            await ctx.send(embed=s("Begging...",f"{random.choice(phrases)} You got **${amount}**."))
        else:
            await ctx.send(embed=e("No Luck","Nobody gave you anything. 😢"))

    @commands.command(name="deposit",aliases=["dep"],help="Deposit money to bank")
    async def deposit(self,ctx,amount:str):
        gid,uid=str(ctx.guild.id),str(ctx.author.id)
        wallet,bank=get_bal(gid,uid)
        amt=wallet if amount.lower()=="all" else int(amount)
        if amt<=0 or amt>wallet:
            return await ctx.send(embed=e("Invalid",f"You have ${wallet:,} in wallet."))
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=wallet-?,bank=bank+? WHERE guild_id=? AND user_id=?",(amt,amt,gid,uid))
            conn.commit()
        await ctx.send(embed=s("Deposited",f"Deposited **${amt:,}** to bank. Balance: ${bank+amt:,}"))

    @commands.command(name="withdraw",aliases=["with"],help="Withdraw from bank")
    async def withdraw(self,ctx,amount:str):
        gid,uid=str(ctx.guild.id),str(ctx.author.id)
        wallet,bank=get_bal(gid,uid)
        amt=bank if amount.lower()=="all" else int(amount)
        if amt<=0 or amt>bank:
            return await ctx.send(embed=e("Invalid",f"You have ${bank:,} in bank."))
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=wallet+?,bank=bank-? WHERE guild_id=? AND user_id=?",(amt,amt,gid,uid))
            conn.commit()
        await ctx.send(embed=s("Withdrawn",f"Withdrew **${amt:,}** to wallet. Wallet: ${wallet+amt:,}"))

    @commands.command(name="pay",aliases=["give","transfer"],help="Pay another member")
    async def pay(self,ctx,member:discord.Member,amount:int):
        if member==ctx.author: return await ctx.send(embed=e("Invalid","Can't pay yourself."))
        if amount<=0: return await ctx.send(embed=e("Invalid","Amount must be positive."))
        gid=str(ctx.guild.id)
        uid=str(ctx.author.id)
        tid=str(member.id)
        wallet,_=get_bal(gid,uid)
        if amount>wallet: return await ctx.send(embed=e("Insufficient Funds",f"You only have ${wallet:,}."))
        ensure_account(gid,tid)
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=wallet-? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
            conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(amount,gid,tid))
            conn.commit()
        await ctx.send(embed=s("Transfer Complete",f"Sent **${amount:,}** to {member.mention}."))

    @commands.command(name="leaderboard",aliases=["lb","rich"],help="Economy leaderboard")
    async def leaderboard(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT user_id,wallet+bank as net FROM economy WHERE guild_id=? ORDER BY net DESC LIMIT 10",(str(ctx.guild.id),))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=i("Empty Leaderboard"))
        medals=["🥇","🥈","🥉"]
        desc="\n".join(
            f"{medals[idx] if idx<3 else f'`{idx+1}.`'} <@{uid}> — **${net:,}**"
            for idx,(uid,net) in enumerate(rows)
        )
        await ctx.send(embed=discord.Embed(title="💰 Economy Leaderboard",description=desc,color=0xf1c40f))

    @commands.command(name="rob",help="Rob another member")
    async def rob(self,ctx,member:discord.Member):
        if member==ctx.author: return await ctx.send(embed=e("Invalid","Can't rob yourself."))
        gid=str(ctx.guild.id)
        uid=str(ctx.author.id)
        tid=str(member.id)
        your_wallet,_=get_bal(gid,uid)
        their_wallet,_=get_bal(gid,tid)
        if their_wallet<100: return await ctx.send(embed=e("Too Poor",f"{member.mention} has less than $100."))
        if your_wallet<50:   return await ctx.send(embed=e("Too Poor","You need at least $50 to rob."))
        if random.random()<0.45:
            stolen=random.randint(50,min(500,their_wallet))
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(stolen,gid,uid))
                conn.execute("UPDATE economy SET wallet=MAX(0,wallet-?) WHERE guild_id=? AND user_id=?",(stolen,gid,tid))
                conn.commit()
            await ctx.send(embed=s("Robbery Successful! 🦹",f"You stole **${stolen:,}** from {member.mention}!"))
        else:
            fine=random.randint(50,200)
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=MAX(0,wallet-?) WHERE guild_id=? AND user_id=?",(fine,gid,uid))
                conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(fine,gid,tid))
                conn.commit()
            await ctx.send(embed=e("Caught! 👮",f"You were caught trying to rob {member.mention} and fined **${fine:,}**!"))

    @commands.command(name="slots",help="Play slots. !slots 100")
    async def slots(self,ctx,bet:int):
        gid,uid=str(ctx.guild.id),str(ctx.author.id)
        wallet,_=get_bal(gid,uid)
        if bet<=0 or bet>wallet: return await ctx.send(embed=e("Invalid Bet",f"You have ${wallet:,}."))
        symbols=["🍒","🍊","🍋","⭐","🔔","💎","7️⃣","🍀"]
        weights=[30,25,20,12,8,3,1,1]
        s1,s2,s3=random.choices(symbols,weights=weights,k=3)
        
        if s1==s2==s3:
            mult={"💎":50,"7️⃣":30,"🍀":20,"🔔":10,"⭐":8}.get(s1,5)
            won=bet*mult
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(won,gid,uid))
                conn.commit()
            result=f"**JACKPOT!** Won **${won:,}**! (x{mult})"
            color=0xf1c40f
        elif s1==s2 or s2==s3 or s1==s3:
            won=int(bet*1.5)
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(int(won-bet),gid,uid))
                conn.commit()
            result=f"**Two of a kind!** Won **${won:,}**!"
            color=0x2ecc71
        else:
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet-? WHERE guild_id=? AND user_id=?",(bet,gid,uid))
                conn.commit()
            result=f"You lost **${bet:,}**."
            color=0xe74c3c
        
        em=discord.Embed(title="🎰 Slot Machine",color=color)
        em.add_field(name="Result",value=f"| {s1} | {s2} | {s3} |",inline=False)
        em.add_field(name="Outcome",value=result,inline=False)
        await ctx.send(embed=em)

    @commands.command(name="coinflipbet",aliases=["cfbet"],help="Bet on coin flip. !cfbet 100 heads")
    async def coinflipbet(self,ctx,bet:int,choice:str):
        gid,uid=str(ctx.guild.id),str(ctx.author.id)
        wallet,_=get_bal(gid,uid)
        if bet<=0 or bet>wallet: return await ctx.send(embed=e("Invalid Bet",f"You have ${wallet:,}."))
        choice=choice.lower()
        if choice not in ("heads","tails","h","t"): return await ctx.send(embed=e("Invalid","Choose heads or tails."))
        result=random.choice(["heads","tails"])
        win=choice in (result,result[0])
        if win:
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(bet,gid,uid))
                conn.commit()
            await ctx.send(embed=s(f"🪙 {result.title()}!",f"You won **${bet:,}**!"))
        else:
            with db() as conn:
                conn.execute("UPDATE economy SET wallet=wallet-? WHERE guild_id=? AND user_id=?",(bet,gid,uid))
                conn.commit()
            await ctx.send(embed=e(f"🪙 {result.title()}!",f"You lost **${bet:,}**."))

    @commands.command(name="addmoney",help="[ADMIN] Add money to user")
    @commands.has_permissions(administrator=True)
    async def addmoney(self,ctx,member:discord.Member,amount:int):
        gid,uid=str(ctx.guild.id),str(member.id)
        ensure_account(gid,uid)
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
            conn.commit()
        await ctx.send(embed=s("Money Added",f"Added **${amount:,}** to {member.mention}."))

    @commands.command(name="removemoney",help="[ADMIN] Remove money from user")
    @commands.has_permissions(administrator=True)
    async def removemoney(self,ctx,member:discord.Member,amount:int):
        gid,uid=str(ctx.guild.id),str(member.id)
        ensure_account(gid,uid)
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=MAX(0,wallet-?) WHERE guild_id=? AND user_id=?",(amount,gid,uid))
            conn.commit()
        await ctx.send(embed=s("Money Removed",f"Removed **${amount:,}** from {member.mention}."))

    @commands.command(name="resetmoney",help="[ADMIN] Reset user economy")
    @commands.has_permissions(administrator=True)
    async def resetmoney(self,ctx,member:discord.Member):
        gid,uid=str(ctx.guild.id),str(member.id)
        with db() as conn:
            conn.execute("UPDATE economy SET wallet=0,bank=0 WHERE guild_id=? AND user_id=?",(gid,uid))
            conn.commit()
        await ctx.send(embed=s("Reset",f"{member.mention}'s economy reset."))

async def setup(bot):
    await bot.add_cog(Economy(bot))
