"""
UTILITY COG - Utility Commands
"""
import discord
from discord.ext import commands
import datetime, random, asyncio, sqlite3, re
from typing import Optional

def db(): return sqlite3.connect("ultrabot.db")
def success_embed(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)
def error_embed(t,d=None):   return discord.Embed(title=f"❌ {t}",description=d,color=0xe74c3c)
def info_embed(t,d=None):    return discord.Embed(title=f"ℹ️ {t}",description=d,color=0x3498db)
def warn_embed(t,d=None):    return discord.Embed(title=f"⚠️ {t}",description=d,color=0xf39c12)

def parse_time(s):
    total=0
    for v,u in re.findall(r'(\d+)([dhms])',s.lower()):
        v=int(v)
        if u=='d': total+=v*86400
        elif u=='h': total+=v*3600
        elif u=='m': total+=v*60
        elif u=='s': total+=v
    return total

def format_seconds(sec):
    d,r=divmod(sec,86400); h,r=divmod(r,3600); m,s=divmod(r,60)
    p=[]
    if d: p.append(f"{d}d")
    if h: p.append(f"{h}h")
    if m: p.append(f"{m}m")
    if s: p.append(f"{s}s")
    return " ".join(p) or "0s"

class Utility(commands.Cog):
    """🔧 Utility - Helpful Tools"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="afk",help="Set your AFK status")
    async def afk(self,ctx,*,reason="AFK"):
        with db() as conn:
            conn.execute("INSERT OR REPLACE INTO afk VALUES (?,?,?,?)",
                (str(ctx.guild.id),str(ctx.author.id),reason,datetime.datetime.utcnow().isoformat()))
            conn.commit()
        await ctx.send(embed=success_embed("AFK Set",f"You are now AFK: **{reason}**"))

    @commands.command(name="remind",aliases=["reminder"],help="Set a reminder. !remind 10m Buy milk")
    async def remind(self,ctx,time:str,*,message:str):
        secs=parse_time(time)
        if not secs: return await ctx.send(embed=error_embed("Invalid Time","Use 1d, 2h, 30m, 45s"))
        remind_at=(datetime.datetime.utcnow()+datetime.timedelta(seconds=secs)).isoformat()
        with db() as conn:
            conn.execute("INSERT INTO reminders (user_id,guild_id,channel_id,remind_at,message) VALUES (?,?,?,?,?)",
                (str(ctx.author.id),str(ctx.guild.id),str(ctx.channel.id),remind_at,message))
            conn.commit()
        await ctx.send(embed=success_embed("Reminder Set",f"I'll remind you in **{format_seconds(secs)}**:\n{message}"))

    @commands.command(name="reminders",help="View your active reminders")
    async def reminders_cmd(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT id,remind_at,message FROM reminders WHERE user_id=? AND done=0",(str(ctx.author.id),))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=info_embed("No Reminders"))
        desc="\n".join(f"**#{r[0]}** — `{r[1][:16]}` — {r[2][:50]}" for r in rows)
        await ctx.send(embed=discord.Embed(title="⏰ Your Reminders",description=desc,color=0x3498db))

    @commands.command(name="delreminder",help="Delete a reminder by ID")
    async def delreminder(self,ctx,rid:int):
        with db() as conn:
            conn.execute("DELETE FROM reminders WHERE id=? AND user_id=?",(rid,str(ctx.author.id)))
            conn.commit()
        await ctx.send(embed=success_embed("Reminder Deleted"))

    @commands.command(name="tag",help="Use a tag")
    async def tag(self,ctx,*,name:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT content FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            row=c.fetchone()
            if row:
                conn.execute("UPDATE tags SET uses=uses+1 WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
                conn.commit()
        if not row: return await ctx.send(embed=error_embed("Tag Not Found",f"No tag named `{name}`."))
        await ctx.send(row[0])

    @commands.command(name="tagcreate",help="Create a tag")
    async def tagcreate(self,ctx,name:str,*,content:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT name FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            if c.fetchone(): return await ctx.send(embed=error_embed("Exists",f"Tag `{name}` already exists."))
            conn.execute("INSERT INTO tags VALUES (?,?,?,?,0)",(str(ctx.guild.id),name.lower(),content,str(ctx.author.id)))
            conn.commit()
        await ctx.send(embed=success_embed("Tag Created",f"Tag `{name}` created."))

    @commands.command(name="tagdelete",help="Delete a tag")
    @commands.has_permissions(manage_messages=True)
    async def tagdelete(self,ctx,*,name:str):
        with db() as conn:
            conn.execute("DELETE FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            conn.commit()
        await ctx.send(embed=success_embed("Tag Deleted"))

    @commands.command(name="taglist",help="List all tags")
    async def taglist(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT name,uses FROM tags WHERE guild_id=? ORDER BY uses DESC",(str(ctx.guild.id),))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=info_embed("No Tags"))
        desc=", ".join(f"`{r[0]}`" for r in rows[:30])
        await ctx.send(embed=discord.Embed(title="🏷️ Tags",description=desc,color=0x3498db))

    @commands.command(name="taginfo",help="Info about a tag")
    async def taginfo(self,ctx,*,name:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT content,author_id,uses FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            row=c.fetchone()
        if not row: return await ctx.send(embed=error_embed("Not Found"))
        e=discord.Embed(title=f"🏷️ Tag: {name}",color=0x3498db)
        e.add_field(name="Author",value=f"<@{row[1]}>")
        e.add_field(name="Uses",value=row[2])
        e.add_field(name="Content",value=row[0][:200],inline=False)
        await ctx.send(embed=e)

    @commands.command(name="tagedit",help="Edit a tag")
    async def tagedit(self,ctx,name:str,*,content:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT author_id FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            row=c.fetchone()
        if not row: return await ctx.send(embed=error_embed("Not Found"))
        if row[0]!=str(ctx.author.id) and not ctx.author.guild_permissions.manage_messages:
            return await ctx.send(embed=error_embed("Not Yours"))
        with db() as conn:
            conn.execute("UPDATE tags SET content=? WHERE guild_id=? AND name=?",(content,str(ctx.guild.id),name.lower()))
            conn.commit()
        await ctx.send(embed=success_embed("Tag Edited"))

    @commands.command(name="avatar",aliases=["av","pfp"],help="Get member avatar")
    async def avatar(self,ctx,member:Optional[discord.Member]):
        member=member or ctx.author
        e=discord.Embed(title=f"{member.display_name}'s Avatar",color=0x3498db)
        e.set_image(url=member.display_avatar.url)
        e.add_field(name="Download",value=f"[PNG]({member.display_avatar.url})")
        await ctx.send(embed=e)

    @commands.command(name="banner",help="Get member banner")
    async def banner(self,ctx,member:Optional[discord.Member]):
        member=member or ctx.author
        u=await self.bot.fetch_user(member.id)
        if not u.banner: return await ctx.send(embed=error_embed("No Banner",f"{member.mention} has no banner."))
        e=discord.Embed(title=f"{member.display_name}'s Banner",color=0x3498db)
        e.set_image(url=u.banner.url)
        await ctx.send(embed=e)

    @commands.command(name="servericon",help="Get server icon")
    async def servericon(self,ctx):
        if not ctx.guild.icon: return await ctx.send(embed=error_embed("No Icon","Server has no icon."))
        e=discord.Embed(title=f"{ctx.guild.name} Icon",color=0x3498db)
        e.set_image(url=ctx.guild.icon.url)
        await ctx.send(embed=e)

    @commands.command(name="serverbanner",help="Get server banner")
    async def serverbanner(self,ctx):
        if not ctx.guild.banner: return await ctx.send(embed=error_embed("No Banner"))
        e=discord.Embed(title=f"{ctx.guild.name} Banner",color=0x3498db)
        e.set_image(url=ctx.guild.banner.url)
        await ctx.send(embed=e)

    @commands.command(name="ping",help="Check bot latency")
    async def ping(self,ctx):
        lat=round(self.bot.latency*1000)
        color=0x2ecc71 if lat<100 else 0xf39c12 if lat<200 else 0xe74c3c
        e=discord.Embed(title="🏓 Pong!",color=color)
        e.add_field(name="Latency",value=f"`{lat}ms`")
        e.add_field(name="Status",value="🟢 Good" if lat<100 else "🟡 OK" if lat<200 else "🔴 High")
        await ctx.send(embed=e)

    @commands.command(name="uptime",help="Check bot uptime")
    async def uptime(self,ctx):
        now=datetime.datetime.utcnow()
        delta=now-self.bot.launch_time if hasattr(self.bot,'launch_time') else datetime.timedelta(seconds=0)
        await ctx.send(embed=info_embed("Uptime",format_seconds(int(delta.total_seconds()))))

    @commands.command(name="botinfo",help="Bot information")
    async def botinfo(self,ctx):
        e=discord.Embed(title="🤖 Bot Info",color=0x3498db)
        e.add_field(name="Name",value=str(self.bot.user))
        e.add_field(name="ID",value=self.bot.user.id)
        e.add_field(name="Servers",value=len(self.bot.guilds))
        e.add_field(name="Users",value=sum(g.member_count for g in self.bot.guilds))
        e.add_field(name="Commands",value=len(self.bot.commands))
        e.add_field(name="Latency",value=f"{round(self.bot.latency*1000)}ms")
        e.set_thumbnail(url=self.bot.user.display_avatar.url)
        await ctx.send(embed=e)

    @commands.command(name="channelinfo",help="Info about a channel")
    async def channelinfo(self,ctx,channel:Optional[discord.TextChannel]):
        ch=channel or ctx.channel
        e=discord.Embed(title=f"#{ch.name}",color=0x3498db)
        e.add_field(name="ID",value=ch.id)
        e.add_field(name="Type",value=str(ch.type))
        e.add_field(name="NSFW",value=ch.is_nsfw())
        e.add_field(name="Category",value=ch.category.name if ch.category else "None")
        e.add_field(name="Created",value=ch.created_at.strftime("%Y-%m-%d"))
        e.add_field(name="Position",value=ch.position)
        if hasattr(ch,'topic'): e.add_field(name="Topic",value=ch.topic or "None",inline=False)
        await ctx.send(embed=e)

    @commands.command(name="emojiinfo",help="Info about an emoji")
    async def emojiinfo(self,ctx,emoji:discord.Emoji):
        e=discord.Embed(title=f"Emoji: {emoji.name}",color=0x3498db)
        e.set_image(url=emoji.url)
        e.add_field(name="ID",value=emoji.id)
        e.add_field(name="Animated",value=emoji.animated)
        e.add_field(name="Created",value=emoji.created_at.strftime("%Y-%m-%d"))
        await ctx.send(embed=e)

    @commands.command(name="listemojis",help="List all server emojis")
    async def listemojis(self,ctx):
        emojis=ctx.guild.emojis
        if not emojis: return await ctx.send(embed=info_embed("No Emojis"))
        desc=" ".join(str(e) for e in emojis[:50])
        await ctx.send(embed=discord.Embed(title=f"Emojis ({len(emojis)})",description=desc,color=0x3498db))

    @commands.command(name="stealemoji",help="Add emoji from another server")
    @commands.has_permissions(manage_emojis=True)
    async def stealemoji(self,ctx,emoji:discord.PartialEmoji,*,name:Optional[str]):
        name=name or emoji.name
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(str(emoji.url)) as r:
                data=await r.read()
        new_emoji=await ctx.guild.create_custom_emoji(name=name,image=data)
        await ctx.send(embed=success_embed("Emoji Stolen",f"{new_emoji} added as `:{new_emoji.name}:`"))

    @commands.command(name="createemoji",help="Create emoji from image URL")
    @commands.has_permissions(manage_emojis=True)
    async def createemoji(self,ctx,name:str,url:str):
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as r:
                data=await r.read()
        emoji=await ctx.guild.create_custom_emoji(name=name,image=data)
        await ctx.send(embed=success_embed("Emoji Created",f"{emoji} `:{emoji.name}:`"))

    @commands.command(name="deleteemoji",help="Delete a server emoji")
    @commands.has_permissions(manage_emojis=True)
    async def deleteemoji(self,ctx,emoji:discord.Emoji):
        name=emoji.name
        await emoji.delete()
        await ctx.send(embed=success_embed("Emoji Deleted",f"`:{name}:` deleted."))

    @commands.command(name="renameemoji",help="Rename an emoji")
    @commands.has_permissions(manage_emojis=True)
    async def renameemoji(self,ctx,emoji:discord.Emoji,*,name:str):
        await emoji.edit(name=name)
        await ctx.send(embed=success_embed("Emoji Renamed",f"Now `:{name}:`"))

    @commands.command(name="timestamp",help="Convert time to Discord timestamp")
    async def timestamp(self,ctx,*,time_str:str):
        now=int(datetime.datetime.utcnow().timestamp())
        await ctx.send(f"**Timestamp:** `{now}`\n**Format:** <t:{now}:F> → <t:{now}:F>\n**Relative:** <t:{now}:R>")

    @commands.command(name="charinfo",help="Info about a character")
    async def charinfo(self,ctx,*,chars:str):
        def get_info(c):
            import unicodedata
            try: name=unicodedata.name(c)
            except: name="UNKNOWN"
            return f"U+{ord(c):04X} `{c}` — {name}"
        info="\n".join(get_info(c) for c in chars[:10])
        await ctx.send(embed=info_embed("Character Info",info))

    @commands.command(name="snowflake",help="Decode a Discord snowflake ID")
    async def snowflake(self,ctx,snowflake_id:int):
        ts=(snowflake_id>>22)+1420070400000
        dt=datetime.datetime.utcfromtimestamp(ts/1000)
        e=info_embed("Snowflake Decode")
        e.add_field(name="ID",value=snowflake_id)
        e.add_field(name="Created At",value=dt.strftime("%Y-%m-%d %H:%M:%S UTC"))
        await ctx.send(embed=e)

    @commands.command(name="calc",help="Calculator")
    async def calc(self,ctx,*,expression:str):
        try:
            safe={'__builtins__':{},'abs':abs,'round':round,'min':min,'max':max,'pow':pow,'sum':sum}
            result=eval(expression,safe)
            await ctx.send(embed=info_embed("Calculator",f"`{expression}` = **{result}**"))
        except:
            await ctx.send(embed=error_embed("Error","Invalid expression."))

    @commands.command(name="color",help="Preview a hex color")
    async def color(self,ctx,hex_color:str):
        try:
            c=int(hex_color.strip("#"),16)
            e=discord.Embed(title=f"Color: #{hex_color.strip('#').upper()}",color=c)
            r=(c>>16)&255; g=(c>>8)&255; b=c&255
            e.add_field(name="RGB",value=f"({r}, {g}, {b})")
            e.add_field(name="Hex",value=f"#{hex_color.strip('#').upper()}")
            await ctx.send(embed=e)
        except:
            await ctx.send(embed=error_embed("Invalid Color","Use hex like `#ff0000`."))

    @commands.command(name="base64encode",help="Encode text to base64")
    async def base64encode(self,ctx,*,text:str):
        import base64
        result=base64.b64encode(text.encode()).decode()
        await ctx.send(embed=info_embed("Base64 Encode",f"```{result}```"))

    @commands.command(name="base64decode",help="Decode base64 text")
    async def base64decode(self,ctx,*,text:str):
        import base64
        try:
            result=base64.b64decode(text.encode()).decode()
            await ctx.send(embed=info_embed("Base64 Decode",f"```{result}```"))
        except:
            await ctx.send(embed=error_embed("Invalid","Not valid base64."))

    @commands.command(name="hash",help="Hash text with MD5/SHA256")
    async def hash_cmd(self,ctx,algo:str,*,text:str):
        import hashlib
        algos={'md5':hashlib.md5,'sha1':hashlib.sha1,'sha256':hashlib.sha256,'sha512':hashlib.sha512}
        if algo.lower() not in algos: return await ctx.send(embed=error_embed("Invalid","Use: md5, sha1, sha256, sha512"))
        result=algos[algo.lower()](text.encode()).hexdigest()
        await ctx.send(embed=info_embed(f"{algo.upper()} Hash",f"```{result}```"))

    @commands.command(name="random",help="Random number between two values")
    async def random_num(self,ctx,min_val:int=1,max_val:int=100):
        n=random.randint(min_val,max_val)
        await ctx.send(embed=info_embed("🎲 Random Number",f"**{n}** (between {min_val} and {max_val})"))

    @commands.command(name="choose",help="Choose between options. !choose A | B | C")
    async def choose(self,ctx,*,options:str):
        choices=[o.strip() for o in options.split("|")]
        choice=random.choice(choices)
        await ctx.send(embed=info_embed("🎯 I Choose",f"**{choice}**"))

    @commands.command(name="coinflip",aliases=["flip"],help="Flip a coin")
    async def coinflip(self,ctx):
        result=random.choice(["Heads 👑","Tails 🦅"])
        await ctx.send(embed=info_embed("🪙 Coin Flip",f"**{result}**!"))

    @commands.command(name="dice",help="Roll dice. !dice 2d6")
    async def dice(self,ctx,notation:str="1d6"):
        try:
            parts=notation.lower().split("d")
            n=int(parts[0]); sides=int(parts[1])
            if n>20 or sides>1000: return await ctx.send(embed=error_embed("Too Large","Max 20d1000"))
            rolls=[random.randint(1,sides) for _ in range(n)]
            total=sum(rolls)
            await ctx.send(embed=info_embed(f"🎲 {notation}",f"Rolls: {rolls}\n**Total: {total}**"))
        except:
            await ctx.send(embed=error_embed("Invalid","Use format like `2d6`."))

    @commands.command(name="8ball",aliases=["ask"],help="Ask the magic 8-ball")
    async def eightball(self,ctx,*,question:str):
        answers=["It is certain","It is decidedly so","Without a doubt","Yes definitely",
                 "You may rely on it","As I see it, yes","Most likely","Outlook good",
                 "Signs point to yes","Yes","Reply hazy try again","Ask again later",
                 "Better not tell you now","Cannot predict now","Don't count on it",
                 "My reply is no","My sources say no","Outlook not so good","Very doubtful","No"]
        color_map={"certainly":0x2ecc71,"yes":0x2ecc71,"good":0x2ecc71,"likely":0x2ecc71,
                   "hazy":0xf39c12,"later":0xf39c12,"not":0xe74c3c,"no":0xe74c3c,"doubtful":0xe74c3c}
        ans=random.choice(answers)
        color=next((v for k,v in color_map.items() if k in ans.lower()),0x3498db)
        e=discord.Embed(color=color)
        e.add_field(name="❓ Question",value=question,inline=False)
        e.add_field(name="🎱 Answer",value=f"**{ans}**",inline=False)
        await ctx.send(embed=e)

    @commands.command(name="urban",help="Look up a word on Urban Dictionary")
    async def urban(self,ctx,*,word:str):
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.urbandictionary.com/v0/define?term={word}") as r:
                data=await r.json()
        if not data.get("list"):
            return await ctx.send(embed=error_embed("Not Found",f"No definition for `{word}`."))
        defn=data["list"][0]
        e=discord.Embed(title=defn["word"],url=defn["permalink"],color=0x1d2439)
        e.add_field(name="Definition",value=defn["definition"][:500],inline=False)
        e.add_field(name="Example",value=defn["example"][:300] or "None",inline=False)
        e.add_field(name="👍",value=defn["thumbs_up"])
        e.add_field(name="👎",value=defn["thumbs_down"])
        await ctx.send(embed=e)

    @commands.command(name="weather",help="Get weather info")
    async def weather(self,ctx,*,city:str):
        await ctx.send(embed=info_embed("Weather",f"To use weather, add an OpenWeatherMap API key in config.json as `weather_api_key`."))

    @commands.command(name="translate",help="Translate text (requires API)")
    async def translate(self,ctx,lang:str,*,text:str):
        await ctx.send(embed=info_embed("Translate",f"Translation to `{lang}`: (Requires Google Translate API key)"))

    @commands.command(name="qr",help="Generate QR code for text/URL")
    async def qr(self,ctx,*,text:str):
        import urllib.parse
        url=f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={urllib.parse.quote(text)}"
        e=discord.Embed(title="📷 QR Code",color=0x3498db)
        e.set_image(url=url)
        await ctx.send(embed=e)

    @commands.command(name="shorten",help="Shorten a URL")
    async def shorten(self,ctx,url:str):
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://tinyurl.com/api-create.php?url={url}") as r:
                result=await r.text()
        await ctx.send(embed=info_embed("🔗 Shortened URL",result))

    @commands.command(name="whois",help="Detailed info about a member")
    async def whois(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        roles=[r.mention for r in m.roles[1:]][:10]
        e=discord.Embed(title=str(m),color=m.color)
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="ID",value=m.id)
        e.add_field(name="Nickname",value=m.nick or "None")
        e.add_field(name="Status",value=str(m.status).title())
        e.add_field(name="Account Created",value=m.created_at.strftime("%Y-%m-%d"))
        e.add_field(name="Joined Server",value=m.joined_at.strftime("%Y-%m-%d") if m.joined_at else "?")
        e.add_field(name="Top Role",value=m.top_role.mention)
        e.add_field(name="Roles",value=" ".join(roles) or "None",inline=False)
        e.add_field(name="Bot",value=m.bot)
        await ctx.send(embed=e)

    @commands.command(name="serverinfo",help="Server information")
    async def serverinfo(self,ctx):
        g=ctx.guild
        bots=sum(1 for m in g.members if m.bot)
        e=discord.Embed(title=g.name,color=0x3498db,timestamp=datetime.datetime.utcnow())
        if g.icon: e.set_thumbnail(url=g.icon.url)
        e.add_field(name="ID",value=g.id)
        e.add_field(name="Owner",value=g.owner.mention if g.owner else "?")
        e.add_field(name="Members",value=g.member_count)
        e.add_field(name="Humans",value=g.member_count-bots)
        e.add_field(name="Bots",value=bots)
        e.add_field(name="Channels",value=len(g.channels))
        e.add_field(name="Roles",value=len(g.roles))
        e.add_field(name="Emojis",value=len(g.emojis))
        e.add_field(name="Boost Level",value=g.premium_tier)
        e.add_field(name="Boosts",value=g.premium_subscription_count)
        e.add_field(name="Created",value=g.created_at.strftime("%Y-%m-%d"))
        e.add_field(name="Verification",value=str(g.verification_level))
        await ctx.send(embed=e)

async def setup(bot):
    await bot.add_cog(Utility(bot))
