"""
LEVELING COG
"""
import discord
from discord.ext import commands
import sqlite3
from typing import Optional

def db(): return sqlite3.connect("ultrabot.db")
def s(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)
def e(t,d=None): return discord.Embed(title=f"❌ {t}",description=d,color=0xe74c3c)
def i(t,d=None): return discord.Embed(title=f"ℹ️ {t}",description=d,color=0x3498db)

class Leveling(commands.Cog):
    """⭐ XP & Leveling"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="rank",aliases=["level","xp"],help="View your rank")
    async def rank(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        gid,uid=str(ctx.guild.id),str(m.id)
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT xp,level,messages FROM xp WHERE guild_id=? AND user_id=?",(gid,uid))
            row=c.fetchone()
            if not row: return await ctx.send(embed=e("No Data",f"{m.mention} hasn't earned XP yet."))
            xp_val,level,messages=row
            c.execute("SELECT COUNT(*)+1 FROM xp WHERE guild_id=? AND xp>?",(gid,xp_val))
            rank_pos=c.fetchone()[0]
        needed=100*(level+1)*(level+1)
        bar_filled=int((xp_val/needed)*20)
        bar="█"*bar_filled+"░"*(20-bar_filled)
        em=discord.Embed(title=f"⭐ {m.display_name}'s Rank",color=0xf1c40f)
        em.set_thumbnail(url=m.display_avatar.url)
        em.add_field(name="Rank",value=f"#{rank_pos}")
        em.add_field(name="Level",value=level)
        em.add_field(name="XP",value=f"{xp_val:,}/{needed:,}")
        em.add_field(name="Messages",value=f"{messages:,}")
        em.add_field(name="Progress",value=f"`[{bar}]`",inline=False)
        await ctx.send(embed=em)

    @commands.command(name="leaderboard_xp",aliases=["lbxp","xplb"],help="XP leaderboard")
    async def xp_leaderboard(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT user_id,level,xp FROM xp WHERE guild_id=? ORDER BY level DESC,xp DESC LIMIT 10",(str(ctx.guild.id),))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=i("Empty"))
        medals=["🥇","🥈","🥉"]
        desc="\n".join(
            f"{medals[idx] if idx<3 else f'`{idx+1}.`'} <@{uid}> — **Lv.{lvl}** ({xp_v:,} XP)"
            for idx,(uid,lvl,xp_v) in enumerate(rows)
        )
        await ctx.send(embed=discord.Embed(title="⭐ XP Leaderboard",description=desc,color=0xf1c40f))

    @commands.command(name="setxp",help="[ADMIN] Set XP for a user")
    @commands.has_permissions(administrator=True)
    async def setxp(self,ctx,member:discord.Member,amount:int):
        gid,uid=str(ctx.guild.id),str(member.id)
        with db() as conn:
            conn.execute("INSERT OR IGNORE INTO xp (guild_id,user_id) VALUES (?,?)",(gid,uid))
            conn.execute("UPDATE xp SET xp=? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
            conn.commit()
        await ctx.send(embed=s("XP Set",f"Set {member.mention}'s XP to {amount:,}."))

    @commands.command(name="setlevel",help="[ADMIN] Set level for a user")
    @commands.has_permissions(administrator=True)
    async def setlevel(self,ctx,member:discord.Member,level:int):
        gid,uid=str(ctx.guild.id),str(member.id)
        with db() as conn:
            conn.execute("INSERT OR IGNORE INTO xp (guild_id,user_id) VALUES (?,?)",(gid,uid))
            conn.execute("UPDATE xp SET level=? WHERE guild_id=? AND user_id=?",(level,gid,uid))
            conn.commit()
        await ctx.send(embed=s("Level Set",f"Set {member.mention} to level {level}."))

    @commands.command(name="resetxp",help="[ADMIN] Reset user XP")
    @commands.has_permissions(administrator=True)
    async def resetxp(self,ctx,member:discord.Member):
        gid,uid=str(ctx.guild.id),str(member.id)
        with db() as conn:
            conn.execute("UPDATE xp SET xp=0,level=0,messages=0 WHERE guild_id=? AND user_id=?",(gid,uid))
            conn.commit()
        await ctx.send(embed=s("XP Reset",f"{member.mention}'s XP reset."))

    @commands.command(name="resetallxp",help="[ADMIN] Reset all XP in server")
    @commands.has_permissions(administrator=True)
    async def resetallxp(self,ctx):
        with db() as conn:
            conn.execute("DELETE FROM xp WHERE guild_id=?",(str(ctx.guild.id),))
            conn.commit()
        await ctx.send(embed=s("All XP Reset","All XP data cleared for this server."))

    @commands.command(name="givexp",help="[ADMIN] Give XP to user")
    @commands.has_permissions(administrator=True)
    async def givexp(self,ctx,member:discord.Member,amount:int):
        gid,uid=str(ctx.guild.id),str(member.id)
        with db() as conn:
            conn.execute("INSERT OR IGNORE INTO xp (guild_id,user_id) VALUES (?,?)",(gid,uid))
            conn.execute("UPDATE xp SET xp=xp+? WHERE guild_id=? AND user_id=?",(amount,gid,uid))
            conn.commit()
        await ctx.send(embed=s("XP Given",f"Gave {amount:,} XP to {member.mention}."))

async def setup(bot):
    await bot.add_cog(Leveling(bot))
