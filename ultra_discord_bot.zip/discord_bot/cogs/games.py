"""GAMES COG"""
import discord, random, asyncio
from discord.ext import commands

class Games(commands.Cog):
    """🕹️ Games"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="guess",help="Guess the number game")
    async def guess(self,ctx,max_num:int=100):
        number=random.randint(1,max_num)
        em=discord.Embed(title=f"🎯 Guess the Number",description=f"Guess a number between **1 and {max_num}**!\nYou have 10 tries.",color=0x9b59b6)
        await ctx.send(embed=em)
        def check(m): 
            return m.author==ctx.author and m.channel==ctx.channel and m.content.isdigit()
        for attempt in range(10):
            try:
                reply=await self.bot.wait_for("message",check=check,timeout=30)
                guess=int(reply.content)
                if guess==number:
                    return await ctx.send(embed=discord.Embed(description=f"🎉 Correct! The number was **{number}**! (Try {attempt+1}/10)",color=0x2ecc71))
                elif guess<number:
                    await ctx.send(f"📈 Too low! Try higher. ({9-attempt} tries left)",delete_after=5)
                else:
                    await ctx.send(f"📉 Too high! Try lower. ({9-attempt} tries left)",delete_after=5)
            except asyncio.TimeoutError:
                return await ctx.send(embed=discord.Embed(description=f"⏰ Timed out! The number was **{number}**.",color=0xe74c3c))
        await ctx.send(embed=discord.Embed(description=f"❌ Out of tries! The number was **{number}**.",color=0xe74c3c))

    @commands.command(name="akinator",help="Simple Akinator-like game")
    async def akinator(self,ctx):
        await ctx.send(embed=discord.Embed(title="🧞 Akinator",description="Think of a character!\nType `!guess @character` to play.\n(Full Akinator requires Akinator API)",color=0x9b59b6))

    @commands.command(name="math",help="Math quiz game")
    async def math(self,ctx):
        a,b=random.randint(1,50),random.randint(1,50)
        op=random.choice(["+","-","*"])
        if op=="+": ans=a+b
        elif op=="-": ans=a-b
        else: ans=a*b
        em=discord.Embed(title="🔢 Math Quiz",description=f"What is **{a} {op} {b}**?\n\nYou have 15 seconds!",color=0x3498db)
        await ctx.send(embed=em)
        def check(m): return m.author==ctx.author and m.channel==ctx.channel
        try:
            reply=await self.bot.wait_for("message",check=check,timeout=15)
            if reply.content.strip()==str(ans):
                await ctx.send(embed=discord.Embed(description=f"✅ Correct! **{a} {op} {b} = {ans}**",color=0x2ecc71))
            else:
                await ctx.send(embed=discord.Embed(description=f"❌ Wrong! Answer was **{ans}**",color=0xe74c3c))
        except asyncio.TimeoutError:
            await ctx.send(embed=discord.Embed(description=f"⏰ Time's up! Answer: **{ans}**",color=0xe74c3c))

    @commands.command(name="wordle",help="Play Wordle in Discord")
    async def wordle(self,ctx):
        words=["crane","beach","piano","light","stone","flame","grace","brave","chess","globe"]
        word=random.choice(words)
        em=discord.Embed(title="🟩 Wordle",description="Guess the 5-letter word!\nYou have 6 tries.\nType a 5-letter word!",color=0x538d4e)
        await ctx.send(embed=em)
        def render_guess(guess,word):
            result=""
            for i,(g,w) in enumerate(zip(guess,word)):
                if g==w: result+=f"🟩"
                elif g in word: result+=f"🟨"
                else: result+="⬜"
            return result+" "+guess.upper()
        guesses=[]
        def check(m): return m.author==ctx.author and m.channel==ctx.channel and len(m.content)==5 and m.content.isalpha()
        for attempt in range(6):
            try:
                reply=await self.bot.wait_for("message",check=check,timeout=60)
                guess=reply.content.lower()
                result=render_guess(guess,word)
                guesses.append(result)
                display="\n".join(guesses)
                if guess==word:
                    return await ctx.send(embed=discord.Embed(title="🟩 Wordle - You Won!",description=display+f"\n\n✅ **{word.upper()}** in {attempt+1}/6!",color=0x538d4e))
                await ctx.send(embed=discord.Embed(title="🟩 Wordle",description=display,color=0x538d4e))
            except asyncio.TimeoutError:
                return await ctx.send(embed=discord.Embed(description=f"⏰ Time's up! Word was **{word.upper()}**",color=0xe74c3c))
        await ctx.send(embed=discord.Embed(description=f"❌ Out of tries! Word was **{word.upper()}**",color=0xe74c3c))

    @commands.command(name="fasttype",help="Fast typing challenge")
    async def fasttype(self,ctx):
        sentences=["The quick brown fox jumps over the lazy dog","Pack my box with five dozen liquor jugs","How vexingly quick daft zebras jump","The five boxing wizards jump quickly"]
        sentence=random.choice(sentences)
        em=discord.Embed(title="⌨️ Fast Type Challenge",description=f"Type this as fast as you can!\n\n```{sentence}```",color=0x3498db)
        msg=await ctx.send(embed=em)
        import time
        start=time.time()
        def check(m): return m.author==ctx.author and m.channel==ctx.channel
        try:
            reply=await self.bot.wait_for("message",check=check,timeout=60)
            elapsed=round(time.time()-start,2)
            if reply.content.lower()==sentence.lower():
                wpm=int(len(sentence.split())/elapsed*60)
                await ctx.send(embed=discord.Embed(description=f"✅ Correct! Time: **{elapsed}s** | WPM: **{wpm}**",color=0x2ecc71))
            else:
                await ctx.send(embed=discord.Embed(description=f"❌ Wrong! Time: **{elapsed}s** — Check your typing!",color=0xe74c3c))
        except asyncio.TimeoutError:
            await ctx.send(embed=discord.Embed(description="⏰ Timed out!",color=0xe74c3c))

async def setup(bot):
    await bot.add_cog(Games(bot))
