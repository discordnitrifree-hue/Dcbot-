"""
ADMIN COG - Server Admin Commands
"""
import discord
from discord.ext import commands
import datetime
import json
import sqlite3
import asyncio
from typing import Optional

def db():
    return sqlite3.connect("ultrabot.db")

def success_embed(t, d=None): return discord.Embed(title=f"✅ {t}", description=d, color=0x2ecc71)
def error_embed(t, d=None):   return discord.Embed(title=f"❌ {t}", description=d, color=0xe74c3c)
def info_embed(t, d=None):    return discord.Embed(title=f"ℹ️ {t}", description=d, color=0x3498db)

def get_settings(guild_id):
    with db() as conn:
        c = conn.cursor()
        c.execute("SELECT settings FROM guild_settings WHERE guild_id=?", (guild_id,))
        row = c.fetchone()
        return json.loads(row[0]) if row else {}

def set_settings(guild_id, s):
    with db() as conn:
        conn.execute("INSERT OR REPLACE INTO guild_settings VALUES (?,?)", (guild_id, json.dumps(s)))
        conn.commit()

def update_setting(guild_id, key, value):
    s = get_settings(guild_id)
    s[key] = value
    set_settings(guild_id, s)

class Admin(commands.Cog):
    """👑 Admin - Server Administration"""
    def __init__(self, bot): self.bot = bot

    @commands.command(name="setup", help="Quick server setup wizard")
    @commands.has_permissions(administrator=True)
    async def setup_wizard(self, ctx):
        e = discord.Embed(title="⚙️ Server Setup", color=0x3498db,
            description="Use these commands to configure your bot:\n\n"
            "`!setwelcome #channel` - Set welcome channel\n"
            "`!setleave #channel` - Set leave channel\n"
            "`!setlog #channel` - Set mod log channel\n"
            "`!setautorole @role` - Set auto role\n"
            "`!setprefix !` - Change prefix\n"
            "`!antispam on` - Enable anti-spam\n"
            "`!anticaps on` - Enable anti-caps\n"
            "`!antiinvite on` - Block invites\n"
            "`!antilinks on` - Block all links\n"
            "`!xp on` - Enable XP system\n"
            "`!economy on` - Enable economy\n"
            "`!setstarboard #ch 3` - Setup starboard\n"
        )
        await ctx.send(embed=e)

    @commands.command(name="setwelcome", help="Set welcome channel")
    @commands.has_permissions(administrator=True)
    async def setwelcome(self, ctx, channel: discord.TextChannel):
        update_setting(str(ctx.guild.id), "welcome_channel", str(channel.id))
        await ctx.send(embed=success_embed("Welcome Set", f"Welcome messages → {channel.mention}"))

    @commands.command(name="setleave", help="Set leave channel")
    @commands.has_permissions(administrator=True)
    async def setleave(self, ctx, channel: discord.TextChannel):
        update_setting(str(ctx.guild.id), "leave_channel", str(channel.id))
        await ctx.send(embed=success_embed("Leave Set", f"Leave messages → {channel.mention}"))

    @commands.command(name="setlog", help="Set mod log channel")
    @commands.has_permissions(administrator=True)
    async def setlog(self, ctx, channel: discord.TextChannel):
        update_setting(str(ctx.guild.id), "log_channel", str(channel.id))
        await ctx.send(embed=success_embed("Log Set", f"Mod logs → {channel.mention}"))

    @commands.command(name="setautorole", help="Set auto-role on join")
    @commands.has_permissions(administrator=True)
    async def setautorole(self, ctx, role: discord.Role):
        update_setting(str(ctx.guild.id), "auto_role", str(role.id))
        await ctx.send(embed=success_embed("Auto-Role Set", f"New members get {role.mention}"))

    @commands.command(name="removeautorole", help="Remove auto-role")
    @commands.has_permissions(administrator=True)
    async def removeautorole(self, ctx):
        update_setting(str(ctx.guild.id), "auto_role", None)
        await ctx.send(embed=success_embed("Auto-Role Removed"))

    @commands.command(name="setprefix", help="Change bot prefix")
    @commands.has_permissions(administrator=True)
    async def setprefix(self, ctx, prefix: str):
        update_setting(str(ctx.guild.id), "prefix", prefix)
        await ctx.send(embed=success_embed("Prefix Changed", f"New prefix: `{prefix}`"))

    @commands.command(name="setwelcomemsg", help="Set custom welcome message")
    @commands.has_permissions(administrator=True)
    async def setwelcomemsg(self, ctx, *, msg: str):
        update_setting(str(ctx.guild.id), "welcome_message", msg)
        await ctx.send(embed=success_embed("Welcome Message Set",
            f"Variables: `{{user}}`, `{{server}}`, `{{count}}`, `{{username}}`\n\n{msg}"))

    @commands.command(name="setleavemsg", help="Set custom leave message")
    @commands.has_permissions(administrator=True)
    async def setleavemsg(self, ctx, *, msg: str):
        update_setting(str(ctx.guild.id), "leave_message", msg)
        await ctx.send(embed=success_embed("Leave Message Set", msg))

    @commands.command(name="antispam", help="Toggle anti-spam. !antispam on/off")
    @commands.has_permissions(administrator=True)
    async def antispam(self, ctx, toggle: str):
        val = toggle.lower() in ("on", "true", "enable", "yes", "1")
        update_setting(str(ctx.guild.id), "antispam", val)
        status = "Enabled" if val else "Disabled"
        await ctx.send(embed=success_embed(f"Anti-Spam {status}"))

    @commands.command(name="antispam_limit", help="Set anti-spam message limit (per 5s)")
    @commands.has_permissions(administrator=True)
    async def antispam_limit(self, ctx, limit: int):
        update_setting(str(ctx.guild.id), "antispam_limit", limit)
        await ctx.send(embed=success_embed("Spam Limit Set", f"Limit: {limit} messages per 5 seconds"))

    @commands.command(name="anticaps", help="Toggle anti-caps")
    @commands.has_permissions(administrator=True)
    async def anticaps(self, ctx, toggle: str):
        val = toggle.lower() in ("on", "true", "enable", "yes", "1")
        update_setting(str(ctx.guild.id), "anticaps", val)
        await ctx.send(embed=success_embed(f"Anti-Caps {'Enabled' if val else 'Disabled'}"))

    @commands.command(name="antiinvite", help="Toggle anti-invite links")
    @commands.has_permissions(administrator=True)
    async def antiinvite(self, ctx, toggle: str):
        val = toggle.lower() in ("on", "true", "enable", "yes", "1")
        update_setting(str(ctx.guild.id), "antiinvite", val)
        await ctx.send(embed=success_embed(f"Anti-Invite {'Enabled' if val else 'Disabled'}"))

    @commands.command(name="antilinks", help="Toggle anti-links")
    @commands.has_permissions(administrator=True)
    async def antilinks(self, ctx, toggle: str):
        val = toggle.lower() in ("on", "true", "enable", "yes", "1")
        update_setting(str(ctx.guild.id), "antilinks", val)
        await ctx.send(embed=success_embed(f"Anti-Links {'Enabled' if val else 'Disabled'}"))

    @commands.command(name="xp", help="Toggle XP system. !xp on/off")
    @commands.has_permissions(administrator=True)
    async def xp_toggle(self, ctx, toggle: str):
        val = toggle.lower() in ("on", "true", "enable", "yes", "1")
        update_setting(str(ctx.guild.id), "xp_enabled", val)
        await ctx.send(embed=success_embed(f"XP System {'Enabled' if val else 'Disabled'}"))

    @commands.command(name="economy", help="Toggle economy system")
    @commands.has_permissions(administrator=True)
    async def economy_toggle(self, ctx, toggle: str):
        val = toggle.lower() in ("on", "true", "enable", "yes", "1")
        update_setting(str(ctx.guild.id), "economy_enabled", val)
        await ctx.send(embed=success_embed(f"Economy {'Enabled' if val else 'Disabled'}"))

    @commands.command(name="setlevelchannel", help="Set level-up announcement channel")
    @commands.has_permissions(administrator=True)
    async def setlevelchannel(self, ctx, channel: discord.TextChannel):
        update_setting(str(ctx.guild.id), "level_channel", str(channel.id))
        await ctx.send(embed=success_embed("Level Channel Set", f"Level-up messages → {channel.mention}"))

    @commands.command(name="setlevelrole", help="Set role reward for a level")
    @commands.has_permissions(administrator=True)
    async def setlevelrole(self, ctx, level: int, role: discord.Role):
        update_setting(str(ctx.guild.id), f"level_role_{level}", str(role.id))
        await ctx.send(embed=success_embed("Level Role Set", f"Level {level} → {role.mention}"))

    @commands.command(name="setstarboard", help="Setup starboard. !setstarboard #channel [min_stars]")
    @commands.has_permissions(administrator=True)
    async def setstarboard(self, ctx, channel: discord.TextChannel, count: int = 3, emoji: str = "⭐"):
        gid = str(ctx.guild.id)
        update_setting(gid, "starboard_channel", str(channel.id))
        update_setting(gid, "starboard_count", count)
        update_setting(gid, "starboard_emoji", emoji)
        await ctx.send(embed=success_embed("Starboard Set", f"Channel: {channel.mention} | Stars needed: {count} | Emoji: {emoji}"))

    @commands.command(name="disablestarboard", help="Disable starboard")
    @commands.has_permissions(administrator=True)
    async def disablestarboard(self, ctx):
        update_setting(str(ctx.guild.id), "starboard_channel", None)
        await ctx.send(embed=success_embed("Starboard Disabled"))

    @commands.command(name="settings", help="View current server settings")
    @commands.has_permissions(administrator=True)
    async def settings(self, ctx):
        s = get_settings(str(ctx.guild.id))
        e = discord.Embed(title=f"⚙️ Settings for {ctx.guild.name}", color=0x3498db)
        
        def ch(cid): return f"<#{cid}>" if cid else "Not set"
        def ro(rid): return f"<@&{rid}>" if rid else "Not set"
        def yn(v): return "✅" if v else "❌"

        e.add_field(name="Welcome Channel", value=ch(s.get("welcome_channel")))
        e.add_field(name="Leave Channel", value=ch(s.get("leave_channel")))
        e.add_field(name="Log Channel", value=ch(s.get("log_channel")))
        e.add_field(name="Auto Role", value=ro(s.get("auto_role")))
        e.add_field(name="Prefix", value=f"`{s.get('prefix', '!')}`")
        e.add_field(name="XP System", value=yn(s.get("xp_enabled")))
        e.add_field(name="Economy", value=yn(s.get("economy_enabled")))
        e.add_field(name="Anti-Spam", value=yn(s.get("antispam")))
        e.add_field(name="Anti-Caps", value=yn(s.get("anticaps")))
        e.add_field(name="Anti-Invite", value=yn(s.get("antiinvite")))
        e.add_field(name="Anti-Links", value=yn(s.get("antilinks")))
        e.add_field(name="Starboard", value=ch(s.get("starboard_channel")))
        await ctx.send(embed=e)

    @commands.command(name="resetsettings", help="Reset all server settings")
    @commands.has_permissions(administrator=True)
    async def resetsettings(self, ctx):
        set_settings(str(ctx.guild.id), {})
        await ctx.send(embed=success_embed("Settings Reset", "All settings cleared."))

    @commands.command(name="addautorespond", help="Add auto-respond trigger")
    @commands.has_permissions(manage_messages=True)
    async def addautorespond(self, ctx, trigger: str, *, response: str):
        with db() as conn:
            conn.execute("INSERT OR REPLACE INTO autorespond VALUES (?,?,?)",
                         (str(ctx.guild.id), trigger.lower(), response))
            conn.commit()
        await ctx.send(embed=success_embed("Auto-Respond Added", f"Trigger: `{trigger}`\nResponse: {response}"))

    @commands.command(name="delautorespond", help="Delete auto-respond trigger")
    @commands.has_permissions(manage_messages=True)
    async def delautorespond(self, ctx, *, trigger: str):
        with db() as conn:
            conn.execute("DELETE FROM autorespond WHERE guild_id=? AND trigger=?",
                         (str(ctx.guild.id), trigger.lower()))
            conn.commit()
        await ctx.send(embed=success_embed("Auto-Respond Deleted", f"Trigger `{trigger}` removed."))

    @commands.command(name="autoresponds", help="List all auto-responds")
    @commands.has_permissions(manage_messages=True)
    async def autoresponds(self, ctx):
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT trigger, response FROM autorespond WHERE guild_id=?", (str(ctx.guild.id),))
            rows = c.fetchall()
        if not rows:
            return await ctx.send(embed=info_embed("No Auto-Responds"))
        desc = "\n".join(f"• `{t}` → {r[:40]}" for t, r in rows[:20])
        await ctx.send(embed=discord.Embed(title="🤖 Auto-Responds", description=desc, color=0x3498db))

    @commands.command(name="addcustomcommand", aliases=["addcmd"], help="Add custom command")
    @commands.has_permissions(manage_messages=True)
    async def addcustomcommand(self, ctx, name: str, *, response: str):
        with db() as conn:
            conn.execute("INSERT OR REPLACE INTO custom_commands VALUES (?,?,?)",
                         (str(ctx.guild.id), name.lower(), response))
            conn.commit()
        await ctx.send(embed=success_embed("Custom Command Added", f"Command: `!{name}`"))

    @commands.command(name="delcustomcommand", aliases=["delcmd"], help="Delete custom command")
    @commands.has_permissions(manage_messages=True)
    async def delcustomcommand(self, ctx, *, name: str):
        with db() as conn:
            conn.execute("DELETE FROM custom_commands WHERE guild_id=? AND name=?",
                         (str(ctx.guild.id), name.lower()))
            conn.commit()
        await ctx.send(embed=success_embed("Custom Command Deleted", f"`!{name}` removed."))

    @commands.command(name="customcommands", aliases=["cmds"], help="List custom commands")
    async def customcommands(self, ctx):
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT name FROM custom_commands WHERE guild_id=?", (str(ctx.guild.id),))
            rows = c.fetchall()
        if not rows:
            return await ctx.send(embed=info_embed("No Custom Commands"))
        desc = ", ".join(f"`!{r[0]}`" for r in rows)
        await ctx.send(embed=discord.Embed(title="📋 Custom Commands", description=desc, color=0x3498db))

    @commands.command(name="setmodrole", help="Set moderator role")
    @commands.has_permissions(administrator=True)
    async def setmodrole(self, ctx, role: discord.Role):
        update_setting(str(ctx.guild.id), "mod_role", str(role.id))
        await ctx.send(embed=success_embed("Mod Role Set", f"{role.mention} is now the mod role."))

    @commands.command(name="setadminrole", help="Set admin role for bot")
    @commands.has_permissions(administrator=True)
    async def setadminrole(self, ctx, role: discord.Role):
        update_setting(str(ctx.guild.id), "admin_role", str(role.id))
        await ctx.send(embed=success_embed("Admin Role Set", f"{role.mention} is now the admin role."))

    @commands.command(name="tempvc", help="Set temp VC hub channel")
    @commands.has_permissions(administrator=True)
    async def tempvc(self, ctx, vc: discord.VoiceChannel):
        update_setting(str(ctx.guild.id), "temp_vc_hub", str(vc.id))
        await ctx.send(embed=success_embed("Temp VC Set", f"`{vc.name}` is now the temp VC hub.\nJoin it to create your own VC!"))

    @commands.command(name="disabletempvc", help="Disable temp VC system")
    @commands.has_permissions(administrator=True)
    async def disabletempvc(self, ctx):
        update_setting(str(ctx.guild.id), "temp_vc_hub", None)
        await ctx.send(embed=success_embed("Temp VC Disabled"))

    @commands.command(name="reactionrole", help="Add reaction role. !reactionrole [msg_id] [emoji] @role")
    @commands.has_permissions(manage_roles=True)
    async def reactionrole(self, ctx, message_id: int, emoji: str, role: discord.Role):
        try:
            msg = await ctx.channel.fetch_message(message_id)
            await msg.add_reaction(emoji)
            with db() as conn:
                conn.execute("INSERT OR REPLACE INTO reaction_roles VALUES (?,?,?,?)",
                             (str(ctx.guild.id), str(message_id), emoji, str(role.id)))
                conn.commit()
            await ctx.send(embed=success_embed("Reaction Role Added", f"{emoji} → {role.mention}"))
        except Exception as e:
            await ctx.send(embed=error_embed("Error", str(e)))

    @commands.command(name="removereactionrole", help="Remove a reaction role")
    @commands.has_permissions(manage_roles=True)
    async def removereactionrole(self, ctx, message_id: int, emoji: str):
        with db() as conn:
            conn.execute("DELETE FROM reaction_roles WHERE guild_id=? AND message_id=? AND emoji=?",
                         (str(ctx.guild.id), str(message_id), emoji))
            conn.commit()
        await ctx.send(embed=success_embed("Reaction Role Removed"))

    @commands.command(name="listreactionroles", help="List all reaction roles")
    @commands.has_permissions(manage_roles=True)
    async def listreactionroles(self, ctx):
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT message_id, emoji, role_id FROM reaction_roles WHERE guild_id=?", (str(ctx.guild.id),))
            rows = c.fetchall()
        if not rows:
            return await ctx.send(embed=info_embed("No Reaction Roles"))
        desc = "\n".join(f"Msg `{m}` | {e} → <@&{r}>" for m, e, r in rows[:15])
        await ctx.send(embed=discord.Embed(title="🎭 Reaction Roles", description=desc, color=0x3498db))

    @commands.command(name="logmessages", help="Toggle message logging")
    @commands.has_permissions(administrator=True)
    async def logmessages(self, ctx, toggle: str):
        val = toggle.lower() in ("on", "true", "enable", "yes", "1")
        update_setting(str(ctx.guild.id), "log_messages", val)
        await ctx.send(embed=success_embed(f"Message Logging {'Enabled' if val else 'Disabled'}"))

    @commands.command(name="announce", help="Send announcement embed to a channel")
    @commands.has_permissions(manage_messages=True)
    async def announce(self, ctx, channel: discord.TextChannel, *, message: str):
        e = discord.Embed(description=message, color=0x3498db, timestamp=datetime.datetime.utcnow())
        e.set_author(name=ctx.guild.name, icon_url=ctx.guild.icon.url if ctx.guild.icon else None)
        e.set_footer(text=f"Announced by {ctx.author}")
        await channel.send(embed=e)
        await ctx.send(embed=success_embed("Announced", f"Message sent to {channel.mention}."), delete_after=5)

    @commands.command(name="say", help="Make bot say something")
    @commands.has_permissions(manage_messages=True)
    async def say(self, ctx, channel: Optional[discord.TextChannel], *, message: str):
        ch = channel or ctx.channel
        await ctx.message.delete()
        await ch.send(message)

    @commands.command(name="embed", help="Send a custom embed. !embed #channel Title|Description")
    @commands.has_permissions(manage_messages=True)
    async def embed_cmd(self, ctx, channel: discord.TextChannel, *, content: str):
        parts = content.split("|", 1)
        title = parts[0].strip()
        desc  = parts[1].strip() if len(parts) > 1 else None
        e = discord.Embed(title=title, description=desc, color=0x3498db)
        await channel.send(embed=e)
        await ctx.send(embed=success_embed("Embed Sent"), delete_after=3)

    @commands.command(name="dm", help="DM a member as the bot")
    @commands.has_permissions(administrator=True)
    async def dm(self, ctx, member: discord.Member, *, message: str):
        try:
            await member.send(f"📨 Message from **{ctx.guild.name}**:\n{message}")
            await ctx.send(embed=success_embed("DM Sent", f"Message sent to {member.mention}."))
        except:
            await ctx.send(embed=error_embed("Failed", f"Couldn't DM {member.mention}."))

    @commands.command(name="dmall", help="DM all members (use with caution)")
    @commands.has_permissions(administrator=True)
    async def dmall(self, ctx, *, message: str):
        msg = await ctx.send(embed=info_embed("DMing All Members", "This may take a while..."))
        count = 0
        for member in ctx.guild.members:
            if not member.bot:
                try:
                    await member.send(f"📨 Message from **{ctx.guild.name}**:\n{message}")
                    count += 1
                    await asyncio.sleep(1)
                except:
                    pass
        await msg.edit(embed=success_embed("DM Complete", f"Sent to `{count}` members."))

    @commands.command(name="poll", help="Create a poll")
    @commands.has_permissions(manage_messages=True)
    async def poll(self, ctx, *, question: str):
        e = discord.Embed(title="📊 Poll", description=question, color=0x3498db, timestamp=datetime.datetime.utcnow())
        e.set_footer(text=f"Poll by {ctx.author}")
        msg = await ctx.send(embed=e)
        await msg.add_reaction("👍")
        await msg.add_reaction("👎")
        await msg.add_reaction("🤷")

    @commands.command(name="custompoll", help="Create poll with options. !custompoll Question | A | B | C")
    @commands.has_permissions(manage_messages=True)
    async def custompoll(self, ctx, *, content: str):
        parts = [p.strip() for p in content.split("|")]
        if len(parts) < 2:
            return await ctx.send(embed=error_embed("Invalid", "Format: `Question | Option1 | Option2 | ...`"))
        question = parts[0]
        options = parts[1:]
        emojis = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
        desc = "\n".join(f"{emojis[i]} {opt}" for i, opt in enumerate(options[:10]))
        e = discord.Embed(title=f"📊 {question}", description=desc, color=0x3498db, timestamp=datetime.datetime.utcnow())
        e.set_footer(text=f"Poll by {ctx.author}")
        msg = await ctx.send(embed=e)
        for i in range(min(len(options), 10)):
            await msg.add_reaction(emojis[i])

    @commands.command(name="commandstats", help="View most used commands in this server")
    @commands.has_permissions(manage_messages=True)
    async def commandstats(self, ctx):
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT command, uses FROM command_stats WHERE guild_id=? ORDER BY uses DESC LIMIT 15",
                      (str(ctx.guild.id),))
            rows = c.fetchall()
        if not rows:
            return await ctx.send(embed=info_embed("No Stats"))
        desc = "\n".join(f"`#{i+1}` **{cmd}** — {uses} uses" for i, (cmd, uses) in enumerate(rows))
        await ctx.send(embed=discord.Embed(title="📊 Command Stats", description=desc, color=0x3498db))

    @commands.command(name="membercount", help="Show member count with stats")
    async def membercount(self, ctx):
        g = ctx.guild
        bots = sum(1 for m in g.members if m.bot)
        humans = g.member_count - bots
        online = sum(1 for m in g.members if m.status != discord.Status.offline)
        e = discord.Embed(title=f"👥 {g.name} Members", color=0x2ecc71)
        e.add_field(name="Total", value=g.member_count)
        e.add_field(name="Humans", value=humans)
        e.add_field(name="Bots", value=bots)
        e.add_field(name="Online", value=online)
        await ctx.send(embed=e)

    @commands.command(name="invites", help="View member's invite count")
    async def invites(self, ctx, member: Optional[discord.Member]):
        member = member or ctx.author
        invites = await ctx.guild.invites()
        count = sum(inv.uses for inv in invites if inv.inviter == member)
        await ctx.send(embed=info_embed("Invites", f"{member.mention} has invited `{count}` members."))

    @commands.command(name="allinvites", help="List all server invites")
    @commands.has_permissions(manage_guild=True)
    async def allinvites(self, ctx):
        invites = await ctx.guild.invites()
        if not invites:
            return await ctx.send(embed=info_embed("No Invites"))
        desc = "\n".join(f"• `{inv.code}` by {inv.inviter} — {inv.uses} uses" for inv in invites[:15])
        await ctx.send(embed=discord.Embed(title="🔗 Server Invites", description=desc, color=0x3498db))

    @commands.command(name="createinvite", help="Create an invite link")
    @commands.has_permissions(create_instant_invite=True)
    async def createinvite(self, ctx, channel: Optional[discord.TextChannel],
                           max_uses: int = 0, max_age: int = 0):
        ch = channel or ctx.channel
        inv = await ch.create_invite(max_uses=max_uses, max_age=max_age)
        await ctx.send(embed=info_embed("Invite Created", f"https://discord.gg/{inv.code}"))

    @commands.command(name="revokeinvite", help="Revoke an invite by code")
    @commands.has_permissions(manage_guild=True)
    async def revokeinvite(self, ctx, code: str):
        invites = await ctx.guild.invites()
        for inv in invites:
            if inv.code == code:
                await inv.delete()
                return await ctx.send(embed=success_embed("Invite Revoked", f"Invite `{code}` deleted."))
        await ctx.send(embed=error_embed("Not Found", f"Invite `{code}` not found."))

    @commands.command(name="joinlog", help="View recent join/leave events")
    @commands.has_permissions(manage_guild=True)
    async def joinlog(self, ctx, limit: int = 20):
        with db() as conn:
            c = conn.cursor()
            c.execute(
                "SELECT user_id, event, timestamp FROM join_leave_log WHERE guild_id=? ORDER BY rowid DESC LIMIT ?",
                (str(ctx.guild.id), limit)
            )
            rows = c.fetchall()
        if not rows:
            return await ctx.send(embed=info_embed("No Logs"))
        desc = "\n".join(
            f"{'✅' if ev=='join' else '❌'} <@{uid}> — {ts[:16]}"
            for uid, ev, ts in rows
        )
        await ctx.send(embed=discord.Embed(title="📋 Join/Leave Log", description=desc, color=0x3498db))

async def setup(bot):
    await bot.add_cog(Admin(bot))
