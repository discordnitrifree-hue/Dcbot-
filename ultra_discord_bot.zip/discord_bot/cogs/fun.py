"""FUN COG"""
import discord, random, asyncio, datetime
from discord.ext import commands
from typing import Optional

def i(t,d=None): return discord.Embed(title=f"ℹ️ {t}",description=d,color=0x3498db)
def s(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)

class Fun(commands.Cog):
    """🎮 Fun Commands"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="meme",help="Get a random meme")
    async def meme(self,ctx):
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get("https://meme-api.com/gimme") as r:
                if r.status==200:
                    data=await r.json()
                    em=discord.Embed(title=data["title"],url=data["postLink"],color=0xff4500)
                    em.set_image(url=data["url"])
                    em.set_footer(text=f"👍 {data['ups']} | r/{data['subreddit']}")
                    await ctx.send(embed=em)
                else:
                    await ctx.send(embed=i("Meme","Could not fetch meme right now."))

    @commands.command(name="joke",help="Get a random joke")
    async def joke(self,ctx):
        jokes=[
            ("Why don't scientists trust atoms?","Because they make up everything!"),
            ("I told my wife she was drawing her eyebrows too high.","She looked surprised."),
            ("Why can't a bicycle stand on its own?","Because it's two-tired!"),
            ("What's a skeleton's least favorite room?","The living room."),
            ("Why do cows wear bells?","Because their horns don't work!"),
        ]
        setup,punchline=random.choice(jokes)
        em=discord.Embed(title="😂 Joke",color=0xf1c40f)
        em.add_field(name="Setup",value=setup,inline=False)
        msg=await ctx.send(embed=em)
        await asyncio.sleep(2)
        em.add_field(name="Punchline",value=punchline,inline=False)
        await msg.edit(embed=em)

    @commands.command(name="dadjoke",help="Get a dad joke")
    async def dadjoke(self,ctx):
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.get("https://icanhazdadjoke.com/",headers={"Accept":"application/json"}) as r:
                data=await r.json()
        await ctx.send(embed=i("👨 Dad Joke",data["joke"]))

    @commands.command(name="fact",help="Get a random fact")
    async def fact(self,ctx):
        facts=[
            "A group of flamingos is called a 'flamboyance'.",
            "Honey never spoils. 3000-year-old honey found in Egyptian tombs was still good.",
            "The shortest war in history lasted only 38 minutes.",
            "Octopuses have three hearts and blue blood.",
            "A single cloud can weigh more than 1 million pounds.",
            "Cleopatra lived closer in time to the Moon landing than to the construction of the Great Pyramid.",
            "The human brain can store approximately 2.5 petabytes of information.",
            "There are more possible chess games than atoms in the universe.",
        ]
        await ctx.send(embed=i("🧠 Random Fact",random.choice(facts)))

    @commands.command(name="roast",help="Roast a member (all in fun!)")
    async def roast(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        roasts=[
            f"{m.mention}, you're the reason shampoo has instructions.",
            f"I'd agree with you {m.mention}, but then we'd both be wrong.",
            f"{m.mention}, I've seen better arguments in a kindergarten class.",
            f"You're not stupid {m.mention}, you just have bad luck thinking.",
            f"{m.mention}, if laughter is the best medicine, your face could cure the world.",
        ]
        em=discord.Embed(title="🔥 Roasted!",description=random.choice(roasts),color=0xe74c3c)
        em.set_footer(text="All in good fun! 😄")
        await ctx.send(embed=em)

    @commands.command(name="compliment",help="Compliment a member")
    async def compliment(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        compliments=[
            f"{m.mention}, you are an incredible human being!",
            f"{m.mention}, your kindness is an inspiration to us all.",
            f"{m.mention}, you light up every room you enter!",
            f"{m.mention}, you're talented beyond measure!",
            f"The world is a better place with {m.mention} in it! 🌟",
        ]
        em=discord.Embed(title="💕 Compliment",description=random.choice(compliments),color=0xff69b4)
        await ctx.send(embed=em)

    @commands.command(name="hug",help="Hug someone")
    async def hug(self,ctx,member:discord.Member):
        hugs=["(づ｡◕‿‿◕｡)づ","(⊃｡•́‿•̀｡)⊃","(つ≧▽≦)つ","⊂(・▽・⊂)","(つ✧ω✧)つ"]
        em=discord.Embed(description=f"{ctx.author.mention} hugs {member.mention}! {random.choice(hugs)}",color=0xff69b4)
        await ctx.send(embed=em)

    @commands.command(name="kiss",help="Kiss someone")
    async def kiss(self,ctx,member:discord.Member):
        em=discord.Embed(description=f"{ctx.author.mention} kisses {member.mention}! 💋",color=0xff69b4)
        await ctx.send(embed=em)

    @commands.command(name="pat",help="Pat someone")
    async def pat(self,ctx,member:discord.Member):
        em=discord.Embed(description=f"{ctx.author.mention} pats {member.mention}! (ﾉ◕ヮ◕)ﾉ",color=0xffd700)
        await ctx.send(embed=em)

    @commands.command(name="slap",help="Slap someone")
    async def slap(self,ctx,member:discord.Member):
        em=discord.Embed(description=f"{ctx.author.mention} slaps {member.mention}! 👋",color=0xe74c3c)
        await ctx.send(embed=em)

    @commands.command(name="punch",help="Punch someone")
    async def punch(self,ctx,member:discord.Member):
        em=discord.Embed(description=f"{ctx.author.mention} punches {member.mention}! 👊",color=0xe74c3c)
        await ctx.send(embed=em)

    @commands.command(name="ship",help="Ship two people")
    async def ship(self,ctx,m1:discord.Member,m2:Optional[discord.Member]):
        m2=m2 or ctx.author
        score=random.randint(1,100)
        bar_filled=int(score/5)
        bar="❤️"*bar_filled+"🖤"*(20-bar_filled)
        em=discord.Embed(title="💘 Shipping",color=0xff69b4)
        em.add_field(name="Couple",value=f"{m1.mention} ❤️ {m2.mention}",inline=False)
        em.add_field(name=f"Compatibility: {score}%",value=f"`[{bar}]`",inline=False)
        msg="💍 Soulmates!" if score>=90 else "💕 Great match!" if score>=70 else "🙂 Pretty good!" if score>=50 else "😬 Could be better..." if score>=30 else "💔 Probably not..."
        em.add_field(name="Verdict",value=msg)
        await ctx.send(embed=em)

    @commands.command(name="rps",help="Rock Paper Scissors")
    async def rps(self,ctx,choice:str):
        choices=["rock","paper","scissors"]
        emojis={"rock":"🪨","paper":"📄","scissors":"✂️"}
        choice=choice.lower()
        if choice not in choices: return await ctx.send(embed=discord.Embed(description="Choose: rock, paper, or scissors",color=0xe74c3c))
        bot_choice=random.choice(choices)
        wins={"rock":"scissors","paper":"rock","scissors":"paper"}
        if choice==bot_choice: result="It's a tie! 🤝"
        elif wins[choice]==bot_choice: result="You win! 🎉"
        else: result="Bot wins! 🤖"
        em=discord.Embed(title="✂️ Rock Paper Scissors",color=0x3498db)
        em.add_field(name="Your Choice",value=f"{emojis[choice]} {choice.title()}")
        em.add_field(name="Bot's Choice",value=f"{emojis[bot_choice]} {bot_choice.title()}")
        em.add_field(name="Result",value=result,inline=False)
        await ctx.send(embed=em)

    @commands.command(name="tictactoe",aliases=["ttt"],help="Play Tic Tac Toe with someone")
    async def tictactoe(self,ctx,member:discord.Member):
        if member==ctx.author: return await ctx.send("Can't play against yourself!")
        board=["⬛"]*9
        turn=0
        players=[ctx.author,member]
        symbols=["❌","⭕"]
        def render():
            return "\n".join(" ".join(board[i*3:(i+1)*3]) for i in range(3))
        def check_win():
            wins=[(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
            for a,b,c in wins:
                if board[a]==board[b]==board[c]!=":black_large_square:": return board[a]
            return None
        em=discord.Embed(title="Tic Tac Toe",description=render()+f"\n\n{players[0].mention}'s turn (❌)",color=0x3498db)
        msg=await ctx.send(embed=em)
        def check(m): return m.author==players[turn%2] and m.channel==ctx.channel and m.content in map(str,range(1,10))
        for _ in range(9):
            try:
                reply=await self.bot.wait_for("message",check=check,timeout=30)
                pos=int(reply.content)-1
                if board[pos]!="⬛": await ctx.send("That spot is taken!",delete_after=3); continue
                board[pos]=symbols[turn%2]
                turn+=1
                winner=check_win()
                if winner:
                    em.description=render()+f"\n\n{players[(turn-1)%2].mention} wins! {'❌' if winner=='❌' else '⭕'}"
                    em.color=0x2ecc71
                    return await msg.edit(embed=em)
                em.description=render()+f"\n\n{players[turn%2].mention}'s turn ({'❌' if turn%2==0 else '⭕'})"
                await msg.edit(embed=em)
            except asyncio.TimeoutError:
                em.description=render()+f"\n\n{players[turn%2].mention} timed out!"
                return await msg.edit(embed=em)
        em.description=render()+"\n\nIt's a draw!"
        await msg.edit(embed=em)

    @commands.command(name="hangman",help="Play Hangman")
    async def hangman(self,ctx):
        words=["python","discord","gaming","keyboard","monitor","internet","algorithm","programming"]
        word=random.choice(words)
        guessed=set()
        wrong=0
        max_wrong=6
        def display():
            return " ".join(c if c in guessed else "\_" for c in word)
        gallows=["```\n  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========```",
                 "```\n  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========```",
                 "```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========```",
                 "```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========```",
                 "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========```",
                 "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========```",
                 "```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========```"]
        em=discord.Embed(title="Hangman",description=f"{gallows[0]}\n**Word:** {display()}\n**Wrong guesses:** none",color=0x3498db)
        msg=await ctx.send(embed=em)
        def check(m): return m.author==ctx.author and m.channel==ctx.channel and len(m.content)==1 and m.content.isalpha()
        while wrong<max_wrong:
            try:
                reply=await self.bot.wait_for("message",check=check,timeout=60)
                letter=reply.content.lower()
                await reply.delete()
                if letter in guessed: continue
                guessed.add(letter)
                if letter in word:
                    if all(c in guessed for c in word):
                        em.description=f"{gallows[wrong]}\n**Word:** {display()}\n✅ You won! The word was **{word}**!"
                        em.color=0x2ecc71
                        return await msg.edit(embed=em)
                else:
                    wrong+=1
                    if wrong>=max_wrong:
                        em.description=f"{gallows[wrong]}\n❌ You lost! The word was **{word}**."
                        em.color=0xe74c3c
                        return await msg.edit(embed=em)
                wrong_letters=[c for c in guessed if c not in word]
                em.description=f"{gallows[wrong]}\n**Word:** {display()}\n**Wrong:** {', '.join(wrong_letters) or 'none'}"
                await msg.edit(embed=em)
            except asyncio.TimeoutError:
                return await msg.edit(embed=discord.Embed(title="Hangman - Timed Out!",description=f"The word was **{word}**.",color=0xe74c3c))

    @commands.command(name="wouldyourather",aliases=["wyr"],help="Would you rather")
    async def wouldyourather(self,ctx):
        import aiohttp
        options_list=[
            ("Fight 100 duck-sized horses","Fight 1 horse-sized duck"),
            ("Be able to fly","Be invisible"),
            ("Know how you die","Know when you die"),
            ("Have unlimited money","Have unlimited time"),
            ("Be able to speak any language","Be able to play any instrument"),
        ]
        a,b=random.choice(options_list)
        em=discord.Embed(title="🤔 Would You Rather...",color=0x9b59b6)
        em.add_field(name="Option A 🅰️",value=a)
        em.add_field(name="Option B 🅱️",value=b)
        msg=await ctx.send(embed=em)
        await msg.add_reaction("🅰️")
        await msg.add_reaction("🅱️")

    @commands.command(name="trivia",help="Answer a trivia question")
    async def trivia(self,ctx):
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get("https://opentdb.com/api.php?amount=1&type=multiple") as r:
                if r.status==200:
                    data=await r.json()
                    q=data["results"][0]
                    import html
                    question=html.unescape(q["question"])
                    correct=html.unescape(q["correct_answer"])
                    options=[correct]+[html.unescape(x) for x in q["incorrect_answers"]]
                    random.shuffle(options)
                    letters=["🇦","🇧","🇨","🇩"]
                    desc="\n".join(f"{letters[i]} {opt}" for i,opt in enumerate(options))
                    em=discord.Embed(title="🧠 Trivia",description=f"**{question}**\n\n{desc}",color=0x9b59b6)
                    em.add_field(name="Category",value=q["category"])
                    em.add_field(name="Difficulty",value=q["difficulty"].title())
                    msg=await ctx.send(embed=em)
                    correct_letter=letters[options.index(correct)]
                    def check(m): return m.author==ctx.author and m.channel==ctx.channel
                    try:
                        reply=await self.bot.wait_for("message",check=check,timeout=30)
                        if correct.lower() in reply.content.lower() or correct_letter in reply.content:
                            await ctx.send(embed=discord.Embed(description=f"✅ Correct! The answer was **{correct}**.",color=0x2ecc71))
                        else:
                            await ctx.send(embed=discord.Embed(description=f"❌ Wrong! The answer was **{correct}**.",color=0xe74c3c))
                    except asyncio.TimeoutError:
                        await ctx.send(embed=discord.Embed(description=f"⏰ Time's up! Answer: **{correct}**",color=0xe74c3c))
                else:
                    await ctx.send(embed=discord.Embed(description="Could not fetch trivia.",color=0xe74c3c))

    @commands.command(name="scramble",help="Word scramble game")
    async def scramble(self,ctx):
        words=["python","discord","server","keyboard","monitor","gaming","coding","developer"]
        word=random.choice(words)
        scrambled=list(word); random.shuffle(scrambled); scrambled="".join(scrambled)
        em=discord.Embed(title="🔤 Word Scramble",description=f"Unscramble: **{scrambled}**\n\nYou have 30 seconds!",color=0x9b59b6)
        await ctx.send(embed=em)
        def check(m): return m.author==ctx.author and m.channel==ctx.channel
        try:
            reply=await self.bot.wait_for("message",check=check,timeout=30)
            if reply.content.lower()==word:
                await ctx.send(embed=discord.Embed(description=f"✅ Correct! The word was **{word}**!",color=0x2ecc71))
            else:
                await ctx.send(embed=discord.Embed(description=f"❌ Wrong! The word was **{word}**.",color=0xe74c3c))
        except asyncio.TimeoutError:
            await ctx.send(embed=discord.Embed(description=f"⏰ Time's up! The word was **{word}**.",color=0xe74c3c))

    @commands.command(name="counting",help="Start a counting game")
    async def counting(self,ctx):
        await ctx.send(embed=discord.Embed(description="🔢 Counting game! Start from 1. I'll tell you if you go wrong!\nUse `!stopcounting` to stop.",color=0x3498db))

    @commands.command(name="truthordare",aliases=["tod"],help="Truth or Dare")
    async def truthordare(self,ctx):
        truths=["What's your biggest fear?","What's the most embarrassing thing that happened to you?","Who was your first crush?","What's a secret you've never told anyone?"]
        dares=["Do 20 pushups right now.","Send a funny GIF in chat.","Type with your eyes closed.","Change your nickname to 'Dummy' for 10 minutes."]
        choice=random.choice(["truth","dare"])
        if choice=="truth":
            em=discord.Embed(title="🤫 TRUTH",description=random.choice(truths),color=0x3498db)
        else:
            em=discord.Embed(title="😈 DARE",description=random.choice(dares),color=0xe74c3c)
        await ctx.send(embed=em)

    @commands.command(name="pp",help="PP size checker 😅")
    async def pp(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        size=random.randint(1,20)
        bar="8"+"="*size+"D"
        em=discord.Embed(title=f"📏 {m.display_name}'s PP",description=f"`{bar}` ({size} inches)",color=0xf1c40f)
        em.set_footer(text="Just for fun! 😄")
        await ctx.send(embed=em)

    @commands.command(name="gay",help="Gay meter 🏳️‍🌈")
    async def gay(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        pct=random.randint(0,100)
        em=discord.Embed(title=f"🏳️‍🌈 {m.display_name}'s Gay Meter",description=f"**{pct}% gay**",color=0xff69b4)
        em.set_footer(text="Just for fun! 🌈")
        await ctx.send(embed=em)

    @commands.command(name="iq",help="IQ tester")
    async def iq(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        iq=random.randint(1,200)
        em=discord.Embed(title=f"🧠 {m.display_name}'s IQ",description=f"**{iq} IQ**",color=0x9b59b6)
        msg="Genius! 🧠" if iq>160 else "Above average! 😊" if iq>110 else "Average" if iq>90 else "Below average 😅" if iq>70 else "Hmm... 🤔"
        em.add_field(name="Verdict",value=msg)
        await ctx.send(embed=em)

    @commands.command(name="simp",help="Simp checker")
    async def simp(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        pct=random.randint(0,100)
        em=discord.Embed(title=f"😍 {m.display_name}'s Simp Meter",description=f"**{pct}% simp**",color=0xff69b4)
        await ctx.send(embed=em)

    @commands.command(name="ascii",help="Convert text to ASCII art")
    async def ascii(self,ctx,*,text:str):
        try:
            import pyfiglet
            result=pyfiglet.figlet_format(text[:15])
            await ctx.send(f"```\n{result}\n```")
        except ImportError:
            await ctx.send(embed=discord.Embed(description="Install `pyfiglet` for ASCII art: `pip install pyfiglet`",color=0xe74c3c))

    @commands.command(name="reverse",help="Reverse text")
    async def reverse(self,ctx,*,text:str):
        await ctx.send(embed=discord.Embed(description=f"**Reversed:** {text[::-1]}",color=0x3498db))

    @commands.command(name="mock",help="Mock text (SpOnGeBoB)")
    async def mock(self,ctx,*,text:str):
        result="".join(c.upper() if i%2 else c.lower() for i,c in enumerate(text))
        await ctx.send(embed=discord.Embed(description=result,color=0xf39c12))

    @commands.command(name="emojify",help="Convert text to emoji letters")
    async def emojify(self,ctx,*,text:str):
        emoji_map={c:f":regional_indicator_{c}:" for c in "abcdefghijklmnopqrstuvwxyz"}
        emoji_map[" "]="   "
        result=" ".join(emoji_map.get(c.lower(),c) for c in text[:30])
        await ctx.send(result)

    @commands.command(name="catfact",help="Get a cat fact")
    async def catfact(self,ctx):
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get("https://catfact.ninja/fact") as r:
                data=await r.json()
        await ctx.send(embed=discord.Embed(title="🐱 Cat Fact",description=data["fact"],color=0xf39c12))

    @commands.command(name="dogfact",help="Get a dog fact")
    async def dogfact(self,ctx):
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get("https://dog-api.kinduff.com/api/facts") as r:
                data=await r.json()
        await ctx.send(embed=discord.Embed(title="🐶 Dog Fact",description=data["facts"][0],color=0xc0a060))

    @commands.command(name="inspire",help="Get an inspirational quote")
    async def inspire(self,ctx):
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get("https://zenquotes.io/api/random") as r:
                data=await r.json()
        q=data[0]
        em=discord.Embed(title="✨ Inspiration",description=f"*\"{q['q']}\"*\n— **{q['a']}**",color=0x9b59b6)
        await ctx.send(embed=em)

    @commands.command(name="lenny",help="( ͡° ͜ʖ ͡°)")
    async def lenny(self,ctx):
        faces=["( ͡° ͜ʖ ͡°)","(ง ͠° ͟ل͜ ͡°)ง","¯\\_(ツ)_/¯","(╯°□°）╯︵ ┻━┻","┻━┻ ︵ヽ(`Д´)ﾉ︵ ┻━┻"]
        await ctx.send(random.choice(faces))

    @commands.command(name="tableflip",help="(╯°□°）╯︵ ┻━┻")
    async def tableflip(self,ctx):
        await ctx.send("(╯°□°）╯︵ ┻━┻")

    @commands.command(name="unflip",help="┬─┬ノ(ಠ_ಠノ)")
    async def unflip(self,ctx):
        await ctx.send("┬─┬ノ(ಠ_ಠノ)")

    @commands.command(name="shrug",help="¯\\_(ツ)_/¯")
    async def shrug(self,ctx):
        await ctx.send("¯\\_(ツ)_/¯")

    @commands.command(name="number",help="Get a fact about a number")
    async def number(self,ctx,n:int=None):
        n=n or random.randint(1,9999)
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(f"http://numbersapi.com/{n}") as r:
                text=await r.text()
        await ctx.send(embed=discord.Embed(title=f"🔢 Number {n}",description=text,color=0x3498db))

    @commands.command(name="activity",help="Get a random activity idea")
    async def activity(self,ctx):
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get("https://www.boredapi.com/api/activity") as r:
                data=await r.json()
        em=discord.Embed(title="🎯 Activity Idea",description=data["activity"],color=0x2ecc71)
        em.add_field(name="Type",value=data["type"].title())
        em.add_field(name="Participants",value=data["participants"])
        await ctx.send(embed=em)

async def setup(bot):
    await bot.add_cog(Fun(bot))
