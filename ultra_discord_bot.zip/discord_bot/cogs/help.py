"""HELP COG"""
import discord, datetime
from discord.ext import commands
from typing import Optional

class Help(commands.Cog):
    """❓ Help System"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="help",aliases=["h","commands"],help="Show help menu")
    async def help_cmd(self,ctx,*,category:str=None):
        prefix=ctx.prefix

        if category:
            # Search for cog
            cog=None
            for c in self.bot.cogs.values():
                if c.qualified_name.lower()==category.lower() or category.lower() in c.qualified_name.lower():
                    cog=c; break
            if cog:
                cmds=[cmd for cmd in cog.get_commands() if not cmd.hidden]
                if not cmds:
                    return await ctx.send(embed=discord.Embed(description="No commands in this category.",color=0xe74c3c))
                desc="\n".join(f"`{prefix}{cmd.name}` {'`'+'|'.join(cmd.aliases)+'`' if cmd.aliases else ''} — {cmd.help or 'No description'}" for cmd in cmds)
                em=discord.Embed(
                    title=f"{cog.description or cog.qualified_name}",
                    description=desc,
                    color=0x3498db
                )
                em.set_footer(text=f"Use {prefix}help for main menu | {len(cmds)} commands")
                return await ctx.send(embed=em)

            # Search for specific command
            cmd=self.bot.get_command(category)
            if cmd:
                em=discord.Embed(title=f"Command: {prefix}{cmd.name}",color=0x3498db)
                em.add_field(name="Description",value=cmd.help or "No description",inline=False)
                em.add_field(name="Usage",value=f"`{prefix}{cmd.name} {cmd.signature}`",inline=False)
                if cmd.aliases: em.add_field(name="Aliases",value=", ".join(f"`{a}`" for a in cmd.aliases),inline=False)
                return await ctx.send(embed=em)

            return await ctx.send(embed=discord.Embed(description=f"❌ Category or command `{category}` not found.",color=0xe74c3c))

        # Main help embed
        em=discord.Embed(
            title="🤖 Ultra Bot — Command Help",
            description=(
                f"**Prefix:** `{prefix}` | Use `{prefix}help <category>` for details\n"
                f"**Total Commands:** {len([c for c in self.bot.commands if not c.hidden])}\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━━"
            ),
            color=0x3498db,
            timestamp=datetime.datetime.utcnow()
        )

        categories = {
            "🛡️ Moderation": ("Moderation", "ban, kick, mute, warn, purge, lock, role, nick, slowmode..."),
            "👑 Admin":       ("Admin",       "setup, welcome, log, autorole, antispam, poll, announce..."),
            "⚙️ Config":      ("Config",      "config, enablemodule, disablemodule, exportconfig..."),
            "🔧 Utility":     ("Utility",     "afk, remind, avatar, ping, calc, color, qr, urban..."),
            "🏷️ Tags":        ("Tags",        "tag, tagcreate, tagdelete, taglist, taginfo, mytags..."),
            "📋 Info":        ("Info",        "userinfo, guildinfo, roles, permissions, boosts..."),
            "🎉 Giveaway":    ("Giveaway",    "gstart, gend, greroll, glist, gdelete..."),
            "🎫 Tickets":     ("Tickets",     "ticket, closeticket, addtoticket, ticketstats..."),
            "💰 Economy":     ("Economy",     "balance, daily, work, crime, beg, pay, slots, rob..."),
            "⭐ Leveling":    ("Leveling",    "rank, xplb, setxp, setlevel, givexp, resetxp..."),
            "🎮 Fun":         ("Fun",         "meme, joke, ship, roast, 8ball, trivia, rps, wordle..."),
            "🕹️ Games":       ("Games",       "guess, wordle, tictactoe, hangman, math, fasttype..."),
            "🎵 Music":       ("Music",       "play, pause, resume, skip, stop, volume, queue..."),
        }

        for emoji_name, (cog_name, preview) in categories.items():
            cog=None
            for c in self.bot.cogs.values():
                if c.qualified_name==cog_name:
                    cog=c; break
            count=len(cog.get_commands()) if cog else 0
            em.add_field(
                name=f"{emoji_name} [{count}]",
                value=f"`{prefix}help {cog_name.lower()}`\n*{preview}*",
                inline=True
            )

        em.add_field(
            name="🔗 Links",
            value="[Support Server](https://discord.gg/example) | [Invite Bot](https://discord.com/oauth2/authorize)",
            inline=False
        )
        em.set_thumbnail(url=self.bot.user.display_avatar.url)
        em.set_footer(text=f"Requested by {ctx.author} | Ultra Bot v1.0")
        await ctx.send(embed=em)

    @commands.command(name="allcommands",aliases=["allcmds"],help="List every single command")
    async def allcommands(self,ctx):
        cmds=sorted([c for c in self.bot.commands if not c.hidden],key=lambda c:c.name)
        chunks=[]
        chunk=""
        for cmd in cmds:
            entry=f"`!{cmd.name}` "
            if len(chunk)+len(entry)>1000:
                chunks.append(chunk)
                chunk=""
            chunk+=entry
        if chunk: chunks.append(chunk)

        em=discord.Embed(title=f"📋 All Commands ({len(cmds)} total)",color=0x3498db)
        for i,chunk in enumerate(chunks[:5]):
            em.add_field(name=f"Page {i+1}",value=chunk,inline=False)
        em.set_footer(text="Use !help <command> for detailed info")
        await ctx.send(embed=em)

    @commands.command(name="commandcount",help="Count of commands per category")
    async def commandcount(self,ctx):
        em=discord.Embed(title="📊 Command Count per Category",color=0x3498db)
        total=0
        for cog_name,cog in self.bot.cogs.items():
            count=len(cog.get_commands())
            total+=count
            em.add_field(name=cog.description or cog_name,value=f"{count} commands")
        em.add_field(name="**TOTAL**",value=f"**{total} commands**",inline=False)
        await ctx.send(embed=em)

    @commands.command(name="botinvite",help="Get bot invite link")
    async def botinvite(self,ctx):
        perms=discord.Permissions(administrator=True)
        url=discord.utils.oauth_url(self.bot.user.id,permissions=perms)
        em=discord.Embed(title="🔗 Invite Bot",description=f"[Click here to invite the bot!]({url})",color=0x3498db)
        await ctx.send(embed=em)

    @commands.command(name="support",help="Get support server link")
    async def support(self,ctx):
        await ctx.send(embed=discord.Embed(title="🆘 Support",description="Join: https://discord.gg/your-support-server",color=0x3498db))

    @commands.command(name="vote",help="Vote for the bot")
    async def vote(self,ctx):
        await ctx.send(embed=discord.Embed(title="⬆️ Vote",description="Vote at: https://top.gg/bot/your-bot-id",color=0x3498db))

    @commands.command(name="changelog",help="View recent bot changes")
    async def changelog(self,ctx):
        em=discord.Embed(title="📰 Changelog — v1.0",color=0x3498db)
        em.add_field(name="v1.0 — Initial Release",value=(
            "• 1000+ commands added\n"
            "• Moderation suite\n"
            "• Economy system\n"
            "• XP & Leveling\n"
            "• Ticket system\n"
            "• Giveaway system\n"
            "• Starboard\n"
            "• Reaction roles\n"
            "• Temp voice channels\n"
            "• Anti-spam, Anti-caps, Anti-invite, Anti-links\n"
            "• Auto-responder\n"
            "• Custom commands\n"
            "• Tags system\n"
            "• Fun & Games commands\n"
        ),inline=False)
        await ctx.send(embed=em)

    @commands.command(name="privacy",help="Bot privacy policy")
    async def privacy(self,ctx):
        em=discord.Embed(title="🔒 Privacy Policy",color=0x3498db,
            description="This bot stores:\n• Server settings\n• User XP/Economy data\n• Warnings & Notes\n• Reminders\n• Tags\n\nData is per-server and can be cleared by admins.")
        await ctx.send(embed=em)

async def setup(bot):
    await bot.add_cog(Help(bot))
