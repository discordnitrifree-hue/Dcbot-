"""TICKETS COG"""
import discord, datetime, sqlite3
from discord.ext import commands
from typing import Optional

def db(): return sqlite3.connect("ultrabot.db")
def s(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)
def e(t,d=None): return discord.Embed(title=f"❌ {t}",description=d,color=0xe74c3c)
def i(t,d=None): return discord.Embed(title=f"ℹ️ {t}",description=d,color=0x3498db)

class Tickets(commands.Cog):
    """🎫 Ticket System"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="ticket",aliases=["newticket"],help="Open a support ticket")
    async def ticket(self,ctx,*,reason:str="No reason provided"):
        guild=ctx.guild
        category_id=None
        import json
        try:
            with db() as conn:
                c=conn.cursor()
                c.execute("SELECT settings FROM guild_settings WHERE guild_id=?",(str(guild.id),))
                row=c.fetchone()
                if row:
                    settings=json.loads(row[0])
                    category_id=settings.get("ticket_category")
        except: pass

        category=guild.get_channel(int(category_id)) if category_id else None
        
        overwrites={
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            ctx.author: discord.PermissionOverwrite(view_channel=True,send_messages=True),
            guild.me: discord.PermissionOverwrite(view_channel=True,send_messages=True)
        }
        
        # Add support role if set
        try:
            settings={}
            with db() as conn:
                c=conn.cursor()
                c.execute("SELECT settings FROM guild_settings WHERE guild_id=?",(str(guild.id),))
                row=c.fetchone()
                if row: settings=json.loads(row[0])
            support_role_id=settings.get("support_role")
            if support_role_id:
                support_role=guild.get_role(int(support_role_id))
                if support_role:
                    overwrites[support_role]=discord.PermissionOverwrite(view_channel=True,send_messages=True)
        except: pass

        ch=await guild.create_text_channel(
            name=f"ticket-{ctx.author.name[:20]}",
            category=category,
            overwrites=overwrites,
            topic=f"Ticket by {ctx.author} | {reason}"
        )
        
        em=discord.Embed(title="🎫 Ticket Opened",color=0x2ecc71,timestamp=datetime.datetime.utcnow())
        em.add_field(name="User",value=ctx.author.mention)
        em.add_field(name="Reason",value=reason)
        em.set_footer(text="React with 🔒 to close ticket.")
        msg=await ch.send(content=ctx.author.mention,embed=em)
        await msg.add_reaction("🔒")
        
        with db() as conn:
            conn.execute(
                "INSERT INTO tickets (guild_id,channel_id,user_id,status,opened_at) VALUES (?,?,?,?,?)",
                (str(guild.id),str(ch.id),str(ctx.author.id),"open",datetime.datetime.utcnow().isoformat())
            )
            conn.commit()
        
        await ctx.send(embed=s("Ticket Created",f"Your ticket is at {ch.mention}."),delete_after=10)

    @commands.command(name="closeticket",aliases=["close"],help="Close a ticket channel")
    @commands.has_permissions(manage_channels=True)
    async def closeticket(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT id,user_id FROM tickets WHERE channel_id=? AND status='open'",(str(ctx.channel.id),))
            row=c.fetchone()
        if not row:
            return await ctx.send(embed=e("Not a Ticket","This is not an open ticket channel."))
        
        # Save transcript
        transcript=[]
        async for msg in ctx.channel.history(limit=500,oldest_first=True):
            transcript.append(f"[{msg.created_at.strftime('%H:%M')}] {msg.author}: {msg.content}")
        transcript_text="\n".join(transcript)
        
        with db() as conn:
            conn.execute("UPDATE tickets SET status='closed',closed_at=?,transcript=? WHERE id=?",
                         (datetime.datetime.utcnow().isoformat(),transcript_text[:10000],row[0]))
            conn.commit()
        
        await ctx.send(embed=s("Ticket Closing","This ticket will be deleted in 5 seconds."))
        import asyncio; await asyncio.sleep(5)
        try: await ctx.channel.delete()
        except: pass

    @commands.command(name="addtoticket",help="Add user to ticket")
    @commands.has_permissions(manage_channels=True)
    async def addtoticket(self,ctx,member:discord.Member):
        await ctx.channel.set_permissions(member,view_channel=True,send_messages=True)
        await ctx.send(embed=s("User Added",f"{member.mention} added to ticket."))

    @commands.command(name="removefromticket",help="Remove user from ticket")
    @commands.has_permissions(manage_channels=True)
    async def removefromticket(self,ctx,member:discord.Member):
        await ctx.channel.set_permissions(member,view_channel=False)
        await ctx.send(embed=s("User Removed",f"{member.mention} removed from ticket."))

    @commands.command(name="tickets",help="List all open tickets")
    @commands.has_permissions(manage_channels=True)
    async def tickets_list(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT channel_id,user_id,opened_at FROM tickets WHERE guild_id=? AND status='open'",(str(ctx.guild.id),))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=i("No Open Tickets"))
        desc="\n".join(f"• <#{chid}> — <@{uid}> — {opened[:10]}" for chid,uid,opened in rows)
        await ctx.send(embed=discord.Embed(title=f"🎫 Open Tickets ({len(rows)})",description=desc,color=0x3498db))

    @commands.command(name="setticketcategory",help="Set ticket category")
    @commands.has_permissions(administrator=True)
    async def setticketcategory(self,ctx,category:discord.CategoryChannel):
        import json
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT settings FROM guild_settings WHERE guild_id=?",(str(ctx.guild.id),))
            row=c.fetchone()
            settings=json.loads(row[0]) if row else {}
            settings["ticket_category"]=str(category.id)
            conn.execute("INSERT OR REPLACE INTO guild_settings VALUES (?,?)",(str(ctx.guild.id),json.dumps(settings)))
            conn.commit()
        await ctx.send(embed=s("Category Set",f"Tickets will be created in `{category.name}`."))

    @commands.command(name="setsupportrole",help="Set support role for tickets")
    @commands.has_permissions(administrator=True)
    async def setsupportrole(self,ctx,role:discord.Role):
        import json
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT settings FROM guild_settings WHERE guild_id=?",(str(ctx.guild.id),))
            row=c.fetchone()
            settings=json.loads(row[0]) if row else {}
            settings["support_role"]=str(role.id)
            conn.execute("INSERT OR REPLACE INTO guild_settings VALUES (?,?)",(str(ctx.guild.id),json.dumps(settings)))
            conn.commit()
        await ctx.send(embed=s("Support Role Set",f"{role.mention} can see all tickets."))

    @commands.command(name="ticketstats",help="View ticket statistics")
    @commands.has_permissions(manage_channels=True)
    async def ticketstats(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT COUNT(*) FROM tickets WHERE guild_id=?",(str(ctx.guild.id),))
            total=c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM tickets WHERE guild_id=? AND status='open'",(str(ctx.guild.id),))
            open_t=c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM tickets WHERE guild_id=? AND status='closed'",(str(ctx.guild.id),))
            closed=c.fetchone()[0]
        em=discord.Embed(title="🎫 Ticket Stats",color=0x3498db)
        em.add_field(name="Total",value=total)
        em.add_field(name="Open",value=open_t)
        em.add_field(name="Closed",value=closed)
        await ctx.send(embed=em)

async def setup(bot):
    await bot.add_cog(Tickets(bot))
