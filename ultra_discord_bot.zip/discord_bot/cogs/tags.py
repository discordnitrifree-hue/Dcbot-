"""TAGS COG"""
import discord, sqlite3, datetime
from discord.ext import commands
from typing import Optional

def db(): return sqlite3.connect("ultrabot.db")
def s(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)
def e(t,d=None): return discord.Embed(title=f"❌ {t}",description=d,color=0xe74c3c)
def i(t,d=None): return discord.Embed(title=f"ℹ️ {t}",description=d,color=0x3498db)

class Tags(commands.Cog):
    """🏷️ Tags System"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="tags",aliases=["taglist"],help="List all tags")
    async def tags_list(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT name,uses FROM tags WHERE guild_id=? ORDER BY uses DESC",(str(ctx.guild.id),))
            rows=c.fetchall()
        if not rows:
            return await ctx.send(embed=i("No Tags","Create one with `!tagcreate name content`"))
        desc="\n".join(f"`{r[0]}` — {r[1]} uses" for r in rows[:20])
        if len(rows)>20: desc+=f"\n*...and {len(rows)-20} more*"
        await ctx.send(embed=discord.Embed(title=f"🏷️ Tags ({len(rows)})",description=desc,color=0x3498db))

    @commands.command(name="tagraw",help="View raw tag content")
    async def tagraw(self,ctx,*,name:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT content FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            row=c.fetchone()
        if not row: return await ctx.send(embed=e("Not Found"))
        await ctx.send(f"```\n{row[0][:1900]}\n```")

    @commands.command(name="tagtransfer",help="Transfer tag ownership")
    async def tagtransfer(self,ctx,name:str,member:discord.Member):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT author_id FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            row=c.fetchone()
        if not row: return await ctx.send(embed=e("Not Found"))
        if row[0]!=str(ctx.author.id) and not ctx.author.guild_permissions.manage_messages:
            return await ctx.send(embed=e("Not Yours","You don't own this tag."))
        with db() as conn:
            conn.execute("UPDATE tags SET author_id=? WHERE guild_id=? AND name=?",(str(member.id),str(ctx.guild.id),name.lower()))
            conn.commit()
        await ctx.send(embed=s("Tag Transferred",f"Tag `{name}` transferred to {member.mention}."))

    @commands.command(name="tagstats",help="Tag statistics")
    async def tagstats(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT COUNT(*),SUM(uses) FROM tags WHERE guild_id=?",(str(ctx.guild.id),))
            total,total_uses=c.fetchone()
            c.execute("SELECT name,uses FROM tags WHERE guild_id=? ORDER BY uses DESC LIMIT 1",(str(ctx.guild.id),))
            top=c.fetchone()
        em=discord.Embed(title="🏷️ Tag Stats",color=0x3498db)
        em.add_field(name="Total Tags",value=total or 0)
        em.add_field(name="Total Uses",value=total_uses or 0)
        em.add_field(name="Most Used",value=f"`{top[0]}` ({top[1]} uses)" if top else "None")
        await ctx.send(embed=em)

    @commands.command(name="tagalias",help="Create alias for a tag")
    @commands.has_permissions(manage_messages=True)
    async def tagalias(self,ctx,original:str,alias:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT content,author_id FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),original.lower()))
            row=c.fetchone()
        if not row: return await ctx.send(embed=e("Not Found",f"Tag `{original}` doesn't exist."))
        with db() as conn:
            conn.execute("INSERT OR REPLACE INTO tags VALUES (?,?,?,?,0)",(str(ctx.guild.id),alias.lower(),row[0],str(ctx.author.id)))
            conn.commit()
        await ctx.send(embed=s("Alias Created",f"`{alias}` now points to `{original}`."))

    @commands.command(name="tagclaim",help="Claim a tag whose owner left")
    async def tagclaim(self,ctx,*,name:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT author_id FROM tags WHERE guild_id=? AND name=?",(str(ctx.guild.id),name.lower()))
            row=c.fetchone()
        if not row: return await ctx.send(embed=e("Not Found"))
        member=ctx.guild.get_member(int(row[0]))
        if member: return await ctx.send(embed=e("Cannot Claim","Tag owner is still in the server."))
        with db() as conn:
            conn.execute("UPDATE tags SET author_id=? WHERE guild_id=? AND name=?",(str(ctx.author.id),str(ctx.guild.id),name.lower()))
            conn.commit()
        await ctx.send(embed=s("Tag Claimed",f"You now own the tag `{name}`."))

    @commands.command(name="mytags",help="List your own tags")
    async def mytags(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT name,uses FROM tags WHERE guild_id=? AND author_id=?",(str(ctx.guild.id),str(ctx.author.id)))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=i("No Tags","You haven't created any tags."))
        desc="\n".join(f"`{r[0]}` — {r[1]} uses" for r in rows)
        await ctx.send(embed=discord.Embed(title=f"🏷️ Your Tags ({len(rows)})",description=desc,color=0x9b59b6))

    @commands.command(name="topsearch",help="Search tags by name")
    async def topsearch(self,ctx,*,query:str):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT name,uses FROM tags WHERE guild_id=? AND name LIKE ? ORDER BY uses DESC LIMIT 10",
                      (str(ctx.guild.id),f"%{query}%"))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=e("Not Found",f"No tags matching `{query}`."))
        desc="\n".join(f"`{r[0]}` — {r[1]} uses" for r in rows)
        await ctx.send(embed=discord.Embed(title=f"🔍 Tag Search: {query}",description=desc,color=0x3498db))

async def setup(bot):
    await bot.add_cog(Tags(bot))
