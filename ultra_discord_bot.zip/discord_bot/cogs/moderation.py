"""
MODERATION COG - 150+ Moderation Commands
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import datetime
import json
import re
import sqlite3
from typing import Optional, Union

def db():
    return sqlite3.connect("ultrabot.db")

def success_embed(title, desc=None):
    return discord.Embed(title=f"✅ {title}", description=desc, color=0x2ecc71)

def error_embed(title, desc=None):
    return discord.Embed(title=f"❌ {title}", description=desc, color=0xe74c3c)

def info_embed(title, desc=None):
    return discord.Embed(title=f"ℹ️ {title}", description=desc, color=0x3498db)

def warn_embed(title, desc=None):
    return discord.Embed(title=f"⚠️ {title}", description=desc, color=0xf39c12)

def parse_time(s: str) -> int:
    total = 0
    for val, unit in re.findall(r'(\d+)([dhms])', s.lower()):
        val = int(val)
        if unit == 'd': total += val * 86400
        elif unit == 'h': total += val * 3600
        elif unit == 'm': total += val * 60
        elif unit == 's': total += val
    return total

def format_seconds(sec: int) -> str:
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    parts = []
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    if s: parts.append(f"{s}s")
    return " ".join(parts) or "0s"

async def send_log(guild, embed):
    from bot import get_settings
    s = get_settings(str(guild.id))
    lch_id = s.get("log_channel")
    if lch_id:
        lch = guild.get_channel(int(lch_id))
        if lch:
            try:
                await lch.send(embed=embed)
            except:
                pass

class Moderation(commands.Cog):
    """🛡️ Moderation - 150+ Commands"""

    def __init__(self, bot):
        self.bot = bot

    # ────────────────────── BAN ──────────────────────────────
    @commands.command(name="ban", help="Ban a member")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason="No reason provided"):
        if member.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("Hierarchy Error", "You can't ban someone with equal or higher role."))
        await member.ban(reason=f"{ctx.author} | {reason}")
        e = success_embed("Member Banned", f"{member.mention} has been banned.")
        e.add_field(name="Reason", value=reason)
        e.add_field(name="Moderator", value=ctx.author.mention)
        await ctx.send(embed=e)
        log_e = discord.Embed(title="🔨 Member Banned", color=0xe74c3c, timestamp=datetime.datetime.utcnow())
        log_e.add_field(name="Member", value=f"{member} ({member.id})")
        log_e.add_field(name="Moderator", value=str(ctx.author))
        log_e.add_field(name="Reason", value=reason)
        await send_log(ctx.guild, log_e)

    @commands.command(name="unban", help="Unban a user by ID or name#tag")
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, *, user: str):
        bans = [entry async for entry in ctx.guild.bans()]
        target = None
        for ban in bans:
            if str(ban.user.id) == user or str(ban.user) == user:
                target = ban.user
                break
        if not target:
            return await ctx.send(embed=error_embed("Not Found", "User not found in ban list."))
        await ctx.guild.unban(target)
        await ctx.send(embed=success_embed("User Unbanned", f"{target} has been unbanned."))

    @commands.command(name="softban", help="Ban and immediately unban (deletes messages)")
    @commands.has_permissions(ban_members=True)
    async def softban(self, ctx, member: discord.Member, *, reason="No reason"):
        if member.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("Hierarchy Error", "Can't softban someone with equal/higher role."))
        await member.ban(reason=f"Softban | {ctx.author} | {reason}", delete_message_days=7)
        await ctx.guild.unban(member)
        await ctx.send(embed=success_embed("Soft Banned", f"{member.mention} was soft-banned (messages deleted)."))

    @commands.command(name="tempban", help="Temporarily ban a member. Usage: !tempban @user 1d reason")
    @commands.has_permissions(ban_members=True)
    async def tempban(self, ctx, member: discord.Member, duration: str, *, reason="No reason"):
        secs = parse_time(duration)
        if secs == 0:
            return await ctx.send(embed=error_embed("Invalid Time", "Use format like `1d`, `2h`, `30m`."))
        await member.ban(reason=f"Tempban {duration} | {ctx.author} | {reason}")
        await ctx.send(embed=success_embed("Temp Banned", f"{member.mention} banned for `{format_seconds(secs)}`."))
        await asyncio.sleep(secs)
        try:
            await ctx.guild.unban(member, reason="Tempban expired")
        except:
            pass

    @commands.command(name="banlist", help="Show list of banned users")
    @commands.has_permissions(ban_members=True)
    async def banlist(self, ctx):
        bans = [entry async for entry in ctx.guild.bans()]
        if not bans:
            return await ctx.send(embed=info_embed("Ban List", "No banned users."))
        desc = "\n".join(f"`{b.user.id}` - **{b.user}**" for b in bans[:25])
        e = discord.Embed(title=f"🔨 Ban List ({len(bans)} total)", description=desc, color=0xe74c3c)
        await ctx.send(embed=e)

    # ────────────────────── KICK ─────────────────────────────
    @commands.command(name="kick", help="Kick a member")
    @commands.has_permissions(kick_members=True)
    @commands.bot_has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason="No reason"):
        if member.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("Hierarchy", "Can't kick equal/higher role."))
        await member.kick(reason=f"{ctx.author} | {reason}")
        await ctx.send(embed=success_embed("Kicked", f"{member.mention} was kicked.\nReason: {reason}"))
        log_e = discord.Embed(title="👢 Member Kicked", color=0xe67e22, timestamp=datetime.datetime.utcnow())
        log_e.add_field(name="Member", value=str(member))
        log_e.add_field(name="Moderator", value=str(ctx.author))
        log_e.add_field(name="Reason", value=reason)
        await send_log(ctx.guild, log_e)

    # ────────────────────── MUTE / TIMEOUT ───────────────────
    @commands.command(name="mute", help="Mute (timeout) a member. !mute @user 10m reason")
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    async def mute(self, ctx, member: discord.Member, duration: str = "10m", *, reason="No reason"):
        secs = parse_time(duration)
        if secs == 0: secs = 600
        until = datetime.datetime.utcnow() + datetime.timedelta(seconds=secs)
        await member.timeout(datetime.timedelta(seconds=secs), reason=f"{ctx.author} | {reason}")
        await ctx.send(embed=success_embed("Muted", f"{member.mention} muted for `{format_seconds(secs)}`.\nReason: {reason}"))
        with db() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO mutes VALUES (?,?,?)",
                (str(ctx.guild.id), str(member.id), until.isoformat())
            )
            conn.commit()

    @commands.command(name="unmute", help="Unmute a member")
    @commands.has_permissions(moderate_members=True)
    async def unmute(self, ctx, member: discord.Member, *, reason="Unmuted by moderator"):
        await member.timeout(None, reason=f"{ctx.author} | {reason}")
        await ctx.send(embed=success_embed("Unmuted", f"{member.mention} has been unmuted."))
        with db() as conn:
            conn.execute("DELETE FROM mutes WHERE guild_id=? AND user_id=?",
                         (str(ctx.guild.id), str(member.id)))
            conn.commit()

    # ────────────────────── WARN ─────────────────────────────
    @commands.command(name="warn", help="Warn a member")
    @commands.has_permissions(manage_messages=True)
    async def warn(self, ctx, member: discord.Member, *, reason="No reason"):
        with db() as conn:
            conn.execute(
                "INSERT INTO warns (guild_id, user_id, mod_id, reason, timestamp) VALUES (?,?,?,?,?)",
                (str(ctx.guild.id), str(member.id), str(ctx.author.id), reason, datetime.datetime.utcnow().isoformat())
            )
            conn.commit()
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM warns WHERE guild_id=? AND user_id=?",
                      (str(ctx.guild.id), str(member.id)))
            count = c.fetchone()[0]
        await ctx.send(embed=warn_embed("Warned", f"{member.mention} warned. Total warns: **{count}**\nReason: {reason}"))
        try:
            await member.send(embed=warn_embed(f"Warning in {ctx.guild.name}", f"You were warned by {ctx.author}.\nReason: {reason}"))
        except:
            pass

    @commands.command(name="warnings", aliases=["warns"], help="View warnings of a member")
    @commands.has_permissions(manage_messages=True)
    async def warnings(self, ctx, member: discord.Member):
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT id, mod_id, reason, timestamp FROM warns WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 10",
                      (str(ctx.guild.id), str(member.id)))
            rows = c.fetchall()
        if not rows:
            return await ctx.send(embed=info_embed("No Warnings", f"{member.mention} has no warnings."))
        e = discord.Embed(title=f"⚠️ Warnings for {member}", color=0xf39c12)
        for wid, mod_id, reason, ts in rows:
            mod = ctx.guild.get_member(int(mod_id)) or f"ID:{mod_id}"
            e.add_field(name=f"#{wid} | {ts[:10]}", value=f"**Mod:** {mod}\n**Reason:** {reason}", inline=False)
        await ctx.send(embed=e)

    @commands.command(name="delwarn", help="Delete a specific warning by ID")
    @commands.has_permissions(manage_messages=True)
    async def delwarn(self, ctx, warn_id: int):
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT id FROM warns WHERE id=? AND guild_id=?", (warn_id, str(ctx.guild.id)))
            row = c.fetchone()
            if not row:
                return await ctx.send(embed=error_embed("Not Found", f"Warning #{warn_id} not found."))
            conn.execute("DELETE FROM warns WHERE id=?", (warn_id,))
            conn.commit()
        await ctx.send(embed=success_embed("Warning Deleted", f"Warning #{warn_id} deleted."))

    @commands.command(name="clearwarns", help="Clear all warnings for a member")
    @commands.has_permissions(administrator=True)
    async def clearwarns(self, ctx, member: discord.Member):
        with db() as conn:
            conn.execute("DELETE FROM warns WHERE guild_id=? AND user_id=?",
                         (str(ctx.guild.id), str(member.id)))
            conn.commit()
        await ctx.send(embed=success_embed("Warnings Cleared", f"All warnings for {member.mention} cleared."))

    # ────────────────────── PURGE / CLEAR ───────────────────
    @commands.command(name="purge", aliases=["clear", "clean"], help="Delete messages. !purge 50")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int = 10):
        if amount > 1000:
            return await ctx.send(embed=error_embed("Too Many", "Max 1000 messages at once."))
        deleted = await ctx.channel.purge(limit=amount + 1)
        await ctx.send(embed=success_embed("Purged", f"Deleted `{len(deleted)-1}` messages."), delete_after=5)

    @commands.command(name="purgeuser", help="Delete messages from specific user")
    @commands.has_permissions(manage_messages=True)
    async def purgeuser(self, ctx, member: discord.Member, amount: int = 50):
        def check(m): return m.author == member
        deleted = await ctx.channel.purge(limit=200, check=check)
        await ctx.send(embed=success_embed("Purged", f"Deleted `{len(deleted)}` messages from {member.mention}."), delete_after=5)

    @commands.command(name="purgebots", help="Delete bot messages")
    @commands.has_permissions(manage_messages=True)
    async def purgebots(self, ctx, amount: int = 50):
        def check(m): return m.author.bot
        deleted = await ctx.channel.purge(limit=amount, check=check)
        await ctx.send(embed=success_embed("Purged Bots", f"Deleted `{len(deleted)}` bot messages."), delete_after=5)

    @commands.command(name="purgeembeds", help="Delete messages with embeds")
    @commands.has_permissions(manage_messages=True)
    async def purgeembeds(self, ctx, amount: int = 50):
        def check(m): return len(m.embeds) > 0
        deleted = await ctx.channel.purge(limit=amount, check=check)
        await ctx.send(embed=success_embed("Purged Embeds", f"Deleted `{len(deleted)}` embed messages."), delete_after=5)

    @commands.command(name="purgeimages", help="Delete messages with images/attachments")
    @commands.has_permissions(manage_messages=True)
    async def purgeimages(self, ctx, amount: int = 50):
        def check(m): return len(m.attachments) > 0
        deleted = await ctx.channel.purge(limit=amount, check=check)
        await ctx.send(embed=success_embed("Purged Images", f"Deleted `{len(deleted)}` image messages."), delete_after=5)

    @commands.command(name="purgelinks", help="Delete messages containing links")
    @commands.has_permissions(manage_messages=True)
    async def purgelinks(self, ctx, amount: int = 50):
        def check(m): return bool(re.search(r'https?://', m.content))
        deleted = await ctx.channel.purge(limit=amount, check=check)
        await ctx.send(embed=success_embed("Purged Links", f"Deleted `{len(deleted)}` link messages."), delete_after=5)

    @commands.command(name="purgecontains", help="Delete messages containing text")
    @commands.has_permissions(manage_messages=True)
    async def purgecontains(self, ctx, *, text: str):
        def check(m): return text.lower() in m.content.lower()
        deleted = await ctx.channel.purge(limit=100, check=check)
        await ctx.send(embed=success_embed("Purged", f"Deleted `{len(deleted)}` messages containing `{text}`."), delete_after=5)

    # ────────────────────── SLOWMODE ─────────────────────────
    @commands.command(name="slowmode", help="Set slowmode. !slowmode 5s / !slowmode off")
    @commands.has_permissions(manage_channels=True)
    async def slowmode(self, ctx, delay: str = "off"):
        if delay.lower() in ("off", "0", "disable"):
            await ctx.channel.edit(slowmode_delay=0)
            await ctx.send(embed=success_embed("Slowmode Off", "Slowmode disabled."))
        else:
            secs = parse_time(delay)
            if secs > 21600: secs = 21600
            await ctx.channel.edit(slowmode_delay=secs)
            await ctx.send(embed=success_embed("Slowmode Set", f"Slowmode set to `{format_seconds(secs)}`."))

    # ────────────────────── LOCK / UNLOCK ────────────────────
    @commands.command(name="lock", help="Lock a channel (no send messages)")
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx, channel: Optional[discord.TextChannel] = None):
        ch = channel or ctx.channel
        overwrite = ch.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await ch.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ch.send(embed=error_embed("🔒 Channel Locked", f"This channel was locked by {ctx.author.mention}."))

    @commands.command(name="unlock", help="Unlock a channel")
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx, channel: Optional[discord.TextChannel] = None):
        ch = channel or ctx.channel
        overwrite = ch.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = None
        await ch.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        await ch.send(embed=success_embed("🔓 Channel Unlocked", f"Unlocked by {ctx.author.mention}."))

    @commands.command(name="lockdown", help="Lock ALL channels in the server")
    @commands.has_permissions(administrator=True)
    async def lockdown(self, ctx, *, reason="Security lockdown"):
        count = 0
        for ch in ctx.guild.text_channels:
            try:
                ow = ch.overwrites_for(ctx.guild.default_role)
                ow.send_messages = False
                await ch.set_permissions(ctx.guild.default_role, overwrite=ow)
                count += 1
            except:
                pass
        await ctx.send(embed=error_embed("🔒 Server Lockdown", f"Locked `{count}` channels.\nReason: {reason}"))

    @commands.command(name="unlockdown", help="Unlock ALL channels")
    @commands.has_permissions(administrator=True)
    async def unlockdown(self, ctx):
        count = 0
        for ch in ctx.guild.text_channels:
            try:
                ow = ch.overwrites_for(ctx.guild.default_role)
                ow.send_messages = None
                await ch.set_permissions(ctx.guild.default_role, overwrite=ow)
                count += 1
            except:
                pass
        await ctx.send(embed=success_embed("🔓 Lockdown Lifted", f"Unlocked `{count}` channels."))

    # ────────────────────── ROLE MANAGEMENT ──────────────────
    @commands.command(name="role", help="Add/remove role from member. !role @user @role")
    @commands.has_permissions(manage_roles=True)
    async def role(self, ctx, member: discord.Member, role: discord.Role):
        if role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("Hierarchy", "Can't assign that role."))
        if role in member.roles:
            await member.remove_roles(role)
            await ctx.send(embed=success_embed("Role Removed", f"Removed {role.mention} from {member.mention}."))
        else:
            await member.add_roles(role)
            await ctx.send(embed=success_embed("Role Added", f"Added {role.mention} to {member.mention}."))

    @commands.command(name="addrole", help="Add a role to a member")
    @commands.has_permissions(manage_roles=True)
    async def addrole(self, ctx, member: discord.Member, role: discord.Role):
        if role in member.roles:
            return await ctx.send(embed=error_embed("Already Has Role", f"{member.mention} already has {role.mention}."))
        await member.add_roles(role)
        await ctx.send(embed=success_embed("Role Added", f"{role.mention} given to {member.mention}."))

    @commands.command(name="removerole", help="Remove a role from a member")
    @commands.has_permissions(manage_roles=True)
    async def removerole(self, ctx, member: discord.Member, role: discord.Role):
        if role not in member.roles:
            return await ctx.send(embed=error_embed("Missing Role", f"{member.mention} doesn't have {role.mention}."))
        await member.remove_roles(role)
        await ctx.send(embed=success_embed("Role Removed", f"{role.mention} removed from {member.mention}."))

    @commands.command(name="massrole", help="Add role to ALL members")
    @commands.has_permissions(administrator=True)
    async def massrole(self, ctx, role: discord.Role):
        msg = await ctx.send(embed=info_embed("Mass Role", f"Adding {role.mention} to all members..."))
        count = 0
        for member in ctx.guild.members:
            if role not in member.roles:
                try:
                    await member.add_roles(role)
                    count += 1
                    await asyncio.sleep(0.5)
                except:
                    pass
        await msg.edit(embed=success_embed("Mass Role Done", f"Added {role.mention} to `{count}` members."))

    @commands.command(name="massremoverole", help="Remove role from ALL members")
    @commands.has_permissions(administrator=True)
    async def massremoverole(self, ctx, role: discord.Role):
        msg = await ctx.send(embed=info_embed("Mass Remove Role", f"Removing {role.mention} from all members..."))
        count = 0
        for member in ctx.guild.members:
            if role in member.roles:
                try:
                    await member.remove_roles(role)
                    count += 1
                    await asyncio.sleep(0.5)
                except:
                    pass
        await msg.edit(embed=success_embed("Done", f"Removed {role.mention} from `{count}` members."))

    @commands.command(name="createrole", help="Create a new role")
    @commands.has_permissions(manage_roles=True)
    async def createrole(self, ctx, *, name: str):
        role = await ctx.guild.create_role(name=name)
        await ctx.send(embed=success_embed("Role Created", f"Created {role.mention}."))

    @commands.command(name="delrole", help="Delete a role")
    @commands.has_permissions(manage_roles=True)
    async def delrole(self, ctx, role: discord.Role):
        name = role.name
        await role.delete()
        await ctx.send(embed=success_embed("Role Deleted", f"Role `{name}` deleted."))

    @commands.command(name="rolecolor", help="Change role color. !rolecolor @role #ff0000")
    @commands.has_permissions(manage_roles=True)
    async def rolecolor(self, ctx, role: discord.Role, color: str):
        try:
            c = discord.Color(int(color.strip("#"), 16))
            await role.edit(color=c)
            await ctx.send(embed=success_embed("Color Changed", f"{role.mention} color changed to `{color}`."))
        except:
            await ctx.send(embed=error_embed("Invalid Color", "Use hex like `#ff0000`."))

    @commands.command(name="rolename", help="Rename a role")
    @commands.has_permissions(manage_roles=True)
    async def rolename(self, ctx, role: discord.Role, *, new_name: str):
        old = role.name
        await role.edit(name=new_name)
        await ctx.send(embed=success_embed("Role Renamed", f"`{old}` → `{new_name}`."))

    @commands.command(name="rolehoist", help="Toggle role hoist (show separately)")
    @commands.has_permissions(manage_roles=True)
    async def rolehoist(self, ctx, role: discord.Role):
        await role.edit(hoist=not role.hoist)
        status = "hoisted" if role.hoist else "un-hoisted"
        await ctx.send(embed=success_embed("Hoist Toggled", f"{role.mention} is now {status}."))

    @commands.command(name="rolementionable", help="Toggle role mentionable")
    @commands.has_permissions(manage_roles=True)
    async def rolementionable(self, ctx, role: discord.Role):
        await role.edit(mentionable=not role.mentionable)
        status = "mentionable" if role.mentionable else "not mentionable"
        await ctx.send(embed=success_embed("Toggled", f"{role.mention} is now {status}."))

    @commands.command(name="roleinfo", help="Get info about a role")
    async def roleinfo(self, ctx, role: discord.Role):
        e = discord.Embed(title=f"Role: {role.name}", color=role.color)
        e.add_field(name="ID", value=role.id)
        e.add_field(name="Color", value=str(role.color))
        e.add_field(name="Members", value=len(role.members))
        e.add_field(name="Hoisted", value=role.hoist)
        e.add_field(name="Mentionable", value=role.mentionable)
        e.add_field(name="Position", value=role.position)
        e.add_field(name="Created", value=role.created_at.strftime("%Y-%m-%d"))
        e.add_field(name="Managed", value=role.managed)
        await ctx.send(embed=e)

    @commands.command(name="inrole", help="List members with a specific role")
    @commands.has_permissions(manage_roles=True)
    async def inrole(self, ctx, role: discord.Role):
        members = role.members
        if not members:
            return await ctx.send(embed=info_embed("No Members", f"No members have {role.mention}."))
        desc = "\n".join(f"• {m.mention} (`{m.id}`)" for m in members[:25])
        if len(members) > 25: desc += f"\n... and {len(members)-25} more"
        e = discord.Embed(title=f"Members with {role.name} ({len(members)})", description=desc, color=role.color)
        await ctx.send(embed=e)

    # ────────────────────── NICK ─────────────────────────────
    @commands.command(name="nick", help="Change member nickname")
    @commands.has_permissions(manage_nicknames=True)
    async def nick(self, ctx, member: discord.Member, *, nickname: str = None):
        old = member.display_name
        await member.edit(nick=nickname)
        new = nickname or member.name
        await ctx.send(embed=success_embed("Nickname Changed", f"`{old}` → `{new}`."))

    @commands.command(name="resetnick", help="Reset member nickname")
    @commands.has_permissions(manage_nicknames=True)
    async def resetnick(self, ctx, member: discord.Member):
        await member.edit(nick=None)
        await ctx.send(embed=success_embed("Nickname Reset", f"{member.mention}'s nickname reset."))

    @commands.command(name="massnick", help="Set nickname for all members")
    @commands.has_permissions(administrator=True)
    async def massnick(self, ctx, *, nickname: str):
        msg = await ctx.send(embed=info_embed("Mass Nickname", f"Setting nickname to `{nickname}`..."))
        count = 0
        for member in ctx.guild.members:
            try:
                await member.edit(nick=nickname)
                count += 1
                await asyncio.sleep(0.5)
            except:
                pass
        await msg.edit(embed=success_embed("Done", f"Changed nickname for `{count}` members."))

    # ────────────────────── NOTES ────────────────────────────
    @commands.command(name="note", help="Add a mod note for a user")
    @commands.has_permissions(manage_messages=True)
    async def note(self, ctx, member: discord.Member, *, note: str):
        with db() as conn:
            conn.execute(
                "INSERT INTO notes (guild_id, user_id, mod_id, note, timestamp) VALUES (?,?,?,?,?)",
                (str(ctx.guild.id), str(member.id), str(ctx.author.id), note, datetime.datetime.utcnow().isoformat())
            )
            conn.commit()
        await ctx.send(embed=success_embed("Note Added", f"Note saved for {member.mention}."))

    @commands.command(name="notes", help="View notes for a user")
    @commands.has_permissions(manage_messages=True)
    async def notes(self, ctx, member: discord.Member):
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT id, mod_id, note, timestamp FROM notes WHERE guild_id=? AND user_id=?",
                      (str(ctx.guild.id), str(member.id)))
            rows = c.fetchall()
        if not rows:
            return await ctx.send(embed=info_embed("No Notes", f"No notes for {member.mention}."))
        e = discord.Embed(title=f"📝 Notes for {member}", color=0x9b59b6)
        for nid, mid, note, ts in rows[:10]:
            mod = ctx.guild.get_member(int(mid)) or f"ID:{mid}"
            e.add_field(name=f"#{nid} | {ts[:10]}", value=f"**Mod:** {mod}\n{note}", inline=False)
        await ctx.send(embed=e)

    @commands.command(name="delnote", help="Delete a note by ID")
    @commands.has_permissions(manage_messages=True)
    async def delnote(self, ctx, note_id: int):
        with db() as conn:
            conn.execute("DELETE FROM notes WHERE id=? AND guild_id=?", (note_id, str(ctx.guild.id)))
            conn.commit()
        await ctx.send(embed=success_embed("Note Deleted", f"Note #{note_id} deleted."))

    # ────────────────────── BLACKLIST ────────────────────────
    @commands.command(name="blacklist", help="Blacklist a user from bot")
    @commands.has_permissions(administrator=True)
    async def blacklist_cmd(self, ctx, member: discord.Member, *, reason="No reason"):
        with db() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO blacklist VALUES (?,?,?)",
                (str(ctx.guild.id), str(member.id), reason)
            )
            conn.commit()
        await ctx.send(embed=success_embed("Blacklisted", f"{member.mention} blacklisted.\nReason: {reason}"))

    @commands.command(name="unblacklist", help="Remove user from blacklist")
    @commands.has_permissions(administrator=True)
    async def unblacklist(self, ctx, member: discord.Member):
        with db() as conn:
            conn.execute("DELETE FROM blacklist WHERE guild_id=? AND user_id=?",
                         (str(ctx.guild.id), str(member.id)))
            conn.commit()
        await ctx.send(embed=success_embed("Unblacklisted", f"{member.mention} removed from blacklist."))

    # ────────────────────── CHANNEL MANAGEMENT ───────────────
    @commands.command(name="nuke", help="Delete and recreate channel (purge all messages)")
    @commands.has_permissions(administrator=True)
    async def nuke(self, ctx):
        ch = ctx.channel
        new_ch = await ch.clone(reason=f"Nuked by {ctx.author}")
        await ch.delete()
        await new_ch.send(embed=success_embed("💥 Channel Nuked", f"Channel nuked by {ctx.author.mention}."))

    @commands.command(name="createchannel", aliases=["makechannel"], help="Create a text channel")
    @commands.has_permissions(manage_channels=True)
    async def createchannel(self, ctx, *, name: str):
        ch = await ctx.guild.create_text_channel(name=name)
        await ctx.send(embed=success_embed("Channel Created", f"{ch.mention} created."))

    @commands.command(name="deletechannel", help="Delete a channel")
    @commands.has_permissions(manage_channels=True)
    async def deletechannel(self, ctx, channel: discord.TextChannel = None):
        ch = channel or ctx.channel
        name = ch.name
        await ch.delete()
        if ch != ctx.channel:
            await ctx.send(embed=success_embed("Channel Deleted", f"`{name}` deleted."))

    @commands.command(name="renamechannel", help="Rename a channel")
    @commands.has_permissions(manage_channels=True)
    async def renamechannel(self, ctx, channel: discord.TextChannel, *, name: str):
        old = channel.name
        await channel.edit(name=name)
        await ctx.send(embed=success_embed("Channel Renamed", f"`{old}` → `{name}`."))

    @commands.command(name="channeltopic", help="Set channel topic")
    @commands.has_permissions(manage_channels=True)
    async def channeltopic(self, ctx, channel: Optional[discord.TextChannel], *, topic: str):
        ch = channel or ctx.channel
        await ch.edit(topic=topic)
        await ctx.send(embed=success_embed("Topic Set", f"Topic updated for {ch.mention}."))

    @commands.command(name="hide", help="Hide channel from everyone")
    @commands.has_permissions(manage_channels=True)
    async def hide(self, ctx, channel: Optional[discord.TextChannel]):
        ch = channel or ctx.channel
        await ch.set_permissions(ctx.guild.default_role, view_channel=False)
        await ctx.send(embed=success_embed("Hidden", f"{ch.mention} hidden from everyone."))

    @commands.command(name="unhide", help="Unhide channel")
    @commands.has_permissions(manage_channels=True)
    async def unhide(self, ctx, channel: Optional[discord.TextChannel]):
        ch = channel or ctx.channel
        await ch.set_permissions(ctx.guild.default_role, view_channel=None)
        await ctx.send(embed=success_embed("Unhidden", f"{ch.mention} is now visible."))

    @commands.command(name="createcategory", help="Create a category")
    @commands.has_permissions(manage_channels=True)
    async def createcategory(self, ctx, *, name: str):
        cat = await ctx.guild.create_category(name=name)
        await ctx.send(embed=success_embed("Category Created", f"Category `{cat.name}` created."))

    @commands.command(name="createvc", help="Create a voice channel")
    @commands.has_permissions(manage_channels=True)
    async def createvc(self, ctx, *, name: str):
        vc = await ctx.guild.create_voice_channel(name=name)
        await ctx.send(embed=success_embed("VC Created", f"Voice channel `{vc.name}` created."))

    @commands.command(name="setuserslimit", help="Set user limit for voice channel")
    @commands.has_permissions(manage_channels=True)
    async def setuserslimit(self, ctx, vc: discord.VoiceChannel, limit: int):
        await vc.edit(user_limit=limit)
        await ctx.send(embed=success_embed("Limit Set", f"`{vc.name}` limit set to `{limit}`."))

    # ────────────────────── MOVE / DISCONNECT ─────────────────
    @commands.command(name="vcmove", help="Move member to voice channel")
    @commands.has_permissions(move_members=True)
    async def vcmove(self, ctx, member: discord.Member, vc: discord.VoiceChannel):
        if not member.voice:
            return await ctx.send(embed=error_embed("Not In VC", f"{member.mention} is not in a VC."))
        await member.move_to(vc)
        await ctx.send(embed=success_embed("Moved", f"{member.mention} moved to `{vc.name}`."))

    @commands.command(name="vckick", help="Disconnect member from VC")
    @commands.has_permissions(move_members=True)
    async def vckick(self, ctx, member: discord.Member):
        if not member.voice:
            return await ctx.send(embed=error_embed("Not In VC", f"{member.mention} is not in a VC."))
        await member.move_to(None)
        await ctx.send(embed=success_embed("Disconnected", f"{member.mention} disconnected from VC."))

    @commands.command(name="vcmoveall", help="Move all members to a VC")
    @commands.has_permissions(move_members=True)
    async def vcmoveall(self, ctx, from_vc: discord.VoiceChannel, to_vc: discord.VoiceChannel):
        count = 0
        for member in from_vc.members:
            try:
                await member.move_to(to_vc)
                count += 1
            except:
                pass
        await ctx.send(embed=success_embed("Moved", f"Moved `{count}` members to `{to_vc.name}`."))

    # ────────────────────── MOD HISTORY ──────────────────────
    @commands.command(name="modhistory", aliases=["mh"], help="View full mod history of a user")
    @commands.has_permissions(manage_messages=True)
    async def modhistory(self, ctx, member: discord.Member):
        gid = str(ctx.guild.id)
        uid = str(member.id)
        with db() as conn:
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM warns WHERE guild_id=? AND user_id=?", (gid, uid))
            warn_count = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM notes WHERE guild_id=? AND user_id=?", (gid, uid))
            note_count = c.fetchone()[0]

        e = discord.Embed(title=f"📋 Mod History: {member}", color=0x9b59b6)
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="⚠️ Warnings", value=warn_count)
        e.add_field(name="📝 Notes", value=note_count)
        e.add_field(name="Account Created", value=member.created_at.strftime("%Y-%m-%d"))
        e.add_field(name="Joined Server", value=member.joined_at.strftime("%Y-%m-%d") if member.joined_at else "Unknown")
        await ctx.send(embed=e)

    # ────────────────────── SERVER MODERATION ────────────────
    @commands.command(name="setverification", help="Set verification level (0-4)")
    @commands.has_permissions(administrator=True)
    async def setverification(self, ctx, level: int):
        levels = {
            0: discord.VerificationLevel.none,
            1: discord.VerificationLevel.low,
            2: discord.VerificationLevel.medium,
            3: discord.VerificationLevel.high,
            4: discord.VerificationLevel.highest
        }
        if level not in levels:
            return await ctx.send(embed=error_embed("Invalid", "Level must be 0-4."))
        await ctx.guild.edit(verification_level=levels[level])
        await ctx.send(embed=success_embed("Verification Set", f"Set to level `{level}`."))

    @commands.command(name="setcontentfilter", help="Set content filter (0=none, 1=no role, 2=all)")
    @commands.has_permissions(administrator=True)
    async def setcontentfilter(self, ctx, level: int):
        filters = {
            0: discord.ContentFilter.disabled,
            1: discord.ContentFilter.no_role,
            2: discord.ContentFilter.all_members
        }
        if level not in filters:
            return await ctx.send(embed=error_embed("Invalid", "Level must be 0-2."))
        await ctx.guild.edit(explicit_content_filter=filters[level])
        await ctx.send(embed=success_embed("Filter Set", f"Content filter set to level `{level}`."))

    @commands.command(name="servername", help="Change server name")
    @commands.has_permissions(manage_guild=True)
    async def servername(self, ctx, *, name: str):
        old = ctx.guild.name
        await ctx.guild.edit(name=name)
        await ctx.send(embed=success_embed("Server Renamed", f"`{old}` → `{name}`."))

    @commands.command(name="hackban", help="Ban user by ID (even not in server)")
    @commands.has_permissions(ban_members=True)
    async def hackban(self, ctx, user_id: int, *, reason="No reason"):
        try:
            await ctx.guild.ban(discord.Object(id=user_id), reason=f"{ctx.author} | {reason}")
            await ctx.send(embed=success_embed("Hackban", f"User `{user_id}` banned."))
        except Exception as e:
            await ctx.send(embed=error_embed("Failed", str(e)))

    @commands.command(name="deafen", help="Server deafen a member in VC")
    @commands.has_permissions(deafen_members=True)
    async def deafen(self, ctx, member: discord.Member):
        await member.edit(deafen=True)
        await ctx.send(embed=success_embed("Deafened", f"{member.mention} server deafened."))

    @commands.command(name="undeafen", help="Undeafen a member")
    @commands.has_permissions(deafen_members=True)
    async def undeafen(self, ctx, member: discord.Member):
        await member.edit(deafen=False)
        await ctx.send(embed=success_embed("Undeafened", f"{member.mention} undeafened."))

    @commands.command(name="vmute", help="Server voice-mute a member")
    @commands.has_permissions(mute_members=True)
    async def vmute(self, ctx, member: discord.Member):
        await member.edit(mute=True)
        await ctx.send(embed=success_embed("Voice Muted", f"{member.mention} voice muted."))

    @commands.command(name="vunmute", help="Unvoice-mute a member")
    @commands.has_permissions(mute_members=True)
    async def vunmute(self, ctx, member: discord.Member):
        await member.edit(mute=False)
        await ctx.send(embed=success_embed("Voice Unmuted", f"{member.mention} voice unmuted."))

async def setup(bot):
    await bot.add_cog(Moderation(bot))
