"""GIVEAWAY COG"""
import discord, asyncio, datetime, json, random, sqlite3, re
from discord.ext import commands
from typing import Optional

def db(): return sqlite3.connect("ultrabot.db")
def s(t,d=None): return discord.Embed(title=f"✅ {t}",description=d,color=0x2ecc71)
def e(t,d=None): return discord.Embed(title=f"❌ {t}",description=d,color=0xe74c3c)

def parse_time(s):
    total=0
    for v,u in re.findall(r'(\d+)([dhms])',s.lower()):
        v=int(v)
        if u=='d': total+=v*86400
        elif u=='h': total+=v*3600
        elif u=='m': total+=v*60
        elif u=='s': total+=v
    return total

def format_seconds(sec):
    d,r=divmod(sec,86400); h,r=divmod(r,3600); m,s=divmod(r,60)
    parts=[]
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    if s: parts.append(f"{s}s")
    return " ".join(parts) or "0s"

class Giveaway(commands.Cog):
    """🎉 Giveaways"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="gstart",aliases=["gcreate"],help="Start a giveaway. !gstart 1h 1 Nitro")
    @commands.has_permissions(manage_guild=True)
    async def gstart(self,ctx,duration:str,winners:int,*,prize:str):
        secs=parse_time(duration)
        if not secs: return await ctx.send(embed=e("Invalid Time"))
        ends=datetime.datetime.utcnow()+datetime.timedelta(seconds=secs)
        em=discord.Embed(
            title=f"🎉 GIVEAWAY: {prize}",
            description=f"React with 🎉 to enter!\n\n**Winners:** {winners}\n**Ends:** <t:{int(ends.timestamp())}:R>\n**Host:** {ctx.author.mention}",
            color=0xf1c40f,
            timestamp=ends
        )
        em.set_footer(text=f"Ends at")
        msg=await ctx.send(embed=em)
        await msg.add_reaction("🎉")
        with db() as conn:
            conn.execute(
                "INSERT INTO giveaways (guild_id,channel_id,message_id,host_id,prize,winners,ends_at) VALUES (?,?,?,?,?,?,?)",
                (str(ctx.guild.id),str(ctx.channel.id),str(msg.id),str(ctx.author.id),prize,winners,ends.isoformat())
            )
            conn.commit()

    @commands.command(name="gend",help="End a giveaway early by message ID")
    @commands.has_permissions(manage_guild=True)
    async def gend(self,ctx,message_id:int):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT * FROM giveaways WHERE message_id=? AND guild_id=? AND ended=0",
                      (str(message_id),str(ctx.guild.id)))
            row=c.fetchone()
        if not row: return await ctx.send(embed=e("Not Found","Giveaway not found or already ended."))
        gid,guild_id,ch_id,msg_id,host_id,prize,winners,ends_at,ended,entries_json=row
        entries=json.loads(entries_json)
        ch=ctx.guild.get_channel(int(ch_id))
        if entries:
            won=random.sample(entries,min(winners,len(entries)))
            mentions=" ".join(f"<@{w}>" for w in won)
            em=discord.Embed(title="🎉 Giveaway Ended!",color=0xf1c40f)
            em.add_field(name="Prize",value=prize)
            em.add_field(name="Winners",value=mentions)
            em.add_field(name="Host",value=f"<@{host_id}>")
            await ch.send(embed=em)
        else:
            await ch.send(embed=e("No Winners","No valid entries."))
        with db() as conn:
            conn.execute("UPDATE giveaways SET ended=1 WHERE id=?",(gid,))
            conn.commit()

    @commands.command(name="greroll",help="Reroll giveaway winners")
    @commands.has_permissions(manage_guild=True)
    async def greroll(self,ctx,message_id:int,count:int=1):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT entries,prize FROM giveaways WHERE message_id=? AND guild_id=?",
                      (str(message_id),str(ctx.guild.id)))
            row=c.fetchone()
        if not row: return await ctx.send(embed=e("Not Found"))
        entries=json.loads(row[0])
        if not entries: return await ctx.send(embed=e("No Entries"))
        won=random.sample(entries,min(count,len(entries)))
        mentions=" ".join(f"<@{w}>" for w in won)
        await ctx.send(embed=s("🎉 Rerolled!",f"New winner(s): {mentions}"))

    @commands.command(name="glist",help="List active giveaways")
    async def glist(self,ctx):
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT message_id,prize,winners,ends_at FROM giveaways WHERE guild_id=? AND ended=0",(str(ctx.guild.id),))
            rows=c.fetchall()
        if not rows: return await ctx.send(embed=discord.Embed(title="No Active Giveaways",color=0x3498db))
        desc="\n".join(f"• [{prize}](https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{mid}) — {w} winner(s)" for mid,prize,w,_ in rows)
        await ctx.send(embed=discord.Embed(title="🎉 Active Giveaways",description=desc,color=0xf1c40f))

    @commands.command(name="gdelete",help="Delete a giveaway")
    @commands.has_permissions(manage_guild=True)
    async def gdelete(self,ctx,message_id:int):
        with db() as conn:
            conn.execute("DELETE FROM giveaways WHERE message_id=? AND guild_id=?",(str(message_id),str(ctx.guild.id)))
            conn.commit()
        await ctx.send(embed=s("Giveaway Deleted"))

    @commands.event
    async def on_raw_reaction_add_giveaway(self,payload):
        if str(payload.emoji)!="🎉" or not payload.guild_id: return
        with db() as conn:
            c=conn.cursor()
            c.execute("SELECT id,entries FROM giveaways WHERE message_id=? AND ended=0",(str(payload.message_id),))
            row=c.fetchone()
            if not row: return
            entries=json.loads(row[1])
            uid=str(payload.user_id)
            if uid not in entries:
                entries.append(uid)
                conn.execute("UPDATE giveaways SET entries=? WHERE id=?",(json.dumps(entries),row[0]))
                conn.commit()

async def setup(bot):
    await bot.add_cog(Giveaway(bot))
