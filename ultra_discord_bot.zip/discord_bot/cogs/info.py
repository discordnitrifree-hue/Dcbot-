"""INFO COG"""
import discord, datetime, sqlite3
from discord.ext import commands
from typing import Optional

class Info(commands.Cog):
    """📋 Info Commands"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="userinfo",aliases=["ui","user"],help="Detailed user information")
    async def userinfo(self,ctx,member:Optional[discord.Member]):
        m=member or ctx.author
        roles=[r.mention for r in m.roles[1:]][:10]
        badges=[]
        if m.bot: badges.append("🤖 Bot")
        if m.public_flags.staff: badges.append("👨‍💼 Staff")
        if m.public_flags.partner: badges.append("🤝 Partner")
        if m.public_flags.hypesquad: badges.append("🏠 HypeSquad")
        if m.public_flags.bug_hunter: badges.append("🐛 Bug Hunter")
        if m.public_flags.early_supporter: badges.append("💎 Early Supporter")
        e=discord.Embed(title=f"👤 {m}",color=m.color,timestamp=datetime.datetime.utcnow())
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="ID",value=m.id)
        e.add_field(name="Nickname",value=m.nick or "None")
        e.add_field(name="Status",value=str(m.status).replace("dnd","🔴 DND").replace("online","🟢 Online").replace("idle","🟡 Idle").replace("offline","⚫ Offline").title())
        e.add_field(name="Top Role",value=m.top_role.mention)
        e.add_field(name="Joined Server",value=m.joined_at.strftime("%Y-%m-%d %H:%M") if m.joined_at else "?")
        e.add_field(name="Account Created",value=m.created_at.strftime("%Y-%m-%d %H:%M"))
        if badges: e.add_field(name="Badges",value=" ".join(badges),inline=False)
        if roles: e.add_field(name=f"Roles [{len(m.roles)-1}]",value=" ".join(roles),inline=False)
        e.set_footer(text=f"Requested by {ctx.author}")
        await ctx.send(embed=e)

    @commands.command(name="guildinfo",aliases=["gi","serverinfo2"],help="Guild/Server information")
    async def guildinfo(self,ctx):
        g=ctx.guild
        bots=sum(1 for m in g.members if m.bot)
        humans=g.member_count-bots
        e=discord.Embed(title=g.name,color=0x3498db,timestamp=datetime.datetime.utcnow())
        if g.icon: e.set_thumbnail(url=g.icon.url)
        if g.banner: e.set_image(url=g.banner.url)
        e.add_field(name="ID",value=g.id)
        e.add_field(name="Owner",value=g.owner.mention if g.owner else "?")
        e.add_field(name="Members",value=f"{g.member_count:,}")
        e.add_field(name="Humans",value=f"{humans:,}")
        e.add_field(name="Bots",value=f"{bots:,}")
        e.add_field(name="Text Channels",value=len(g.text_channels))
        e.add_field(name="Voice Channels",value=len(g.voice_channels))
        e.add_field(name="Categories",value=len(g.categories))
        e.add_field(name="Roles",value=len(g.roles))
        e.add_field(name="Emojis",value=f"{len(g.emojis)}/{g.emoji_limit}")
        e.add_field(name="Stickers",value=len(g.stickers))
        e.add_field(name="Boost Level",value=f"Level {g.premium_tier}")
        e.add_field(name="Boosts",value=g.premium_subscription_count)
        e.add_field(name="Verification",value=str(g.verification_level).title())
        e.add_field(name="2FA Required",value="Yes" if g.mfa_level else "No")
        e.add_field(name="Created",value=g.created_at.strftime("%Y-%m-%d"))
        await ctx.send(embed=e)

    @commands.command(name="roles",help="List all server roles")
    async def roles(self,ctx):
        roles=list(reversed(ctx.guild.roles))
        desc=" ".join(r.mention for r in roles[1:30])
        if len(roles)>30: desc+=f"\n*...and {len(roles)-30} more*"
        e=discord.Embed(title=f"🎭 Server Roles ({len(roles)-1})",description=desc,color=0x3498db)
        await ctx.send(embed=e)

    @commands.command(name="channels",help="List all channels organized")
    async def channels(self,ctx):
        text=ctx.guild.text_channels[:15]
        voice=ctx.guild.voice_channels[:10]
        e=discord.Embed(title=f"📁 Channels ({len(ctx.guild.channels)})",color=0x3498db)
        e.add_field(name=f"💬 Text ({len(ctx.guild.text_channels)})",value="\n".join(f"#{c.name}" for c in text) or "None",inline=True)
        e.add_field(name=f"🔊 Voice ({len(ctx.guild.voice_channels)})",value="\n".join(f"🔊 {c.name}" for c in voice) or "None",inline=True)
        await ctx.send(embed=e)

    @commands.command(name="permissions",aliases=["perms"],help="Check member's permissions")
    async def permissions(self,ctx,member:Optional[discord.Member],channel:Optional[discord.TextChannel]):
        m=member or ctx.author
        ch=channel or ctx.channel
        perms=ch.permissions_for(m)
        allowed=[]
        denied=[]
        for perm,val in perms:
            name=perm.replace("_"," ").title()
            if val: allowed.append(f"✅ {name}")
            else: denied.append(f"❌ {name}")
        e=discord.Embed(title=f"🔐 Permissions: {m.display_name}",color=m.color)
        e.add_field(name="Allowed",value="\n".join(allowed[:15]) or "None",inline=True)
        e.add_field(name="Denied",value="\n".join(denied[:10]) or "None",inline=True)
        await ctx.send(embed=e)

    @commands.command(name="boosts",help="Show server boosters")
    async def boosts(self,ctx):
        boosters=ctx.guild.premium_subscribers
        if not boosters:
            return await ctx.send(embed=discord.Embed(description="💎 No boosters yet. Be the first!",color=0xff73fa))
        desc="\n".join(f"• {m.mention}" for m in boosters[:20])
        if len(boosters)>20: desc+=f"\n...and {len(boosters)-20} more"
        e=discord.Embed(title=f"💎 Server Boosters ({len(boosters)})",description=desc,color=0xff73fa)
        e.add_field(name="Boost Level",value=f"Level {ctx.guild.premium_tier}")
        e.add_field(name="Total Boosts",value=ctx.guild.premium_subscription_count)
        await ctx.send(embed=e)

    @commands.command(name="oldest",help="Show oldest members")
    async def oldest(self,ctx):
        members=sorted([m for m in ctx.guild.members if m.joined_at],key=lambda m:m.joined_at)[:10]
        desc="\n".join(f"`{i+1}.` {m.mention} — {m.joined_at.strftime('%Y-%m-%d')}" for i,m in enumerate(members))
        await ctx.send(embed=discord.Embed(title="🏛️ Oldest Members",description=desc,color=0x3498db))

    @commands.command(name="newest",help="Show newest members")
    async def newest(self,ctx):
        members=sorted([m for m in ctx.guild.members if m.joined_at],key=lambda m:m.joined_at,reverse=True)[:10]
        desc="\n".join(f"`{i+1}.` {m.mention} — {m.joined_at.strftime('%Y-%m-%d')}" for i,m in enumerate(members))
        await ctx.send(embed=discord.Embed(title="🆕 Newest Members",description=desc,color=0x2ecc71))

    @commands.command(name="onlinemembers",help="Show online member count")
    async def onlinemembers(self,ctx):
        online=sum(1 for m in ctx.guild.members if m.status==discord.Status.online)
        idle=sum(1 for m in ctx.guild.members if m.status==discord.Status.idle)
        dnd=sum(1 for m in ctx.guild.members if m.status==discord.Status.dnd)
        offline=sum(1 for m in ctx.guild.members if m.status==discord.Status.offline)
        e=discord.Embed(title="📊 Member Status",color=0x3498db)
        e.add_field(name="🟢 Online",value=online)
        e.add_field(name="🟡 Idle",value=idle)
        e.add_field(name="🔴 DND",value=dnd)
        e.add_field(name="⚫ Offline",value=offline)
        e.add_field(name="Total",value=ctx.guild.member_count)
        await ctx.send(embed=e)

    @commands.command(name="inviteinfo",help="Get info about an invite")
    async def inviteinfo(self,ctx,code:str):
        try:
            inv=await self.bot.fetch_invite(code)
            e=discord.Embed(title=f"🔗 Invite: {code}",color=0x3498db)
            e.add_field(name="Server",value=inv.guild.name if inv.guild else "?")
            e.add_field(name="Channel",value=f"#{inv.channel.name}" if inv.channel else "?")
            e.add_field(name="Inviter",value=str(inv.inviter) if inv.inviter else "?")
            e.add_field(name="Uses",value=inv.uses or "?")
            e.add_field(name="Max Uses",value=inv.max_uses or "∞")
            e.add_field(name="Members",value=inv.approximate_member_count or "?")
            await ctx.send(embed=e)
        except:
            await ctx.send(embed=discord.Embed(description="❌ Invalid invite code.",color=0xe74c3c))

    @commands.command(name="statuscount",help="Count members with specific status")
    async def statuscount(self,ctx,status:str="online"):
        status_map={"online":discord.Status.online,"idle":discord.Status.idle,"dnd":discord.Status.dnd,"offline":discord.Status.offline}
        if status.lower() not in status_map:
            return await ctx.send(embed=discord.Embed(description="❌ Status: online, idle, dnd, offline",color=0xe74c3c))
        count=sum(1 for m in ctx.guild.members if m.status==status_map[status.lower()])
        await ctx.send(embed=discord.Embed(description=f"**{status.title()}** members: **{count}**",color=0x3498db))

async def setup(bot):
    await bot.add_cog(Info(bot))
