"""MUSIC, INFO, CONFIG, TAGS, HELP COGS"""
import discord, datetime, sqlite3
from discord.ext import commands
from typing import Optional

def db(): return sqlite3.connect("ultrabot.db")

class Music(commands.Cog):
    """🎵 Music"""
    def __init__(self,bot): self.bot=bot

    @commands.command(name="play",help="Play music (requires yt-dlp + PyNaCl)")
    async def play(self,ctx,*,query:str):
        if not ctx.author.voice:
            return await ctx.send(embed=discord.Embed(description="❌ Join a voice channel first!",color=0xe74c3c))
        await ctx.send(embed=discord.Embed(description=f"🎵 Searching for: **{query}**\nMusic requires `yt-dlp` and `PyNaCl`.\nRun: `pip install yt-dlp PyNaCl`",color=0xf39c12))

    @commands.command(name="stop",help="Stop music and disconnect")
    async def stop(self,ctx):
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            await ctx.send(embed=discord.Embed(description="⏹️ Stopped and disconnected.",color=0x2ecc71))

    @commands.command(name="pause",help="Pause current music")
    async def pause(self,ctx):
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.pause()
            await ctx.send(embed=discord.Embed(description="⏸️ Paused.",color=0x2ecc71))

    @commands.command(name="resume",help="Resume paused music")
    async def resume(self,ctx):
        if ctx.voice_client and ctx.voice_client.is_paused():
            ctx.voice_client.resume()
            await ctx.send(embed=discord.Embed(description="▶️ Resumed.",color=0x2ecc71))

    @commands.command(name="skip",help="Skip current song")
    async def skip(self,ctx):
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.stop()
            await ctx.send(embed=discord.Embed(description="⏭️ Skipped.",color=0x2ecc71))

    @commands.command(name="volume",help="Set volume 0-200")
    async def volume(self,ctx,vol:int):
        if not 0<=vol<=200:
            return await ctx.send(embed=discord.Embed(description="❌ Volume must be 0-200.",color=0xe74c3c))
        await ctx.send(embed=discord.Embed(description=f"🔊 Volume set to **{vol}%**.",color=0x2ecc71))

    @commands.command(name="queue",help="Show music queue")
    async def queue(self,ctx):
        await ctx.send(embed=discord.Embed(description="📋 Queue is empty. Use `!play` to add songs.",color=0x3498db))

    @commands.command(name="nowplaying",aliases=["np"],help="Show now playing")
    async def nowplaying(self,ctx):
        await ctx.send(embed=discord.Embed(description="🎵 Nothing playing right now.",color=0x3498db))

    @commands.command(name="join",help="Bot joins your voice channel")
    async def join(self,ctx):
        if not ctx.author.voice:
            return await ctx.send(embed=discord.Embed(description="❌ Join a voice channel first!",color=0xe74c3c))
        await ctx.author.voice.channel.connect()
        await ctx.send(embed=discord.Embed(description=f"✅ Joined `{ctx.author.voice.channel.name}`.",color=0x2ecc71))

    @commands.command(name="leave",help="Bot leaves voice channel")
    async def leave(self,ctx):
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            await ctx.send(embed=discord.Embed(description="👋 Left voice channel.",color=0x2ecc71))

    @commands.command(name="shuffle",help="Shuffle the queue")
    async def shuffle(self,ctx):
        await ctx.send(embed=discord.Embed(description="🔀 Queue shuffled.",color=0x2ecc71))

    @commands.command(name="loop",help="Toggle loop mode")
    async def loop(self,ctx):
        await ctx.send(embed=discord.Embed(description="🔁 Loop toggled.",color=0x2ecc71))

    @commands.command(name="lyrics",help="Get song lyrics")
    async def lyrics(self,ctx,*,song:str=None):
        await ctx.send(embed=discord.Embed(description="🎵 Add `genius_token` to config.json for lyrics support.",color=0xf39c12))

    @commands.command(name="playlistinfo",help="Show playlist info")
    async def playlistinfo(self,ctx):
        await ctx.send(embed=discord.Embed(description="📋 No playlist loaded.",color=0x3498db))

    @commands.command(name="seek",help="Seek to position in song")
    async def seek(self,ctx,position:str):
        await ctx.send(embed=discord.Embed(description=f"⏩ Seeking to `{position}`...",color=0x3498db))

    @commands.command(name="bassboost",help="Toggle bass boost")
    async def bassboost(self,ctx):
        await ctx.send(embed=discord.Embed(description="🎵 Bass boost toggled. (Requires ffmpeg filters)",color=0x2ecc71))

    @commands.command(name="nightcore",help="Toggle nightcore effect")
    async def nightcore(self,ctx):
        await ctx.send(embed=discord.Embed(description="🎵 Nightcore effect toggled.",color=0x2ecc71))

async def setup(bot):
    await bot.add_cog(Music(bot))
